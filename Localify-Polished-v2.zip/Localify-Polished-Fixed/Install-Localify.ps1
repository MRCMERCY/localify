$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'Localify'
New-Item -ItemType Directory -Force -Path $target | Out-Null
foreach ($name in @('index.html','styles.css','power.css','fixes.css','cinema.css','app.js','power.js','cinema.js','README.txt','Start-Localify.ps1','mini.html','mini.css','mini.js','Set-Mini-TopMost.ps1')) {
  Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $target $name) -Force
}

$startVbs = Join-Path $target 'Launch-Localify.vbs'
@"
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$target\Start-Localify.ps1""", 0, False
"@ | Set-Content -Path $startVbs -Encoding ASCII

$uninstall = Join-Path $target 'Uninstall-Localify.ps1'
@"
Remove-Item -LiteralPath "$(Join-Path ([Environment]::GetFolderPath('Desktop')) 'Localify.lnk')" -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath "$target" -Recurse -Force -ErrorAction SilentlyContinue
"@ | Set-Content -Path $uninstall -Encoding UTF8

$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop 'Localify.lnk'
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($shortcutPath)
$sc.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
$sc.Arguments = '"' + $startVbs + '"'
$sc.WorkingDirectory = $target
$sc.Description = 'Localify — local music player'
$sc.IconLocation = "$env:SystemRoot\System32\imageres.dll,103"
$sc.Save()

Write-Host ''
Write-Host 'Localify installed successfully.' -ForegroundColor Green
Write-Host "Installed to: $target"
Write-Host "Desktop shortcut: $shortcutPath"
Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + $startVbs + '"')
