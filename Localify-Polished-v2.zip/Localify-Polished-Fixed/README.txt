LOCALIFY — Windows local music player

This build includes automatic lyrics, deep appearance customisation, and an immersive fullscreen player.

INSTALL
1. Extract this ZIP.
2. Double-click "Install Localify.bat".
3. Launch Localify from the desktop shortcut.

APPEARANCE
Settings > Appearance includes:
- Lime, Spotify, Ocean, Violet, Sunset, Rose, Cyber and Mono presets
- Custom accent colour
- Accent glow intensity
- Aurora, Midnight, Graphite and Glass backgrounds
- Compact / Comfortable / Spacious density
- Rounded / Soft / Sharp corners
- Wide / Compact / Minimal sidebar
- Large / Medium / Small artwork
- Classic / Raised / Minimal player
- Bars / Wave / Dots visualizer
- Global interface scaling
- Glass panels on/off
- Animations on/off

FULLSCREEN PLAYER / LYRICS
- One-click fullscreen lyrics from the Lyrics panel
- 50/50 album art + lyrics mode
- Lyrics-only mode
- Artwork-only mode
- Synced karaoke highlighting and clickable lyric seeking
- Configurable lyrics size
- Artwork-blur, accent-gradient or solid fullscreen backdrop
- Adjustable fullscreen artwork scale
- Browser fullscreen exit/re-entry support
- Scrollable lyrics with automatic sync pause while you browse; sync resumes after scrolling stops

LYRICS
- Embedded ID3 lyrics where available
- Adjacent .lrc and .txt files
- Automatic LRCLIB lookup using track metadata
- Synced karaoke-style line highlighting

PLAYBACK
- MP3/local audio playback
- Playlists, favourites, queue and history
- Search, sorting, shuffle and repeat
- Album artwork and metadata
- Keyboard shortcuts

PLAYLISTS
- Add a cover picture to any playlist (Edit playlist > Choose cover image, or drop an image on the cover). It is cropped to a square and shown in the sidebar, the playlist page and the Add-to-playlist picker.
- Playlists without a custom cover show a collage of their album art.

SIDEBAR
- Collapse the sidebar to an icon rail with the arrow next to the Localify logo, or press Ctrl+B. The choice is remembered.

CINEMA MODE (kinetic lyrics)
- Open with the ◉ button in the player bar, the ◉ Cinema button in Focus mode, or press C.
- Every synced lyric line becomes a short edit: words slam, rise, flip, slide and scatter around the screen, with outline echo text sweeping behind, camera pushes / pans / tilts, and a punch + flash on the beat.
- Looks: Bold, Neon and Mono (S key or the button). F / double-click = fullscreen, Space or click = play/pause, Left/Right = seek 5s, Esc = close.
- Instrumental gaps show an animated equaliser. Tracks without synced lyrics show an animated title card with a Find lyrics button.
- Turning Animations off in Settings > Appearance (or the Windows reduced-motion setting) switches Cinema to simple fades.

PRIVACY
Your music files remain on the computer. Automatic lyric lookup sends only the metadata needed to identify the track.

POWER FEATURES
- 10-band EQ, presets, preamp, bass/treble, ReplayGain loudness normalisation, track transitions
- Smart Shuffle and recommendations / For You
- Ratings, listening statistics, daily/monthly charts, top songs/artists/genres and skip tracking
- Duplicate detector, advanced library filters and quality information
- Automatic album-art lookup (track metadata is not editable in the app)
- Automatic artwork/metadata helpers, folder monitoring and drag/drop audio import
- Queue drag/reorder (history, played / now playing / next up sections, Clear), mini player, sleep timer, media-key support and keyboard shortcuts
- Dynamic album-colour themes, Cinema mode and more visualizer styles
- Full backup / restore and M3U playlist export

NOTE
Online metadata/artwork lookup uses public iTunes Search results when enabled. Automatic lyrics continue to use the lyric service configured by Localify.

Mini Player: the Mini Player button opens a separate Windows window that is pinned above other applications. Sleep Timer: choose a time after which Localify pauses playback; Fade out smoothly lowers volume during the final 20 seconds.
