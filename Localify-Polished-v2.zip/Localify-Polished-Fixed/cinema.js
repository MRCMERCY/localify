/* Localify Cinema — kinetic lyric typography.
   Every lyric line becomes a short "edit": words slam, rise, flip, slide and scatter around the
   screen while the camera pushes, pans and punches on the beat.  Scenes are deterministic per
   song + line, so seeking always gives the same look. */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  function boot() {
    if (!window.LocalifyAPI || !document.getElementById('app')) return setTimeout(boot, 40);
    init(window.LocalifyAPI);
  }
  boot();

  function init(api) {
    const state = api.state, audio = api.audio;
    const STYLES = ['bold', 'neon', 'mono'];
    const STYLE_NAMES = { bold: 'Bold', neon: 'Neon', mono: 'Mono' };
    const LEAD = 0.1;                      // switch scenes a touch early; words still land on the beat
    const EXPO = 'cubic-bezier(.16,1,.3,1)', BACK = 'cubic-bezier(.34,1.56,.64,1)', SLAM = 'cubic-bezier(.12,.9,.2,1)';
    const STOP = new Set('a an the and or but of to in on at for with from by as is are was were be been am i me my you your he she it we they them his her its our their this that these those so if then than too very just not no do does did oh uh yeah ya la na hey ooh ah im ill id ive dont cant wont'.split(' '));

    const reduced = () => state.appearance?.animated === false || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
    const fmt = s => api.fmtTime(s);

    // ---------- deterministic randomness ----------
    function hash(str) { let x = 1779033703 ^ str.length; for (let i = 0; i < str.length; i++) { x = Math.imul(x ^ str.charCodeAt(i), 3432918353); x = x << 13 | x >>> 19; } x = Math.imul(x ^ x >>> 16, 2246822507); x = Math.imul(x ^ x >>> 13, 3266489909); return (x ^= x >>> 16) >>> 0; }
    function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
    let seedBase = 'x';
    const rngFor = (idx, salt = '') => mulberry32(hash(seedBase + ':' + idx + ':' + salt));

    // ---------- DOM ----------
    const cx = h('div', 'cx hidden');
    cx.id = 'cinema'; cx.dataset.style = 'bold'; cx.setAttribute('role', 'dialog'); cx.setAttribute('aria-label', 'Cinema mode');
    cx.innerHTML = `
      <div class="cx-bg"><div class="cx-art none"></div><div class="cx-blob b1"></div><div class="cx-blob b2"></div><div class="cx-blob b3"></div><div class="cx-grain"></div></div>
      <div class="cx-camera"><div class="cx-shake"><div class="cx-stage"></div></div></div>
      <div class="cx-interlude"><div class="cx-bars"><i></i><i></i><i></i><i></i><i></i></div><small>Instrumental</small></div>
      <div class="cx-vignette"></div><div class="cx-flash"></div>
      <div class="cx-hud cx-top">
        <div class="cx-tag"><strong class="cx-title">Nothing playing</strong><span class="cx-artist"></span>
          <div class="cx-note" hidden><span class="cx-note-text"></span> <button class="cx-btn cx-find" type="button" style="height:26px;min-width:0;padding:0 10px;font-size:12px;margin-left:6px">Find lyrics</button></div></div>
        <div class="cx-actions"><button class="cx-btn cx-style" type="button" title="Switch look (S)">Bold</button><button class="cx-btn cx-fs" type="button" title="Fullscreen (F)">⛶</button><button class="cx-btn cx-close" type="button" title="Close (Esc)">✕</button></div>
      </div>
      <div class="cx-hud cx-bottom">
        <button class="cx-btn cx-prev" type="button" title="Previous">◀◀</button><button class="cx-btn cx-play" type="button" title="Play / pause">▶</button><button class="cx-btn cx-next" type="button" title="Next">▶▶</button>
        <div class="cx-bar"><div><span class="cx-fill"></span></div></div><span class="cx-time">0:00 / 0:00</span>
      </div>`;
    document.body.appendChild(cx);
    const cam = $('.cx-camera', cx), shakeEl = $('.cx-shake', cx), stage = $('.cx-stage', cx), flashEl = $('.cx-flash', cx);
    const interlude = $('.cx-interlude', cx), artEl = $('.cx-art', cx);
    const elTitle = $('.cx-title', cx), elArtist = $('.cx-artist', cx), elNote = $('.cx-note', cx), elNoteText = $('.cx-note-text', cx);
    const btnPlay = $('.cx-play', cx), fill = $('.cx-fill', cx), elTime = $('.cx-time', cx), bar = $('.cx-bar', cx);

    // ---------- animation bookkeeping (everything pauses with the music) ----------
    const allAnims = new Set();
    function anim(el, kf, opts, bucket) {
      const a = el.animate(kf, Object.assign({ fill: 'both' }, opts));
      allAnims.add(a); if (bucket) bucket.push(a);
      if (audio.paused) a.pause();
      a.finished.then(() => { if (!bucket) allAnims.delete(a); }).catch(() => allAnims.delete(a));
      return a;
    }
    const pauseAll = () => allAnims.forEach(a => { if (a.playState === 'running') a.pause(); });
    const resumeAll = () => allAnims.forEach(a => { if (a.playState === 'paused') a.play(); });

    // ---------- state ----------
    let open = false, raf = 0, song = null, parsed = { lines: [], synced: false }, timed = [];
    let sig = '', cur = { idx: -99, scene: null }, lastNow = 0, camAnim = null, lastRefresh = 0;
    let beatAvg = 0, beatLast = 0, beatLevel = 0, buf = null, lastUi = 0;

    function songNow() { return state.library.find(s => s.id === state.currentId) || null; }
    const sigOf = s => (s?.id || '') + '|' + (s?.lyrics ? s.lyrics.length : 0);

    function loadSong() {
      song = songNow();
      parsed = song ? api.getSongLyrics(song) : { lines: [], synced: false };
      timed = parsed.lines.filter(l => l.time != null);
      sig = sigOf(song); seedBase = song?.id || 'x';
      elTitle.textContent = song?.title || song?.name || 'Nothing playing';
      elArtist.textContent = song?.artist || '';
      cx.style.setProperty('--cx-img', song?.art ? `url("${song.art}")` : 'none');
      artEl.classList.toggle('none', !song?.art);
      const noLyrics = !timed.length;
      elNote.hidden = !noLyrics;
      elNoteText.textContent = parsed.lines.length ? 'This track only has unsynced lyrics' : 'No synced lyrics for this track';
      clearScenes(true); interlude.classList.remove('on');
      cur = { idx: -99, scene: null };
    }
    function clearScenes() { [...stage.children].forEach(c => { c.getAnimations?.({subtree:true}).forEach(a => { allAnims.delete(a); a.cancel(); }); c.remove(); }); if (cur.scene) { cur.scene.bucket.forEach(a => allAnims.delete(a)); } cur.scene = null; }

    // ---------- text helpers ----------
    const tokenize = t => t.replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
    const clean = w => w.replace(/[^\p{L}\p{N}']/gu, '').toLowerCase();
    const isStop = w => STOP.has(clean(w));
    const hasText = t => /[\p{L}\p{N}]/u.test(t || '');

    // ---------- templates ----------
    function validTemplates(n, maxLen) {
      let l;
      if (n === 1) l = ['giant', 'slam', 'pop', 'mask', 'flip'];
      else if (n <= 3) l = ['mask', 'stack', 'slam', 'giant', 'diag', 'pop', 'scatter', 'flip'];
      else if (n <= 6) l = ['mask', 'pop', 'split', 'flip', 'scatter', 'stack', 'diag', 'giant'];
      else l = ['mask', 'pop', 'flip', 'split'];
      return l.filter(t => !(t === 'stack' || t === 'diag') || (n >= 2 && n <= 5))
              .filter(t => t !== 'slam' || n <= 4)
              .filter(t => t !== 'scatter' || (n >= 2 && n <= 6 && maxLen <= 9))
              .filter(t => t !== 'split' || n >= 2)
              .filter(t => t !== 'giant' || n <= 6);
    }
    function lineInfo(i) { const t = timed[i]?.text || ''; const w = tokenize(t); return { n: w.length, maxLen: Math.max(1, ...w.map(x => x.length)) }; }
    function pickTpl(i) { const { n, maxLen } = lineInfo(i); const list = validTemplates(n, maxLen); return { list, t: pick(rngFor(i, 'tpl'), list) }; }
    function templateFor(i) {
      const a = pickTpl(i);
      if (i > 0 && timed[i - 1] && hasText(timed[i - 1].text) && pickTpl(i - 1).t === a.t && a.list.length > 1) return a.list[(a.list.indexOf(a.t) + 1) % a.list.length];
      return a.t;
    }

    // ---------- entrances / exits ----------
    function entrance(kind, r) {
      switch (kind) {
        case 'pop': return { kf: [{ opacity: 0, transform: `scale(.35) rotate(${(r * 10 - 5).toFixed(1)}deg)` }, { opacity: 1, transform: 'scale(1) rotate(0deg)' }], dur: 430, ease: BACK };
        case 'rise': return { kf: [{ opacity: 1, transform: 'translateY(112%)' }, { opacity: 1, transform: 'translateY(0)' }], dur: 620, ease: EXPO };
        case 'drop': return { kf: [{ opacity: 1, transform: 'translateY(-112%)' }, { opacity: 1, transform: 'translateY(0)' }], dur: 620, ease: EXPO };
        case 'slideL': return { kf: [{ opacity: 0, transform: 'translateX(-58vw) skewX(14deg)', filter: 'blur(16px)' }, { opacity: 1, transform: 'translateX(0) skewX(0deg)', filter: 'blur(0px)' }], dur: 680, ease: EXPO };
        case 'slideR': return { kf: [{ opacity: 0, transform: 'translateX(58vw) skewX(-14deg)', filter: 'blur(16px)' }, { opacity: 1, transform: 'translateX(0) skewX(0deg)', filter: 'blur(0px)' }], dur: 680, ease: EXPO };
        case 'slam': return { kf: [{ opacity: 0, transform: 'scale(3.4)', filter: 'blur(18px)' }, { opacity: 1, transform: 'scale(.94)', filter: 'blur(0px)', offset: .7 }, { opacity: 1, transform: 'scale(1)', filter: 'blur(0px)' }], dur: 340, ease: SLAM };
        case 'flip': return { kf: [{ opacity: 0, transform: 'perspective(900px) rotateX(-100deg) translateY(30%)' }, { opacity: 1, transform: 'perspective(900px) rotateX(0deg) translateY(0)' }], dur: 640, ease: EXPO };
        case 'zoom': return { kf: [{ opacity: 0, transform: 'scale(.1) rotate(-10deg)' }, { opacity: 1, transform: 'scale(1) rotate(0deg)' }], dur: 480, ease: BACK };
        default: return { kf: [{ opacity: 0 }, { opacity: 1 }], dur: 220, ease: 'ease-out' };
      }
    }
    function exitFrames(kind) {
      switch (kind) {
        case 'up': return { kf: [{ opacity: 1, transform: 'translateY(0)' }, { opacity: 0, transform: 'translateY(-16vh)' }], dur: 300 };
        case 'down': return { kf: [{ opacity: 1, transform: 'translateY(0)' }, { opacity: 0, transform: 'translateY(16vh)' }], dur: 300 };
        case 'left': return { kf: [{ opacity: 1, transform: 'translateX(0) skewX(0deg)' }, { opacity: 0, transform: 'translateX(-34vw) skewX(-12deg)' }], dur: 300 };
        case 'right': return { kf: [{ opacity: 1, transform: 'translateX(0) skewX(0deg)' }, { opacity: 0, transform: 'translateX(34vw) skewX(12deg)' }], dur: 300 };
        case 'zoom': return { kf: [{ opacity: 1, transform: 'scale(1)', filter: 'blur(0px)' }, { opacity: 0, transform: 'scale(1.8)', filter: 'blur(12px)' }], dur: 280 };
        default: return { kf: [{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.6)' }], dur: 260 };
      }
    }
    function removeScene(sc, mode) {
      if (!sc) return;
      const finish = () => { sc.bucket.forEach(x => { try { x.cancel(); } catch {} allAnims.delete(x); }); try { sc.exitAnim && allAnims.delete(sc.exitAnim); } catch {} sc.el.remove(); };
      if (mode === 'instant') { finish(); return; }
      const red = reduced();
      const e = red ? { kf: [{ opacity: 1 }, { opacity: 0 }], dur: 160 } : exitFrames(sc.exitKind);
      const a = sc.el.animate(e.kf, { duration: e.dur, easing: 'cubic-bezier(.5,0,.9,.4)', fill: 'forwards' });
      sc.exitAnim = a; allAnims.add(a); if (audio.paused) a.pause();
      a.onfinish = finish;
      if (!audio.paused) setTimeout(finish, e.dur + 400);
    }

    // ---------- camera, shake, flash ----------
    function cameraFor(r, span, elapsed) {
      if (reduced()) return;
      const k = pick(r, ['push', 'pull', 'panL', 'panR', 'tilt', 'push']);
      const frames = {
        push: [{ transform: 'scale(1)' }, { transform: 'scale(1.075)' }],
        pull: [{ transform: 'scale(1.09)' }, { transform: 'scale(1)' }],
        panL: [{ transform: 'translate3d(1.6vw,0,0) scale(1.05)' }, { transform: 'translate3d(-1.6vw,0,0) scale(1.05)' }],
        panR: [{ transform: 'translate3d(-1.6vw,0,0) scale(1.05)' }, { transform: 'translate3d(1.6vw,0,0) scale(1.05)' }],
        tilt: [{ transform: 'rotate(-1.3deg) scale(1.05)' }, { transform: 'rotate(1.3deg) scale(1.05)' }]
      }[k];
      if (camAnim) { allAnims.delete(camAnim); try { camAnim.cancel(); } catch {} }
      camAnim = anim(cam, frames, { duration: Math.max(1.5, span + .4) * 1000, delay: -elapsed * 1000, easing: 'cubic-bezier(.3,.1,.3,1)' });
    }
    function shake(delayMs, s = .5) {
      if (reduced()) return;
      const a = shakeEl.animate([{ transform: 'translate(0,0)' }, { transform: `translate(${-s}vw,${s * .6}vw)` }, { transform: `translate(${s * .8}vw,${-s * .5}vw)` }, { transform: `translate(${-s * .4}vw,${s * .2}vw)` }, { transform: 'translate(0,0)' }], { duration: 230, delay: Math.max(0, delayMs), easing: 'ease-out' });
      allAnims.add(a); if (audio.paused) a.pause(); a.finished.then(() => allAnims.delete(a)).catch(() => allAnims.delete(a));
    }
    function flash(delayMs, peak = .2) {
      if (reduced()) return;
      const a = flashEl.animate([{ opacity: 0 }, { opacity: peak }, { opacity: 0 }], { duration: 200, delay: Math.max(0, delayMs) });
      allAnims.add(a); if (audio.paused) a.pause(); a.finished.then(() => allAnims.delete(a)).catch(() => allAnims.delete(a));
    }

    // ---------- scene builder ----------
    function buildScene(spec) {
      const { idx, text, t0, span, kind, sub, now } = spec;
      const rng = rngFor(idx, kind), red = reduced(), bucket = [];
      const elapsed = now - t0;
      const words = tokenize(text), n = words.length, chars = text.length;
      const maxLen = Math.max(...words.map(w => w.length));
      const tpl = kind === 'title' ? 'mask' : templateFor(idx);
      const up = rng() < .7;

      // anchor + alignment
      let anchors;
      if (kind === 'title') anchors = ['c'];
      else if (tpl === 'split' || tpl === 'scatter') anchors = ['full'];
      else if (tpl === 'stack' || tpl === 'diag') anchors = ['c', 'l', 'r'];
      else anchors = n <= 3 ? ['c', 'c', 'l', 'r', 'tl', 'br', 'tr', 'bl'] : ['c', 'c', 'l', 'r'];
      const anchor = pick(rng, anchors);
      const al = ['l', 'tl', 'bl'].includes(anchor) ? 'al-left' : ['r', 'tr', 'br'].includes(anchor) ? 'al-right' : '';
      const origin = { c: '50% 50%', l: '0% 50%', r: '100% 50%', tl: '0% 0%', tr: '100% 0%', bl: '0% 100%', br: '100% 100%', full: '50% 50%' }[anchor];

      // emphasis
      let key = -1, best = -1;
      words.forEach((w, i) => { const sc = (isStop(w) ? 0 : clean(w).length) + i * .001; if (sc > best) { best = sc; key = i; } });
      const emph = new Map(), styles = ['accent', 'box', 'outline', 'serif'];
      if (kind === 'title') { if (n > 1) emph.set(n - 1, 'accent'); }
      else {
        const s1 = pick(rng, styles); emph.set(key, tpl === 'giant' && s1 === 'box' ? 'accent' : s1);
        if (n >= 5 && rng() < .6) {
          let k2 = -1, b2 = -1;
          words.forEach((w, i) => { if (i === key || isStop(w)) return; const l = clean(w).length; if (l > b2) { b2 = l; k2 = i; } });
          if (k2 >= 0 && b2 >= 4) emph.set(k2, pick(rng, styles.filter(x => x !== s1 && !(s1 === 'box' && x === 'outline') && !(s1 === 'outline' && x === 'box'))));
        }
      }
      const dimOK = n >= 5 && kind !== 'title' && ['mask', 'pop', 'flip', 'split'].includes(tpl);
      const mkWord = (i, mask) => {
        const w = h('span', 'cx-w w-solid'); w.textContent = words[i];
        const st = emph.get(i);
        if (st) w.className = 'cx-w w-' + st;
        else if (dimOK && isStop(words[i])) { w.className = 'cx-w w-solid w-dim'; w.style.fontSize = '.74em'; }
        const wrap = h('span', 'cx-wrap' + (mask ? ' m' : '')); wrap.append(w);
        return { wrap, w };
      };

      // structure
      const scene = h('div', 'cx-scene a-' + anchor + (up ? ' up' : ''));
      const drift = h('div', 'cx-drift');
      const fit = h('div', 'cx-fit ' + al + ' t-' + tpl);
      fit.style.transformOrigin = origin;
      const units = [];
      let useFit = true, shakeOn = false;

      switch (tpl) {
        case 'mask': { const box = h('div', 'cx-words'); const dir = rng() < .55 ? 'rise' : 'drop'; words.forEach((_, i) => { const o = mkWord(i, true); box.append(o.wrap); units.push({ w: o.w, k: dir }); }); fit.append(box); break; }
        case 'pop': { const box = h('div', 'cx-words'); words.forEach((_, i) => { const o = mkWord(i, false); box.append(o.wrap); units.push({ w: o.w, k: emph.has(i) ? 'zoom' : 'pop' }); }); fit.append(box); break; }
        case 'flip': { const box = h('div', 'cx-words'); words.forEach((_, i) => { const o = mkWord(i, false); box.append(o.wrap); units.push({ w: o.w, k: 'flip' }); }); fit.append(box); break; }
        case 'slam': { const box = h('div', 'cx-words'); words.forEach((_, i) => { const o = mkWord(i, false); box.append(o.wrap); units.push({ w: o.w, k: 'slam' }); }); fit.append(box); shakeOn = true; break; }
        case 'stack': { const box = h('div', 'cx-words'); words.forEach((_, i) => { const o = mkWord(i, false); o.wrap.style.alignSelf = i % 2 ? 'flex-end' : 'flex-start'; o.wrap.style[i % 2 ? 'marginLeft' : 'marginRight'] = '.9em'; box.append(o.wrap); units.push({ w: o.w, k: i % 2 ? 'slideR' : 'slideL' }); }); fit.append(box); break; }
        case 'diag': { const box = h('div', 'cx-words'); words.forEach((_, i) => { const o = mkWord(i, false); o.wrap.style.marginLeft = (i * .75).toFixed(2) + 'em'; box.append(o.wrap); units.push({ w: o.w, k: 'slideL' }); }); fit.append(box); break; }
        case 'giant': {
          const box = h('div', 'cx-words');
          words.forEach((_, i) => {
            const isKey = i === key; const o = mkWord(i, !isKey);
            if (isKey) { o.w.style.fontSize = n === 1 ? '1em' : '2.5em'; if (!emph.has(i)) o.w.classList.add('w-accent'); }
            else { o.w.style.fontSize = '.6em'; o.w.classList.add('w-dim'); }
            box.append(o.wrap);
            units.push({ w: o.w, k: isKey ? (n === 1 && rng() < .5 ? 'zoom' : 'slam') : 'rise' });
            if (isKey) shakeOn = true;
          });
          fit.append(box); break;
        }
        case 'split': {
          useFit = false;
          const half = Math.ceil(n / 2), a = h('div', 'cx-words'), b = h('div', 'cx-words');
          words.forEach((_, i) => { const o = mkWord(i, false); (i < half ? a : b).append(o.wrap); units.push({ w: o.w, k: i < half ? 'slideL' : 'slideR' }); });
          fit.append(a, b); break;
        }
        case 'scatter': {
          useFit = false;
          const cells = []; for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) cells.push([c, r]);
          for (let i = cells.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [cells[i], cells[j]] = [cells[j], cells[i]]; }
          const chosen = cells.slice(0, n).sort((p, q) => p[1] - q[1] || p[0] - q[0]);
          words.forEach((_, i) => {
            const o = mkWord(i, false); const [c, r] = chosen[i];
            const pos = h('div', 'cx-pos'); pos.style.left = (22 + c * 28 + (rng() * 4 - 2)).toFixed(1) + '%'; pos.style.top = (r * 33.3 + 16.65 + (rng() * 8 - 4)).toFixed(1) + '%';
            pos.append(o.wrap); fit.append(pos); units.push({ w: o.w, k: pick(rng, ['pop', 'zoom', 'slideL', 'slideR', 'flip']) });
          });
          break;
        }
      }
      if (sub) { const s = h('div', 'cx-sub', sub); fit.append(s); units.sub = s; }

      // font size
      const capW = w => (86 / (w * .72)).toFixed(2);
      let base;
      if (tpl === 'giant') base = n === 1 ? 27 : 9.5;
      else if (tpl === 'stack' || tpl === 'diag') base = n <= 2 ? 17 : n === 3 ? 14 : n === 4 ? 11.5 : 10;
      else if (tpl === 'split') base = chars <= 24 ? 11.5 : 9;
      else if (tpl === 'slam') base = n === 1 ? 28 : chars <= 12 ? 24 : chars <= 22 ? 17 : 13;
      else if (kind === 'title') base = chars <= 14 ? 16 : chars <= 26 ? 12 : 9;
      else base = chars <= 10 ? 23 : chars <= 18 ? 18 : chars <= 28 ? 14 : chars <= 42 ? 10.8 : chars <= 60 ? 8.4 : chars <= 90 ? 6.6 : 5.4;
      const keyMult = tpl === 'giant' && n > 1 ? 2.5 : 1;
      const capLen = Math.max(maxLen, (words[key]?.length || 0) * keyMult);
      if (tpl === 'scatter') fit.style.fontSize = `min(14vmin, ${(27 / (maxLen * .7)).toFixed(2)}vw)`;
      else fit.style.fontSize = `min(${base}vmin, ${capW(capLen)}vw)`;

      drift.append(fit); scene.append(drift); stage.append(scene);
      if (useFit) {
        const availW = innerWidth * .88, availH = innerHeight * .78;
        const w = fit.offsetWidth || 1, hh = fit.offsetHeight || 1;
        fit.style.setProperty('--fit', Math.min(1, availW / w, availH / hh).toFixed(3));
      }

      // timing
      const step = tpl === 'slam' ? Math.max(.2, Math.min(span * .75, .3 * (n - 1) + .1)) : Math.max(.25, Math.min(span * .6, .17 * n + .3));
      units.forEach((u, i) => {
        const frac = n === 1 ? 0 : i / (n - 1), delay = step * frac - elapsed;
        const e = entrance(red ? 'fade' : u.k, rng());
        anim(u.w, e.kf, { duration: e.dur, delay: delay * 1000, easing: e.ease }, bucket);
        if (!red && u.k === 'slam' && delay > -.05) { shake(delay * 1000 + 110, .55); flash(delay * 1000 + 90, .2); }
      });
      if (units.sub) anim(units.sub, [{ opacity: 0, transform: 'translateY(1.2vmin)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 600, delay: (step + .25 - elapsed) * 1000, easing: EXPO }, bucket);

      // idle drift, camera, background colour, ghost text
      if (!red) {
        const dx = (rng() * 2 - 1) * 1.4, dy = (rng() * 2 - 1), sc = 1.035 + rng() * .03, rot = (rng() * 2 - 1) * .8;
        anim(drift, [{ transform: 'translate3d(0,0,0) scale(1) rotate(0deg)' }, { transform: `translate3d(${dx.toFixed(2)}vw,${dy.toFixed(2)}vh,0) scale(${sc.toFixed(3)}) rotate(${rot.toFixed(2)}deg)` }], { duration: Math.max(1.5, span + .3) * 1000, delay: -elapsed * 1000, easing: 'linear' }, bucket);
        cameraFor(rng, span, elapsed);
        cx.style.setProperty('--cx-hue', Math.round(rng() * 50 - 25) + 'deg');
        if (kind !== 'title' && !['split', 'scatter'].includes(tpl) && rng() < .5) {
          const g = h('div', 'cx-ghost'); g.textContent = (words[key].replace(/[^\p{L}\p{N}']/gu, '') || words[key]).toUpperCase();
          g.style.fontSize = '30vmin'; g.style.top = (4 + rng() * 52).toFixed(0) + '%'; scene.prepend(g);
          const gw = g.offsetWidth || innerWidth * .6, right = rng() < .5, from = right ? -gw : innerWidth, to = right ? innerWidth : -gw, lerp = p => (from + (to - from) * p).toFixed(0);
          anim(g, [{ opacity: 0, transform: `translateX(${lerp(0)}px)` }, { opacity: .14, transform: `translateX(${lerp(.08)}px)`, offset: .08 }, { opacity: .14, transform: `translateX(${lerp(.9)}px)`, offset: .9 }, { opacity: 0, transform: `translateX(${lerp(1)}px)` }], { duration: Math.max(3.2, span + 1) * 1000, delay: -elapsed * 1000, easing: 'linear' }, bucket);
        }
      }
      return { el: scene, bucket, exitKind: pick(rng, ['up', 'zoom', 'left', 'right', 'down', 'shrink']) };
    }

    // ---------- line state machine ----------
    function idxAt(t) { let lo = 0, hi = timed.length - 1, r = -1; while (lo <= hi) { const m = (lo + hi) >> 1; if (timed[m].time <= t) { r = m; lo = m + 1; } else hi = m - 1; } return r; }
    const setInterlude = on => interlude.classList.toggle('on', !!on);

    function showTitleCard(now, hold) {
      cur.scene = buildScene({ idx: -1, text: song?.title || song?.name || 'Untitled', sub: song?.artist || '', t0: now, span: hold, kind: 'title', now });
    }
    function setLine(idx, now, instant) {
      removeScene(cur.scene, instant ? 'instant' : 'exit');
      cur = { idx, scene: null, holdChecked: false };
      setInterlude(false);
      if (idx < 0) { const first = timed[0]?.time || 0; if (first - now > 2) showTitleCard(now, first - now - .3); return; }
      const line = timed[idx], text = (line.text || '').trim();
      if (!hasText(text)) { cur.holdChecked = true; setInterlude(true); return; }
      const next = timed[idx + 1], dur = audio.duration || 0;
      const nextT = next ? next.time : Math.max(line.time + 6, dur);
      const n = tokenize(text).length, hold = Math.max(2, n * .5 + 1.1), span = Math.max(.6, Math.min(nextT - line.time, hold));
      cur.nextT = nextT; cur.holdEnd = line.time + span;
      cur.scene = buildScene({ idx, text, t0: line.time, span, kind: 'lyric', now });
    }
    function endHold(now) {
      cur.holdChecked = true;
      if (cur.nextT - cur.holdEnd > .5) { removeScene(cur.scene, 'exit'); cur.scene = null; if (cur.nextT - now > 2.2) setInterlude(true); }
    }

    // ---------- beat detection ----------
    function detectBeat(t) {
      const an = window.__localifyAudioGraph?.analyser; if (!an || audio.paused) { beatLevel *= .9; return; }
      if (!buf || buf.length !== an.frequencyBinCount) buf = new Uint8Array(an.frequencyBinCount);
      an.getByteFrequencyData(buf);
      let e = 0; for (let i = 0; i < 6; i++) e += buf[i]; e /= 6 * 255;
      beatAvg = beatAvg * .94 + e * .06;
      let strength = 0;
      if (e > .35 && e > beatAvg * 1.22 && t - beatLast > 230) { beatLast = t; strength = Math.min(1, (e - beatAvg) * 3.2 + .3); }
      beatLevel = Math.max(beatLevel * .9, strength);
      cx.style.setProperty('--cx-beat', beatLevel.toFixed(2));
      if (strength && !reduced()) {
        stage.animate([{ transform: `scale(${(1 + .026 * strength).toFixed(4)})` }, { transform: 'scale(1)' }], { duration: 260, easing: 'cubic-bezier(.2,.8,.2,1)' });
        if (strength > .7) flash(0, .09);
      }
    }

    // ---------- main loop ----------
    function tick(t) {
      raf = requestAnimationFrame(tick);
      if (!open) return;
      if (t - lastRefresh > 1000 || (state.currentId || null) !== (song?.id || null)) { lastRefresh = t; const s = songNow(); if (s?.id !== song?.id || sigOf(s) !== sig) { song = s; loadSong(); } }
      const now = audio.currentTime || 0;
      const jumped = now - lastNow > 1.2 || now < lastNow - .25; lastNow = now;
      if (song && timed.length) {
        const idx = idxAt(now + LEAD);
        if (idx !== cur.idx || jumped) setLine(idx, now, jumped || cur.idx === -99);
        else if (cur.scene && !cur.holdChecked && now > cur.holdEnd) endHold(now);
      } else if (song && cur.idx === -99) {
        removeScene(cur.scene, 'instant');
        cur = { idx: -2, scene: null, holdChecked: true };
        showTitleCard(now, 9999);
      }
      detectBeat(t);
      if (t - lastUi > 120) {
        lastUi = t; const d = audio.duration || 0;
        fill.style.width = d ? (now / d * 100).toFixed(2) + '%' : '0%';
        elTime.textContent = `${fmt(now)} / ${fmt(d)}`;
      }
    }

    // ---------- controls ----------
    let hudTimer = 0;
    function showHud() { cx.classList.add('hud-on'); cx.classList.remove('hud-off'); clearTimeout(hudTimer); hudTimer = setTimeout(() => { if (!audio.paused) { cx.classList.remove('hud-on'); cx.classList.add('hud-off'); } }, 2800); }
    const syncPlay = () => { btnPlay.textContent = audio.paused ? '▶' : '❚❚'; cx.classList.toggle('paused', audio.paused); };
    function applyStyle() { const st = STYLES.includes(state.appearance.cinemaStyle) ? state.appearance.cinemaStyle : 'bold'; cx.dataset.style = st; $('.cx-style', cx).textContent = STYLE_NAMES[st]; }
    function openCinema() {
      if (!songNow()) { api.toast('Play a song first to use Cinema mode'); return; }
      if (open) return;
      open = true; applyStyle(); cx.classList.remove('hidden'); document.body.classList.add('cx-open');
      lastNow = audio.currentTime || 0; song = null; sig = ''; loadSong(); syncPlay(); showHud();
      cancelAnimationFrame(raf); raf = requestAnimationFrame(tick);
    }
    function closeCinema() {
      if (!open) return;
      open = false; cancelAnimationFrame(raf); clearScenes(); setInterlude(false);
      if (camAnim) { allAnims.delete(camAnim); try { camAnim.cancel(); } catch {} camAnim = null; }
      cx.classList.add('hidden'); document.body.classList.remove('cx-open');
      if (document.fullscreenElement === cx) document.exitFullscreen().catch(() => {});
    }
    const toggleCinema = () => (open ? closeCinema() : openCinema());
    async function toggleFs() { try { if (document.fullscreenElement === cx) await document.exitFullscreen(); else await cx.requestFullscreen(); } catch {} }

    $('.cx-close', cx).onclick = closeCinema;
    $('.cx-fs', cx).onclick = e => { toggleFs(); e.currentTarget.blur(); };
    $('.cx-style', cx).onclick = e => { const i = STYLES.indexOf(cx.dataset.style); state.appearance.cinemaStyle = STYLES[(i + 1) % STYLES.length]; applyStyle(); api.persist(); e.currentTarget.blur(); };
    btnPlay.onclick = e => { if (audio.paused) audio.play().catch(() => {}); else audio.pause(); e.currentTarget.blur(); };
    $('.cx-prev', cx).onclick = e => { api.previousTrack(); e.currentTarget.blur(); };
    $('.cx-next', cx).onclick = e => { api.nextTrack(); e.currentTarget.blur(); };
    $('.cx-find', cx).onclick = e => { if (song) api.fetchLyricsOnline(song, true); e.currentTarget.blur(); };
    cx.addEventListener('mousemove', showHud);
    cx.addEventListener('click', e => { if (e.target.closest('.cx-hud')) return; if (audio.paused) audio.play().catch(() => {}); else audio.pause(); });
    cx.addEventListener('dblclick', e => { if (!e.target.closest('.cx-hud')) toggleFs(); });

    let dragging = false;
    const seekFrom = e => { const r = bar.getBoundingClientRect(), p = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); if (audio.duration) audio.currentTime = p * audio.duration; };
    bar.addEventListener('pointerdown', e => { dragging = true; bar.setPointerCapture(e.pointerId); seekFrom(e); });
    bar.addEventListener('pointermove', e => { if (dragging) seekFrom(e); });
    bar.addEventListener('pointerup', () => { dragging = false; });

    audio.addEventListener('pause', () => { pauseAll(); syncPlay(); if (open) showHud(); });
    audio.addEventListener('play', () => { resumeAll(); syncPlay(); if (open) showHud(); });
    document.addEventListener('visibilitychange', () => { if (open && !document.hidden) cur.idx = -99; });
    let rz; window.addEventListener('resize', () => { if (!open) return; clearTimeout(rz); rz = setTimeout(() => { cur.idx = -99; }, 200); });

    document.addEventListener('keydown', e => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');
      if (open) {
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeCinema(); return; }
        if (typing) return;
        const k = e.key.toLowerCase();
        if (!e.ctrlKey && !e.metaKey && !e.altKey) {
          if (k === 'f') { e.preventDefault(); toggleFs(); }
          else if (k === 's') { e.preventDefault(); $('.cx-style', cx).click(); }
          else if (k === 'c') { e.preventDefault(); closeCinema(); }
          else if (e.key === 'ArrowRight') { e.preventDefault(); e.stopPropagation(); audio.currentTime = Math.min((audio.duration || 1e9) - .1, audio.currentTime + 5); }
          else if (e.key === 'ArrowLeft') { e.preventDefault(); e.stopPropagation(); audio.currentTime = Math.max(0, audio.currentTime - 5); }
        }
        return;
      }
      if (typing || e.ctrlKey || e.metaKey || e.altKey || e.key.toLowerCase() !== 'c') return;
      if (!$('#modal')?.classList.contains('hidden')) return;
      e.preventDefault(); openCinema();
    }, true);

    // ---------- entry points ----------
    function addButtons() {
      const lb = $('#lyricsBtn');
      if (lb && !$('#cinemaBtn')) { const b = h('button', 'player-btn', '◉'); b.id = 'cinemaBtn'; b.title = 'Cinema mode (C)'; b.onclick = e => { openCinema(); e.currentTarget.blur(); }; lb.after(b); }
      const fa = $('#focusOverlay .focus-actions');
      if (fa && !$('#focusCinemaBtn')) { const b = h('button', 'focus-action', '◉ Cinema'); b.id = 'focusCinemaBtn'; b.title = 'Cinema mode — kinetic lyrics'; b.onclick = openCinema; fa.insertBefore(b, $('#focusFullscreenBtn')); }
    }
    addButtons();
    window.addEventListener('localify-ready', addButtons);
    window.LocalifyCinema = { open: openCinema, close: closeCinema, toggle: toggleCinema };
  }
})();
