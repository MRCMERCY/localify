@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$t=Join-Path $env:LOCALAPPDATA 'Localify'; Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $t; Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Localify.lnk'); Write-Host 'Localify removed.'; pause"
