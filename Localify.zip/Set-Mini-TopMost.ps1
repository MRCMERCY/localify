param([int]$ParentPid)
$ErrorActionPreference='SilentlyContinue'
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class MiniWin {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", SetLastError=true)] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
  public static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
  public static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
  public const uint SWP_NOMOVE=0x0002, SWP_NOSIZE=0x0001, SWP_SHOWWINDOW=0x0040;
}
"@
while($true){
  if($ParentPid -gt 0 -and -not (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue)){break}
  [MiniWin]::EnumWindows({ param($h,$l)
    if(-not [MiniWin]::IsWindowVisible($h)){ return $true }
    $sb=New-Object System.Text.StringBuilder 256
    [void][MiniWin]::GetWindowText($h,$sb,$sb.Capacity)
    if($sb.ToString() -like '*Localify Mini Player*'){
      [void][MiniWin]::SetWindowPos($h,[MiniWin]::HWND_TOPMOST,0,0,0,0,[MiniWin]::SWP_NOMOVE -bor [MiniWin]::SWP_NOSIZE -bor [MiniWin]::SWP_SHOWWINDOW)
    }
    return $true
  },[IntPtr]::Zero)
  Start-Sleep -Milliseconds 700
}
