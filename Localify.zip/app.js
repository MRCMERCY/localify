/* Localify — local-first music player. No external network or accounts required. */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const audio = $('#audio');
  const state = {
    view: 'home',
    playlistId: null,
    search: '',
    sort: 'added',
    library: [],
    folders: [],
    playlists: [],
    favorites: new Set(),
    history: [],
    queue: [],
    currentId: null,
    queueIndex: -1,
    queueScrollTop: 0,
    shuffle: false,
    repeat: 'off',
    volume: 0.8,
    previousVolume: 0.8,
    visualizer: true,
    visualizerStyle: 'bars',
    dbReady: false,
    audioObjectUrl: null,
    permissions: false,
    lyricsOpen: false,
    autoFetchLyrics: true,
    appearance: {
      preset: 'lime', accent: '#9cff57', accent2: '#d7ffb9',
      background: 'aurora', density: 'comfortable', radius: 'rounded',
      glass: true, sidebar: 'wide', fontScale: 1, artwork: 'large',
      player: 'bar', animated: true, focusLayout: 'split', focusLyricsSize: 'large', focusBackdrop: 'artwork', focusArtScale: 1, cinemaStyle: 'random', cinemaBeat: 'strong', cinemaBeatSensitivity: 'medium', cinemaIntensity: 1, cinemaTransition: 'dynamic', accentGlow: 'medium', sidebarCollapsed: false
    }
  };

  const DB_NAME = 'localify-db-v1';
  let db;
  let navHistory = [];
  let navIndex = -1;

  function uid(prefix = 'id') { return prefix + '-' + crypto.randomUUID(); }
  function esc(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  async function imageFileToDataURL(file, maxSize=900){
    return new Promise((resolve,reject)=>{
      const fr=new FileReader();
      fr.onerror=()=>reject(fr.error||new Error('Could not read image'));
      fr.onload=()=>{
        const img=new Image();
        img.onerror=()=>reject(new Error('Invalid image'));
        img.onload=()=>{
          const scale=Math.min(1,maxSize/Math.max(img.naturalWidth||1,img.naturalHeight||1));
          const canvas=document.createElement('canvas');
          canvas.width=Math.max(1,Math.round((img.naturalWidth||1)*scale));
          canvas.height=Math.max(1,Math.round((img.naturalHeight||1)*scale));
          canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
          resolve(canvas.toDataURL('image/webp',0.88));
        };
        img.src=fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  function fmtTime(sec) { if (!Number.isFinite(sec) || sec < 0) return '0:00'; const s = Math.floor(sec % 60).toString().padStart(2,'0'); const m = Math.floor(sec / 60); const h = Math.floor(m / 60); return h ? `${h}:${String(m % 60).padStart(2,'0')}:${s}` : `${m}:${s}`; }
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast._timer); toast._timer=setTimeout(()=>t.classList.remove('show'),2200); }

  let contextMenu;
  function closeContextMenu(){ if(contextMenu){contextMenu.remove();contextMenu=null;} }
  function showContextMenu(x,y,id){
    closeContextMenu(); const s=state.library.find(v=>v.id===id); if(!s)return;
    contextMenu=document.createElement('div'); contextMenu.className='context-menu';
    const items=[
      ['Play now',()=>playById(id)],
      ['Play next',()=>enqueue(id,true)],
      ['Add to queue',()=>enqueue(id,false)],
      ['Add to playlist',()=>openAddToPlaylistModal(id)],
      [state.favorites.has(id)?'Remove from favorites':'Add to favorites',()=>toggleFavorite(id)]
    ];
    if(state.view==='playlist' && state.playlistId){items.push(['Remove from this playlist',()=>removeFromPlaylist(state.playlistId,id)]);}
    contextMenu.innerHTML=items.map((it,i)=>`<button data-cmi="${i}">${esc(it[0])}</button>`).join('');
    contextMenu.style.left=Math.min(x,window.innerWidth-220)+'px'; contextMenu.style.top=Math.min(y,window.innerHeight-260)+'px';
    document.body.appendChild(contextMenu);
    $$('#contextMenuDummy');
    contextMenu.querySelectorAll('[data-cmi]').forEach(b=>b.addEventListener('click',()=>{const it=items[Number(b.dataset.cmi)];closeContextMenu();it[1]();}));
  }
  document.addEventListener('contextmenu',e=>{const item=e.target.closest('.song-row,.card');if(!item)return;e.preventDefault();showContextMenu(e.clientX,e.clientY,item.dataset.songId);});
  document.addEventListener('click',e=>{if(contextMenu&&!e.target.closest('.context-menu'))closeContextMenu();});

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains('config')) d.createObjectStore('config');
        if (!d.objectStoreNames.contains('songs')) d.createObjectStore('songs', {keyPath:'id'});
        if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', {keyPath:'id'});
      };
      req.onsuccess = () => { db=req.result; state.dbReady=true; resolve(db); };
      req.onerror = () => reject(req.error);
    });
  }
  function dbGet(store,key){return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
  function dbPut(store,val,key){return new Promise((res,rej)=>{const r=db.transaction(store,'readwrite').objectStore(store).put(val,key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
  function dbDelete(store,key){return new Promise((res,rej)=>{const r=db.transaction(store,'readwrite').objectStore(store).delete(key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
  function dbGetAll(store){return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error);});}

  async function loadPersistent() {
    await openDB();
    const cfg = await dbGet('config','state') || {};
    const songs = await dbGetAll('songs');
    const folders = await dbGetAll('folders');
    Object.assign(state, cfg, {library:songs, folders});
    state.favorites = new Set(cfg.favorites || []);
    state.playlists = Array.isArray(cfg.playlists) ? cfg.playlists : [];
    state.history = Array.isArray(cfg.history) ? cfg.history : [];
    state.currentId = cfg.currentId || null;
    state.queue = Array.isArray(cfg.queue) ? cfg.queue.filter(id=>songs.some(x=>x.id===id)) : [];
    state.queueIndex = Number.isInteger(cfg.queueIndex) ? cfg.queueIndex : (state.currentId && state.queue.includes(state.currentId) ? state.queue.indexOf(state.currentId) : -1);
    state.queueScrollTop = 0;
    state.volume = Number.isFinite(cfg.volume) ? cfg.volume : .8;
    state.previousVolume = state.volume || .8;
    state.autoFetchLyrics = cfg.autoFetchLyrics !== false;
    state.visualizerStyle = cfg.visualizerStyle || 'bars';
    state.appearance = Object.assign({preset:'lime',accent:'#9cff57',accent2:'#d7ffb9',background:'aurora',density:'comfortable',radius:'rounded',glass:true,sidebar:'wide',fontScale:1,artwork:'large',player:'bar',animated:true,focusLayout:'split',focusLyricsSize:'large',focusBackdrop:'artwork',focusArtScale:1,cinemaStyle:'random',cinemaBeat:'strong',cinemaBeatSensitivity:'medium',cinemaIntensity:1,cinemaTransition:'dynamic',accentGlow:'medium',sidebarCollapsed:false}, cfg.appearance || {});
    state.appearance.fontScale=Math.min(1,Math.max(.9,Number(state.appearance.fontScale)||.96));
    if(!cfg.appearance || Number(cfg.appearance.fontScale)>1) state.appearance.fontScale=.96;
    if(state.appearance.focusLayout==='cover') state.appearance.focusLayout='artwork';
    applyAppearance();
    if (state.repeat === true) state.repeat = 'all';
    $('#volume').value = state.volume;
    audio.volume = state.volume;
    if (state.currentId) {
      const s = state.library.find(x=>x.id===state.currentId);
      if (s) setNowPlayingUI(s, false);
    }
    renderSidebar();
    render();
  }

  let persistTimer;
  function persist() {
    clearTimeout(persistTimer);
    persistTimer=setTimeout(async()=>{
      if(!state.dbReady)return;
      const cfg={favorites:[...state.favorites],playlists:state.playlists,history:state.history.slice(0,100),queue:state.queue.slice(0,200),queueIndex:state.queueIndex,currentId:state.currentId,volume:state.volume,shuffle:state.shuffle,repeat:state.repeat,visualizer:state.visualizer,visualizerStyle:state.visualizerStyle,view:state.view,autoFetchLyrics:state.autoFetchLyrics,appearance:state.appearance};
      await dbPut('config',cfg,'state');
    },100);
  }


  const APPEARANCE_PRESETS = {
    lime:{name:'Lime',accent:'#9cff57',accent2:'#d7ffb9'},
    spotify:{name:'Spotify',accent:'#1ed760',accent2:'#a7f3c0'},
    ocean:{name:'Ocean',accent:'#59d7ff',accent2:'#bcefff'},
    violet:{name:'Violet',accent:'#b68cff',accent2:'#e0ceff'},
    sunset:{name:'Sunset',accent:'#ff9f68',accent2:'#ffd2bd'},
    rose:{name:'Rose',accent:'#ff6f9d',accent2:'#ffc3d6'},
    cyan:{name:'Cyber',accent:'#45f0d0',accent2:'#b8fff3'},
    mono:{name:'Mono',accent:'#f3f4f6',accent2:'#ffffff'}
  };
  function hexToRgb(hex){const h=String(hex||'').replace('#',''); if(h.length!==6)return null; const n=parseInt(h,16); return {r:(n>>16)&255,g:(n>>8)&255,b:n&255};}
  function applyAppearance(){
    const a=state.appearance||{}; const root=document.documentElement; const rgb=hexToRgb(a.accent);
    const accent=a.accent||'#9cff57'; const accent2=a.accent2||'#d7ffb9';
    root.style.setProperty('--accent',accent); root.style.setProperty('--accent-2',accent2);
    if(rgb) root.style.setProperty('--accent-rgb',`${rgb.r},${rgb.g},${rgb.b}`);
    root.style.setProperty('--font-scale',String(a.fontScale||1));
    const glowMap={subtle:.08,medium:.15,strong:.25};
    root.style.setProperty('--accent-glow',String(glowMap[a.accentGlow] ?? .15));
    document.body.dataset.theme=a.preset||'lime'; document.body.dataset.bg=a.background||'aurora'; document.body.dataset.density=a.density||'comfortable'; document.body.dataset.radius=a.radius||'rounded'; document.body.dataset.glass=String(a.glass!==false); document.body.dataset.sidebar=a.sidebar||'wide'; document.body.dataset.artwork=a.artwork||'large'; document.body.dataset.player=a.player||'bar'; document.body.dataset.animated=String(a.animated!==false); document.body.dataset.sidebarCollapsed=String(a.sidebarCollapsed===true); const sidebarToggle=$('#sidebarToggle'); if(sidebarToggle){const collapsed=a.sidebarCollapsed===true;sidebarToggle.textContent=collapsed?'›':'‹';sidebarToggle.title=collapsed?'Expand sidebar':'Collapse sidebar';sidebarToggle.setAttribute('aria-label',sidebarToggle.title);}
    const overlay=$('#focusOverlay'); if(overlay){ overlay.dataset.layout=a.focusLayout||'split'; overlay.dataset.backdrop=a.focusBackdrop||'artwork'; overlay.dataset.lyricsSize=a.focusLyricsSize||'large'; const stage=$('#focusStage'); if(stage){stage.dataset.layout=a.focusLayout||'split';stage.dataset.lyricsSize=a.focusLyricsSize||'large';stage.dataset.cinemaStyle=a.cinemaStyle||'random';stage.style.setProperty('--focus-art-scale',String(a.focusArtScale||1));stage.style.setProperty('--cinema-intensity',String(a.cinemaIntensity||1));stage.style.setProperty('--cinema-beat-strength',String(a.cinemaBeat==='off'?0:a.cinemaBeat==='subtle'?.45:a.cinemaBeat==='strong'?1.35:1));} const label=$('#focusLayoutLabel'); if(label) label.textContent=({split:'Split view',lyrics:'Lyrics only',artwork:'Artwork only',cinema:'Cinema'}[a.focusLayout||'split']||'Split view'); }
  }
  function setAppearance(patch){state.appearance=Object.assign({},state.appearance,patch);if(patch.preset&&APPEARANCE_PRESETS[patch.preset]){const pr=APPEARANCE_PRESETS[patch.preset];state.appearance.accent=pr.accent;state.appearance.accent2=pr.accent2;}applyAppearance();persist();render();}

  function renderSidebar() {
    $$('.nav-btn[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===state.view));
    $('#playlistNav').innerHTML = state.playlists.length ? state.playlists.map(p=>`<button class="playlist-link ${state.view==='playlist'&&state.playlistId===p.id?'active':''}" data-playlist-id="${esc(p.id)}">${p.cover?`<img class="playlist-nav-cover" src="${p.cover}" alt="">`:'<span class="playlist-nav-cover placeholder">♫</span>'}<span class="playlist-link-label">${esc(p.name)}</span></button>`).join('') : '<div style="padding:10px 12px;color:#5f6470;font-size:12px">Create a playlist with ＋</div>';
  }

  function visibleSongs() {
    let list = [...state.library];
    if (state.view==='favorites') list = list.filter(s=>state.favorites.has(s.id));
    else if (state.view==='recent') list = state.history.map(id=>state.library.find(s=>s.id===id)).filter(Boolean);
    else if (state.view==='playlist') {
      const p=state.playlists.find(x=>x.id===state.playlistId);
      list=p ? p.songIds.map(id=>state.library.find(s=>s.id===id)).filter(Boolean) : [];
    }
    const q=state.search.trim().toLowerCase();
    if(q) list=list.filter(s=>[s.title,s.artist,s.album,s.path].some(v=>String(v||'').toLowerCase().includes(q)));
    const coll=(a,b)=>String(a||'').localeCompare(String(b||''),undefined,{numeric:true,sensitivity:'base'});
    if(state.sort==='title') list.sort((a,b)=>coll(a.title,b.title));
    else if(state.sort==='artist') list.sort((a,b)=>coll(a.artist,b.artist)||coll(a.title,b.title));
    else if(state.sort==='album') list.sort((a,b)=>coll(a.album,b.album)||coll(a.title,b.title));
    else list.sort((a,b)=>(b.addedAt||0)-(a.addedAt||0));
    return list;
  }

  function art(s, cls='song-art') { return `<div class="${cls}">${s?.art ? `<img src="${s.art}" alt="">` : '<span>♪</span>'}</div>`; }

  function songRow(s, index) {
    const liked=state.favorites.has(s.id);
    return `<tr class="song-row ${s.id===state.currentId?'playing':''}" data-song-id="${esc(s.id)}">
      <td><div class="title-cell">${art(s)}<div class="title-meta"><div class="title-main">${esc(s.title||s.name)}</div><div class="title-sub">${esc(s.artist||'Unknown artist')}</div></div></div></td>
      <td>${esc(s.album||'Unknown album')}</td><td>${esc(s.genre||'')}</td><td>${fmtTime(s.duration)}</td>
      <td><button class="heart-small ${liked?'liked':''}" data-fav-id="${esc(s.id)}" title="${liked?'Remove favorite':'Favorite'}">${liked?'♥':'♡'}</button><button class="more-small" data-menu-id="${esc(s.id)}" title="Track actions">⋯</button></td>
    </tr>`;
  }

  function songTable(list) {
    if (!list.length) return `<div class="empty"><div><div class="empty-icon">♫</div><h3>No songs here yet</h3><p>Scan a folder of MP3s and Localify will build your library automatically.</p><button class="btn primary" id="emptyAddFolder">Add Music Folder</button></div></div>`;
    return `<div class="table-wrap"><table class="song-table"><thead><tr><th>Title</th><th>Album</th><th>Genre</th><th>Time</th><th></th></tr></thead><tbody>${list.map(songRow).join('')}</tbody></table></div>`;
  }

  function homeView() {
    const recentAdded=[...state.library].sort((a,b)=>b.addedAt-a.addedAt).slice(0,6);
    const recentPlayed=state.history.map(id=>state.library.find(s=>s.id===id)).filter(Boolean).slice(0,6);
    const artists=new Set(state.library.map(s=>s.artist).filter(Boolean));
    const albums=new Set(state.library.map(s=>s.album).filter(Boolean));
    if(!state.library.length) return `<div class="hero"><div class="hero-art">♫</div><div><div class="hero-kicker">Local-first music player</div><h1>Your music. Your way.</h1><p>Play your saved MP3s with playlists, favourites, search, queue, history, album art and a full desktop-style player — no account, no streaming service, no uploads.</p><button class="btn primary" id="heroAddFolder">Add Music Folder</button></div></div>`;
    return `<div class="hero"><div class="hero-art">${recentAdded[0]?.art?`<img src="${recentAdded[0].art}" alt="">`:'♫'}</div><div><div class="hero-kicker">Welcome back</div><h1>Your library</h1><p>${state.library.length} songs ready to play. Everything is stored locally on this computer.</p><div class="hero-stats"><span><strong>${state.library.length}</strong> songs</span><span><strong>${artists.size}</strong> artists</span><span><strong>${albums.size}</strong> albums</span><span><strong>${state.playlists.length}</strong> playlists</span></div></div></div>
      <section class="section"><div class="section-title-row"><h2>Recently added</h2><button class="section-link" id="showLibraryBtn">Show all</button></div><div class="cards">${recentAdded.map(card).join('')}</div></section>
      ${recentPlayed.length?`<section class="section"><div class="section-title-row"><h2>Recently played</h2><button class="section-link" id="showRecentBtn">Open history</button></div><div class="cards">${recentPlayed.map(card).join('')}</div></section>`:''}
      <section class="section"><div class="section-title-row"><h2>All songs</h2><button class="section-link" id="playAllBtn">Play all</button></div>${songTable(state.library.slice(0,12))}</section>`;
  }
  function card(s){return `<div class="card" data-song-id="${esc(s.id)}">${art(s,'card-art')}<div class="card-title">${esc(s.title)}</div><div class="card-sub">${esc(s.artist||'Unknown artist')}</div></div>`;}

  function libraryView() {
    const list=visibleSongs();
    return `<div class="view-head"><div><div class="eyebrow">Library</div><div class="view-title">Your Library</div><div class="view-subtitle">${list.length} visible tracks${state.search?` matching “${esc(state.search)}”`:''}</div></div><div class="actions"><select id="sortSelect" class="sort-select"><option value="added" ${state.sort==='added'?'selected':''}>Recently added</option><option value="title" ${state.sort==='title'?'selected':''}>Title</option><option value="artist" ${state.sort==='artist'?'selected':''}>Artist</option><option value="album" ${state.sort==='album'?'selected':''}>Album</option></select><button class="btn" id="rescanBtn">Rescan</button><button class="btn primary" id="playVisibleBtn">Play all</button></div></div>${songTable(list)}`;
  }
  function favoritesView(){ const list=visibleSongs(); return `<div class="view-head"><div><div class="eyebrow">Collection</div><div class="view-title">Favorites</div><div class="view-subtitle">Tracks you’ve starred.</div></div><div class="actions"><button class="btn primary" id="playVisibleBtn">Play all</button></div></div>${songTable(list)}`; }
  function recentView(){ const list=visibleSongs(); return `<div class="view-head"><div><div class="eyebrow">History</div><div class="view-title">Recently Played</div><div class="view-subtitle">Your most recently played tracks.</div></div><div class="actions"><button class="btn" id="clearHistoryBtn">Clear history</button><button class="btn primary" id="playVisibleBtn">Play all</button></div></div>${songTable(list)}`; }
  function playlistView(){ const p=state.playlists.find(x=>x.id===state.playlistId); const list=visibleSongs(); return `<div class="playlist-hero"><div class="playlist-hero-cover">${p?.cover?`<img src="${p.cover}" alt="">`:'<span>♫</span>'}</div><div class="playlist-hero-copy"><div class="eyebrow">Playlist</div><div class="view-title">${esc(p?.name||'Playlist')}</div><div class="view-subtitle">${list.length} tracks · ${esc(p?.description||'')}</div></div><div class="actions playlist-hero-actions"><button class="btn" id="editPlaylistBtn">Playlist settings</button><button class="btn primary" id="playVisibleBtn">Play all</button></div></div>${songTable(list)}`; }

  function render(){
    let html='';
    if(state.view==='home') html=homeView();
    else if(state.view==='library') html=libraryView();
    else if(state.view==='favorites') html=favoritesView();
    else if(state.view==='recent') html=recentView();
    else if(state.view==='playlist') html=playlistView();
    $('#mainView').innerHTML=html;
    renderSidebar();
    bindViewEvents();
  }

  function bindViewEvents(){
    $('#mainView').querySelectorAll('.song-row,.card').forEach(el=>el.addEventListener('click',e=>{ if(e.target.closest('button')) return; const id=el.dataset.songId; playById(id); }));
    $('#mainView').querySelectorAll('[data-fav-id]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();toggleFavorite(b.dataset.favId);}));
    $('#heroAddFolder')?.addEventListener('click', addFolder);
    $('#emptyAddFolder')?.addEventListener('click', addFolder);
    $('#showLibraryBtn')?.addEventListener('click',()=>navigate('library'));
    $('#showRecentBtn')?.addEventListener('click',()=>navigate('recent'));
    $('#playAllBtn')?.addEventListener('click',()=>playList(state.library.slice(0,12)));
    $('#rescanBtn')?.addEventListener('click',scanAllFolders);
    $('#playVisibleBtn')?.addEventListener('click',()=>playList(visibleSongs()));
    $('#clearHistoryBtn')?.addEventListener('click',()=>{state.history=[];persist();render();toast('Playback history cleared');});
    $('#editPlaylistBtn')?.addEventListener('click',()=>openPlaylistModal(state.playlistId));
    $('#sortSelect')?.addEventListener('change',e=>{state.sort=e.target.value;render();});
    $$('#mainView [data-menu-id]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const r=b.closest('[data-song-id]');const rect=b.getBoundingClientRect();showContextMenu(rect.left-180,rect.bottom+4,b.dataset.menuId);}));
  }

  function navigate(view, playlistId=null, record=true){
    state.view=view; state.playlistId=playlistId; if(record){navHistory=navHistory.slice(0,navIndex+1);navHistory.push({view,playlistId});navIndex=navHistory.length-1;} persist(); render();}

  async function addFolder(){
    if(window.showDirectoryPicker){
      try{
        const handle=await window.showDirectoryPicker({mode:'read'});
        const exists=state.folders.find(f=>f.name===handle.name && f.handle);
        if(exists){exists.handle=handle;await dbPut('folders',exists);toast('Folder permission refreshed');await scanFolder(exists);} else {
          const f={id:uid('folder'),name:handle.name,handle}; state.folders.push(f); await dbPut('folders',f); await scanFolder(f);
        }
      } catch(e){ if(e.name!=='AbortError') toast('Could not open that folder'); }
    } else $('#folderInput').click();
  }

  $('#folderInput').addEventListener('change', async e=>{
    const files=[...e.target.files].filter(f=>/\.mp3$/i.test(f.name));
    if(!files.length){toast('No MP3 files found');return;}
    const f={id:uid('legacy'),name:files[0].webkitRelativePath.split('/')[0]||'Imported folder',legacyFiles:files};
    state.folders.push(f); await scanLegacyFolder(f,files);
    e.target.value='';
  });

  async function scanLegacyFolder(folder,files){
    const lyricMap=new Map(files.filter(f=>/\.(lrc|txt)$/i.test(f.name)).map(f=>[normalizePath(f.webkitRelativePath||f.name),f]));
    let count=0;
    for(const file of files){
      if(!/\.(mp3|m4a|aac|wav|ogg|flac)$/i.test(file.name)) continue;
      const rel=file.webkitRelativePath||file.name;
      const base=stripExt(rel);
      const lyricFile=lyricMap.get(normalizePath(base+'.lrc')) || lyricMap.get(normalizePath(base+'.txt'));
      const lyricText=lyricFile?await lyricFile.text():null;
      const song=await parseFile(file,folder.id,rel,{text:lyricText,source:lyricFile?.name});
      await upsertSong(song); count++;
    }
    await finishScan(); toast(`Imported ${count} audio file${count===1?'':'s'}${lyricMap.size?' and detected lyrics where available':''}`); navigate('library');
  }

  async function scanFolder(folder){
    if(!folder.handle) return; toast(`Scanning ${folder.name}…`); let count=0; const seen=new Set();
    for await(const [name,handle] of folder.handle.entries()) count += await scanEntry(handle,[name],folder.id,seen,folder.handle);
    const existing=state.library.filter(s=>s.folderId===folder.id);
    for(const old of existing){if(!seen.has(old.id)){await dbDelete('songs',old.id);state.library=state.library.filter(x=>x.id!==old.id);}}
    await finishScan(); toast(`Scanned ${count} audio file${count===1?'':'s'}${count?' — lyrics detected automatically where present':''}`); navigate('library');
  }
  async function scanEntry(handle,parts,folderId,seen,rootHandle){
    if(handle.kind==='file'){
      if(!/\.(mp3|m4a|aac|wav|ogg|flac)$/i.test(handle.name)) return 0;
      try{
        const file=await handle.getFile();
        const rel=parts.join('/');
        const lyric=await readAdjacentLyrics(rootHandle,rel);
        const song=await parseFile(file,folderId,rel,lyric);
        await upsertSong(song); seen.add(song.id); return 1;
      }catch{return 0;}
    }
    let n=0; for await(const [name,ch] of handle.entries()) n+=await scanEntry(ch,[...parts,name],folderId,seen,rootHandle); return n;
  }
  async function scanAllFolders(){ if(!state.folders.length){addFolder();return;} for(const f of state.folders) if(f.handle) await scanFolder(f); }
  async function upsertSong(song){ const old=state.library.find(x=>x.id===song.id); if(old && !song.art) song.art=old.art; if(old && !song.lyrics && old.lyrics){song.lyrics=old.lyrics;song.lyricsSource=old.lyricsSource||'Manual';} if(old) song.addedAt=old.addedAt; await dbPut('songs',song); const idx=state.library.findIndex(x=>x.id===song.id); if(idx>=0)state.library[idx]=song;else state.library.push(song); }
  async function finishScan(){state.library=await dbGetAll('songs');persist();render();}

  async function parseFile(file,folderId,relativePath,lyricHint=null){
    const id=`${folderId}::${relativePath}`;
    const buf=await file.arrayBuffer();
    const tags=parseID3(buf);
    let duration=0;
    try { const url=URL.createObjectURL(file); const temp=new Audio(); temp.preload='metadata'; duration=await new Promise(resolve=>{ const done=()=>{cleanup();resolve(Number.isFinite(temp.duration)?temp.duration:0)}; const cleanup=()=>{temp.removeEventListener('loadedmetadata',done);temp.removeEventListener('error',done);URL.revokeObjectURL(url);}; temp.addEventListener('loadedmetadata',done,{once:true}); temp.addEventListener('error',done,{once:true}); temp.src=url;}); }catch{}
    const lyrics=lyricHint?.text || tags.lyrics || '';
    const bitrate=duration>0?Math.round((file.size*8/duration)/1000):0;
    return {id,folderId,path:relativePath,name:file.name,title:tags.title||stripExt(file.name),artist:tags.artist||'Unknown artist',album:tags.album||'Unknown album',genre:tags.genre||'',year:tags.year||'',duration,size:file.size,lastModified:file.lastModified,bitrate,replayGainDb:tags.replayGainDb ?? null,addedAt:Date.now(),art:tags.art||null,lyrics,lyricsSource:lyricHint?.source || (tags.lyrics?'Embedded ID3':'')};
  }

  function normalizePath(p){return String(p||'').replaceAll('\\','/').replace(/^\//,'').toLowerCase();}

  async function readAdjacentLyrics(rootHandle,relativePath){
    try{
      const parts=relativePath.split('/'); const name=parts.pop(); const dirParts=parts;
      let dir=rootHandle; for(const part of dirParts) dir=await dir.getDirectoryHandle(part);
      const base=stripExt(name);
      for(const ext of ['.lrc','.LRC','.txt','.TXT']){
        try{const h=await dir.getFileHandle(base+ext); const f=await h.getFile(); return {text:await f.text(),source:f.name};}catch{}
      }
    }catch{}
    return null;
  }

  function stripExt(n){return n.replace(/\.[^/.]+$/,'');}
  function readSynchsafe(b,o){return (b[o]<<21)|(b[o+1]<<14)|(b[o+2]<<7)|b[o+3];}
  function textDecode(bytes){
    try{ if(bytes.length&&bytes[0]===1) return new TextDecoder('utf-16').decode(bytes.slice(1)).replace(/\u0000/g,'').trim(); if(bytes.length&&bytes[0]===2) return new TextDecoder('utf-16be').decode(bytes.slice(1)).replace(/\u0000/g,'').trim(); return new TextDecoder('utf-8').decode(bytes).replace(/\u0000/g,'').trim(); }catch{return new TextDecoder().decode(bytes).replace(/\u0000/g,'').trim();}
  }
  function findTerm(bytes,start,enc){ for(let i=start;i<bytes.length;i++){ if(bytes[i]===0) return i; if(enc===1&&i+1<bytes.length&&bytes[i]===0&&bytes[i+1]===0)return i; }return bytes.length; }
  function parseID3(buf){
    const bytes=new Uint8Array(buf); const out={}; if(bytes.length>=10&&String.fromCharCode(...bytes.slice(0,3))==='ID3'){
      const ver=bytes[3], tagSize=readSynchsafe(bytes,6); let p=10, end=Math.min(bytes.length,10+tagSize);
      while(p+10<=end){ const id=String.fromCharCode(...bytes.slice(p,p+4)); let size=ver>=4?readSynchsafe(bytes,p+4):((bytes[p+4]<<24)|(bytes[p+5]<<16)|(bytes[p+6]<<8)|bytes[p+7]); if(!id.trim()||size<=0){p+=1;continue;} const d=bytes.slice(p+10,p+10+size); if(/^T/.test(id)&&id!=='TXXX'){ const val=textDecode(d.slice(0)); if(id==='TIT2')out.title=val; if(id==='TPE1')out.artist=val; if(id==='TALB')out.album=val; if(id==='TCON')out.genre=val; if(id==='TYER'||id==='TDRC')out.year=val; } else if(id==='USLT'){ try{ const enc=d[0]||3; let q=1; while(q<d.length&&d[q]!==0)q++; q++; const payload=d.slice(q); out.lyrics=textDecode(payload); }catch{} } else if(id==='TXXX'){ try{ const val=textDecode(d.slice(1)); if(/lyrics/i.test(val)) out.lyrics=val; const rg=String(val).match(/(?:REPLAYGAIN_TRACK_GAIN|replaygain_track_gain)\s*[:=]\s*([+-]?\d+(?:\.\d+)?)\s*dB/i); if(rg) out.replayGainDb=Number(rg[1]); }catch{} } else if(id==='APIC'){ try{ const enc=d[0]||0; let q=1; const mimeStart=q; while(q<d.length&&d[q]!==0)q++; const mime=new TextDecoder().decode(d.slice(mimeStart,q)); q++; if(q>=d.length) throw new Error('bad APIC'); q++; if(enc===1||enc===2){while(q+1<d.length){if(d[q]===0&&d[q+1]===0){q+=2;break;}q++;}}else{while(q<d.length&&d[q]!==0)q++;q++;} const payload=d.slice(q); if(payload.byteLength>0&&payload.byteLength<600000){const bin=[...payload].map(x=>String.fromCharCode(x)).join('');out.art=`data:${mime||'image/jpeg'};base64,${btoa(bin)}`;}}catch{} }
      p+=10+size;
      }
    }
    // ID3v1 fallback
    if(bytes.length>=128){const start=bytes.length-128;if(String.fromCharCode(...bytes.slice(start,start+3))==='TAG'){const dec=(arr)=>new TextDecoder('latin1').decode(arr).replace(/\u0000/g,'').trim();out.title ||= dec(bytes.slice(start+3,start+33));out.artist ||= dec(bytes.slice(start+33,start+63));out.album ||= dec(bytes.slice(start+63,start+93));out.year ||= dec(bytes.slice(start+93,start+97));}}
    return out;
  }

  async function getFileForSong(song){
    const folder=state.folders.find(f=>f.id===song.folderId);
    if(folder?.handle){ let h=folder.handle; for(const part of song.path.split('/'))h=await h.getFileHandle(part); return h.getFile(); }
    if(folder?.legacyFiles) return folder.legacyFiles.find(f=>(f.webkitRelativePath||f.name).endsWith(song.path));
    throw new Error('Folder unavailable');
  }

  let lyricsRequestChain = Promise.resolve();
  const lyricsInFlight = new Map();
  function delay(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
  function queueLyricsRequest(fn){
    const run=lyricsRequestChain.then(fn,fn);
    lyricsRequestChain=run.catch(()=>{});
    return run;
  }
  function lyricsQuery(song){
    const q=new URLSearchParams();
    q.set('track_name',song.title||'');
    q.set('artist_name',song.artist||'');
    if(song.album && song.album!=='Unknown album') q.set('album_name',song.album);
    if(Number(song.duration)>0) q.set('duration',String(Math.round(song.duration)));
    return q.toString();
  }
  async function fetchLyricsOnline(song, force=false){
    if(!song || (!force && song.lyrics)) return false;
    if(!force && song.lyricsCheckedAt && Date.now()-song.lyricsCheckedAt < 7*24*60*60*1000) return false;
    if(!song.title) return false;
    if(lyricsInFlight.has(song.id)) return lyricsInFlight.get(song.id);
    const request=queueLyricsRequest(async()=>{
      if(!force && song.lyrics) return true;
      try{
        if(state.currentId===song.id) setLyricsStatus('Finding lyrics online…');
        await delay(300);
        let res=await fetch(`https://lrclib.net/api/get?${lyricsQuery(song)}`,{headers:{'X-User-Agent':'Localify/1.0 (local music player)'}});
        if(res.status===404){
          await delay(300);
          const q=new URLSearchParams({track_name:song.title,artist_name:song.artist});
          res=await fetch(`https://lrclib.net/api/get?${q.toString()}`,{headers:{'X-User-Agent':'Localify/1.0 (local music player)'}});
        }
        if(res.status===404){
          await delay(300);
          const broad=new URLSearchParams({q:[song.title,song.artist!=='Unknown artist'?song.artist:''].filter(Boolean).join(' '),track_name:song.title});
          res=await fetch(`https://lrclib.net/api/search?${broad.toString()}`,{headers:{'X-User-Agent':'Localify/1.0 (local music player)'}});
          if(res.ok){
            const results=await res.json();
            const wantedArtist=String(song.artist||'').toLowerCase();
            const wantedDuration=Number(song.duration)||0;
            const ranked=(Array.isArray(results)?results:[]).filter(x=>x && (x.syncedLyrics||x.plainLyrics)).sort((a,b)=>{
              const score=x=>{let n=0;const art=String(x.artistName||'').toLowerCase();const title=String(x.trackName||'').toLowerCase();const dur=Number(x.duration)||0;if(title===String(song.title).toLowerCase())n+=8;if(wantedArtist&&wantedArtist!=='unknown artist'&&art===wantedArtist)n+=8;if(wantedDuration&&Math.abs(dur-wantedDuration)<=2)n+=6;if(song.album&&song.album!=='Unknown album'&&String(x.albumName||'').toLowerCase()===String(song.album).toLowerCase())n+=3;return n;};return score(b)-score(a);});
            if(ranked[0]) res=new Response(JSON.stringify(ranked[0]),{status:200});
            else res=new Response('{}',{status:404});
          }
        }
        if(res.status===404){
          song.lyricsCheckedAt=Date.now();
          song.lyricsSource='No online match';
          await dbPut('songs',song); persist();
          if(state.currentId===song.id){renderLyricsPanel(song);if(state.focusOpen)renderFocusOverlay(song);}
          return false;
        }
        if(!res.ok) throw new Error(`Lyrics service returned ${res.status}`);
        const data=await res.json();
        const text=data.syncedLyrics || data.plainLyrics || '';
        song.lyrics=text;
        song.lyricsSource=data.syncedLyrics ? 'LRCLIB · synced' : 'LRCLIB · plain';
        song.lyricsCheckedAt=Date.now();
        song.lyricsProviderId=data.id||null;
        await dbPut('songs',song);
        const idx=state.library.findIndex(x=>x.id===song.id); if(idx>=0)state.library[idx]=song;
        persist();
        if(state.currentId===song.id){renderLyricsPanel(song);if(state.focusOpen)renderFocusOverlay(song);toast(data.syncedLyrics?'Synced lyrics found':'Lyrics found');}
        return true;
      }catch(err){
        console.warn('Automatic lyrics lookup failed',err);
        if(state.currentId===song.id) setLyricsStatus('Could not reach the lyrics service.');
        return false;
      }
    });
    lyricsInFlight.set(song.id,request);
    request.finally(()=>lyricsInFlight.delete(song.id));
    return request;
  }
  function setLyricsStatus(text){
    const source=$('#lyricsSource'); if(source) source.textContent=text;
    const meta=$('#lyricsMeta'); if(meta && state.currentId){ const s=state.library.find(x=>x.id===state.currentId); if(s) meta.textContent=`${s.title} · ${s.artist}`; }
  }
  function maybeAutoFetchLyrics(song){
    if(state.autoFetchLyrics && song && !song.lyrics) fetchLyricsOnline(song).catch(()=>{});
  }

  function updateRows(){ $$('.song-row').forEach(r=>r.classList.toggle('playing',r.dataset.songId===state.currentId)); }
  function updateQueueRows(){
    $$('#queueList .queue-row').forEach(r=>r.classList.toggle('playing',r.dataset.qid===state.currentId));
  }

  async function playById(id,preserveQueue=false){
    const s=state.library.find(x=>x.id===id); if(!s)return;
    if(preserveQueue && state.queue.includes(id)) state.queueIndex=state.queue.indexOf(id);
    if(!preserveQueue && state.queue.length && !state.queue.includes(id)){state.queue=[];state.queueIndex=-1;state.queueScrollTop=0;renderQueue('queue',false);}
    try{
      const file=await getFileForSong(s);
      if(state.audioObjectUrl)URL.revokeObjectURL(state.audioObjectUrl);
      state.audioObjectUrl=URL.createObjectURL(file);
      audio.src=state.audioObjectUrl;
      state.currentId=id;
      setNowPlayingUI(s,true);
      if(state.focusOpen) renderFocusOverlay(s);
      addToHistory(id);
      persist();
      await audio.play();
      updateRows();
      updateQueueRows();
      maybeAutoFetchLyrics(s);
    }catch(e){toast('That music folder is no longer available. Use Settings to refresh it.');}
  }

  function setNowPlayingUI(s,playing=true){$('#nowTitle').textContent=s?.title||'Nothing playing';$('#nowArtist').textContent=s?.artist||'Add a music folder to get started';$('#miniArt').innerHTML=s?.art?`<img src="${s.art}" alt="">`:'<span>♪</span>'; $('#likeBtn').classList.toggle('liked',state.favorites.has(s?.id)); $('#likeBtn').textContent=state.favorites.has(s?.id)?'♥':'♡'; $('#playBtn').textContent=playing&&!audio.paused?'❚❚':'▶'; if(state.lyricsOpen)renderLyricsPanel(s);}
  function addToHistory(id){state.history=[id,...state.history.filter(x=>x!==id)].slice(0,100);}
  function playList(list){if(!list.length){toast('There are no songs to play');return;}state.queue=list.map(s=>s.id);state.queueIndex=0;state.queueScrollTop=0;if(state.shuffle)state.queue=shuffleIds(state.queue);persist();playById(state.queue[0],true);renderQueue('queue',false);}
  function enqueue(id,next=false){state.queue=state.queue.filter(x=>x!==id);if(next){let pos=Math.max(0,state.queueIndex+1);state.queue.splice(pos,0,id);}else state.queue.push(id);persist();renderQueue('queue',true);toast(next?'Added to play next':'Added to queue');}
  function shuffleIds(arr){const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

  // Lyrics scrolling: playback keeps the active line updated, while manual scrolling
  // temporarily pauses auto-follow. A timer (or the explicit sync button) returns to current.
  const lyricsScrollState = {
    regular: {manual:false,resumeTimer:null,suppressUntil:0},
    focus: {manual:false,resumeTimer:null,suppressUntil:0}
  };
  function showFocusSyncButton(show){
    const btn=$('#focusSyncBtn');
    if(btn) btn.classList.toggle('hidden',!show);
  }
  function lyricsScrollActivity(kind){
    const stateRef=lyricsScrollState[kind];
    stateRef.manual=true;
    clearTimeout(stateRef.resumeTimer);
    stateRef.resumeTimer=setTimeout(()=>{
      stateRef.manual=false;
      if(kind==='focus') syncFocusLyrics(true);
      else syncLyrics(true);
    },1800);
    if(kind==='focus') showFocusSyncButton(true);
  }
  function markProgrammaticLyricsScroll(kind){
    lyricsScrollState[kind].suppressUntil=Date.now()+1400;
  }
  function lyricAutoScroll(kind,container,element,force=false){
    const stateRef=lyricsScrollState[kind];
    if(!container||!element||(!force&&stateRef.manual)) return;
    const target=element.offsetTop-(container.clientHeight/2)+(element.offsetHeight/2);
    const max=Math.max(0,container.scrollHeight-container.clientHeight);
    const clamped=Math.max(0,Math.min(max,target));
    const distance=Math.abs(container.scrollTop-clamped);
    if(force || distance>28){
      markProgrammaticLyricsScroll(kind);
      container.scrollTo({top:clamped,behavior:'smooth'});
    }
  }
  function syncBackToCurrent(kind){
    const stateRef=lyricsScrollState[kind];
    stateRef.manual=false;
    clearTimeout(stateRef.resumeTimer);
    stateRef.resumeTimer=null;
    if(kind==='focus'){
      showFocusSyncButton(false);
      syncFocusLyrics(true);
    }else{
      syncLyrics(true);
    }
  }
  function setupLyricsScrollListeners(){
    const regularBody=$('#lyricsBody');
    const focusBody=$('#focusLyricsBody');
    if(regularBody&&!regularBody.dataset.scrollBound){
      regularBody.dataset.scrollBound='1';
      regularBody.addEventListener('wheel',()=>lyricsScrollActivity('regular'),{passive:true});
      regularBody.addEventListener('touchstart',()=>lyricsScrollActivity('regular'),{passive:true});
      regularBody.addEventListener('scroll',()=>{
        if(Date.now()>lyricsScrollState.regular.suppressUntil) lyricsScrollActivity('regular');
      },{passive:true});
    }
    if(focusBody&&!focusBody.dataset.scrollBound){
      focusBody.dataset.scrollBound='1';
      focusBody.addEventListener('wheel',()=>lyricsScrollActivity('focus'),{passive:true});
      focusBody.addEventListener('touchstart',()=>lyricsScrollActivity('focus'),{passive:true});
      focusBody.addEventListener('pointerdown',()=>lyricsScrollActivity('focus'),{passive:true});
      focusBody.addEventListener('scroll',()=>{
        if(Date.now()>lyricsScrollState.focus.suppressUntil) lyricsScrollActivity('focus');
      },{passive:true});
    }
  }
  function resetLyricsScroll(kind,hideButton=true){
    const stateRef=lyricsScrollState[kind];
    stateRef.manual=false;
    stateRef.suppressUntil=0;
    clearTimeout(stateRef.resumeTimer);
    stateRef.resumeTimer=null;
    if(kind==='focus'&&hideButton) showFocusSyncButton(false);
  }

  function parseLyrics(raw){
    const text=String(raw||'').replace(/\r/g,'');
    const lines=[];
    for(const source of text.split('\n')){
      const stamps=[...source.matchAll(/\[(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g)];
      const lyric=source.replace(/\[(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g,'').trim();
      if(stamps.length){ for(const m of stamps){ const hours=Number(m[1]||0), minutes=Number(m[2]||0), seconds=Number(m[3]||0), fraction=Number((m[4]||'0').padEnd(3,'0'))/1000; lines.push({time:hours*3600+minutes*60+seconds+fraction,text:lyric}); } }
      else if(source.trim() && !/^\[(ar|ti|al|by|offset|length|re)\s*:/i.test(source.trim())) lines.push({time:null,text:source.trim()});
    }
    lines.sort((a,b)=>(a.time==null?Infinity:a.time)-(b.time==null?Infinity:b.time));
    return {lines,synced:lines.some(x=>x.time!=null)};
  }
  function getSongLyrics(song){return song?.lyrics ? parseLyrics(song.lyrics) : {lines:[],synced:false};}
  function renderLyricsPanel(song){
    const body=$('#lyricsBody'), meta=$('#lyricsMeta'), source=$('#lyricsSource');
    $('#lyricsBtn').classList.toggle('active',state.lyricsOpen);
    if(!song){meta.textContent='Select a song to see lyrics';source.textContent='';body.innerHTML='<div class=\"lyrics-empty\"><div class=\"empty-icon\">♫</div><h3>No lyrics loaded</h3><p>Start playing a song to open its lyrics.</p></div>';return;}
    meta.textContent=`${song.title} · ${song.artist}`;
    source.textContent=song.lyricsSource ? `Source: ${song.lyricsSource}` : 'Looking for lyrics automatically…';
    const parsed=getSongLyrics(song);
    const fetchBtn=$('#fetchLyricsBtn');
    if(fetchBtn){fetchBtn.textContent=song.lyrics?'Refresh online lyrics':'Find lyrics online';fetchBtn.classList.toggle('primary',!song.lyrics);fetchBtn.onclick=()=>fetchLyricsOnline(song,true);}
    if(!parsed.lines.length){
      body.innerHTML='<div class=\"lyrics-empty\"><div class=\"empty-icon\">♫</div><h3>No lyrics loaded</h3><p>Localify can automatically search for this song online using its title, artist, album and duration.</p><button class=\"btn small primary\" id=\"fetchLyricsEmptyBtn\">Find lyrics online</button></div>';
      $('#fetchLyricsEmptyBtn').addEventListener('click',()=>fetchLyricsOnline(song,true));
      if(state.autoFetchLyrics)fetchLyricsOnline(song).catch(()=>{});
      setupLyricsScrollListeners();
      return;
    }
    body.innerHTML=`<div class=\"lyrics-lines ${parsed.synced?'synced':''}">${parsed.lines.map((line,i)=>`<button class=\"lyric-line\" data-lyric-index=\"${i}\" ${line.time!=null?`data-lyric-time=\"${line.time}\"`:''}>${esc(line.text||'♪')}</button>`).join('')}</div>`;
    $$('#lyricsBody .lyric-line').forEach(b=>b.addEventListener('click',()=>{const t=Number(b.dataset.lyricTime);if(Number.isFinite(t)){audio.currentTime=t;audio.play().catch(()=>{});resetLyricsScroll('regular');}}));
    setupLyricsScrollListeners();
    syncLyrics(true);
  }
  function syncLyrics(force=false){
    const focusNeedsSync=state.focusOpen;
    if(!state.lyricsOpen && !focusNeedsSync) return;
    const song=state.library.find(s=>s.id===state.currentId);
    if(!song){if(focusNeedsSync)syncFocusLyrics(force);return;}
    const parsed=getSongLyrics(song);
    if(state.lyricsOpen && parsed.synced){
      let active=-1;
      const now=audio.currentTime;
      parsed.lines.forEach((line,i)=>{if(line.time!=null&&line.time<=now)active=i;});
      const els=$$('#lyricsBody .lyric-line');
      els.forEach((el,i)=>el.classList.toggle('active',i===active));
      const current=active>=0?els[active]:null;
      if(current) lyricAutoScroll('regular',$('#lyricsBody'),current,force);
    }
    if(focusNeedsSync) syncFocusLyrics(force);
  }
  function renderFocusOverlay(song){
    const overlay=$('#focusOverlay');
    if(!overlay)return;
    const stage=$('#focusStage');
    const artBox=$('#focusArt');
    const title=$('#focusTitle');
    const artist=$('#focusArtist');
    const artTitle=$('#focusArtTitle');
    const album=$('#focusArtAlbum');
    const body=$('#focusLyricsBody');
    overlay.classList.toggle('hidden',!state.focusOpen);
    overlay.setAttribute('aria-hidden',String(!state.focusOpen));
    if(!song){
      title.textContent='Nothing playing';
      artist.textContent='Choose a song';
      artTitle.textContent='';
      album.textContent='';
      artBox.innerHTML='<span>♪</span>';
      body.innerHTML='<div class=\"focus-empty\">Play a track to see lyrics.</div>';
      return;
    }
    const layout=state.appearance.focusLayout||'split';
    const backdrop=state.appearance.focusBackdrop||'artwork';
    const lyricsSize=state.appearance.focusLyricsSize||'large';
    overlay.dataset.layout=layout;
    overlay.dataset.backdrop=backdrop;
    overlay.dataset.lyricsSize=lyricsSize;
    stage.dataset.layout=layout;
    stage.dataset.lyricsSize=lyricsSize;
    stage.style.setProperty('--focus-art-scale',String(state.appearance.focusArtScale||1));
    const layoutNames={split:'Split view',lyrics:'Lyrics only',artwork:'Artwork only',cinema:'Cinema'};
    const layoutLabel=$('#focusLayoutLabel');
    if(layoutLabel)layoutLabel.textContent=layoutNames[layout]||'Split view';
    title.textContent=song.title||song.name||'Unknown title';
    artist.textContent=song.artist||'Unknown artist';
    artTitle.textContent=song.title||'';
    album.textContent=song.album&&song.album!=='Unknown album'?song.album:'';
    artBox.innerHTML=song.art?`<img src=\"${song.art}\" alt=\"\">`:'<span>♪</span>';
    if(song.art)overlay.style.setProperty('--focus-bg-image',`url(\"${song.art}\")`);
    else overlay.style.removeProperty('--focus-bg-image');
    const parsed=getSongLyrics(song);
    if(!parsed.lines.length){
      body.innerHTML='<div class=\"focus-empty\"><div class=\"empty-icon\">♫</div><h3>No lyrics yet</h3><p>Localify will keep looking automatically when online lyrics are enabled.</p><button class=\"btn small primary\" id=\"focusFindLyricsBtn\">Find lyrics online</button></div>';
      $('#focusFindLyricsBtn').addEventListener('click',()=>fetchLyricsOnline(song,true));
      setupLyricsScrollListeners();
      return;
    }
    if(layout==='cinema') renderCinemaLyrics(parsed);
    else body.innerHTML=`<div class=\"focus-lyrics-lines ${parsed.synced?'synced':''}">${parsed.lines.map((line,i)=>`<button class=\"focus-lyric-line\" data-focus-lyric-index=\"${i}\" ${line.time!=null?`data-lyric-time=\"${line.time}\"`:''}>${esc(line.text||'♪')}</button>`).join('')}</div>`;
    $$('#focusLyricsBody .focus-lyric-line, #focusLyricsBody .cinema-lyric-line').forEach(b=>b.addEventListener('click',()=>{
      const t=Number(b.dataset.lyricTime);
      if(Number.isFinite(t)){audio.currentTime=t;audio.play().catch(()=>{});resetLyricsScroll('focus');syncFocusLyrics(true);}
    }));
    setupLyricsScrollListeners();
    syncFocusLyrics(true);
  }
  function renderCinemaLyrics(parsed){
    const body=$('#focusLyricsBody'); if(!body)return;
    const styles=['scatter','pop','slide','slam','float','wave','flip','blur','zoom','rotate','type','drift','bounce','glitch','elastic','orbit','radial','jitter','stretch','neon','pulse','split','rise','fall','spiral','snap','swing','topDrop','bottomRise','leftRush','rightRush','diagonal','verticalFlip','pendulum','cardTurn','corkscrew','tunnel','gravity','sideSwipe','centerBurst','edgeFloat','stackRise','stackFall','waveVertical','skate','swoop','whiplash','magnet','flicker','cascade'];
    const configured=state.appearance.cinemaStyle||'random';
    const intensity=Math.max(.55,Math.min(1.55,Number(state.appearance.cinemaIntensity||1)));
    const transition=state.appearance.cinemaTransition||'dynamic';
    const shuffledStyles=styles.slice().sort(()=>Math.random()-.5);
    const pickStyle=(lineIndex)=>{
      if(configured!=='random') return configured;
      // A different style per lyric line gives Cinema a much less repetitive edit-like feel.
      return shuffledStyles[lineIndex % shuffledStyles.length];
    };
    const words=(text)=>String(text||'♪').trim().split(/\s+/).map((word,idx)=>{
      const angle=Math.random()*360;
      const distance=(50+Math.random()*135)*intensity;
      const x=Math.cos(angle*Math.PI/180)*distance;
      const y=Math.sin(angle*Math.PI/180)*distance;
      const sx=(Math.random()>.5?1:-1)*(70+Math.random()*90)*intensity;
      const wy=(Math.random()>.5?1:-1)*(8+Math.random()*22)*intensity;
      const fx=(Math.random()>.5?1:-1)*(18+Math.random()*55)*intensity;
      const cr=(Math.random()*28-14).toFixed(1);
      const big=(Math.random()*70-35).toFixed(1);
      const dx=(Math.random()>.5?1:-1)*(30+Math.random()*85)*intensity;
      const dy=(Math.random()>.5?1:-1)*(18+Math.random()*55)*intensity;
      const sc=(0.72+Math.random()*0.45).toFixed(2);
      const d=(idx*0.026 + Math.random()*0.12).toFixed(2);
      const hue=(Math.random()*40-20).toFixed(1);
      const landX=(Math.random()*44-22)*intensity;
      const landY=(Math.random()*32-16)*intensity;
      const depth=(0.78+Math.random()*0.42).toFixed(2);
      const beatFactor=(0.55+Math.random()*0.85).toFixed(2);
      const phase=(Math.random()*360).toFixed(0);
      const axis=Math.random()>.5?'x':'y';
      return `<span class="cinema-word" style="--cx:${x.toFixed(0)}px;--cy:${y.toFixed(0)}px;--sx:${sx.toFixed(0)}px;--wy:${wy.toFixed(0)}px;--fx:${fx.toFixed(0)}px;--cr:${cr}deg;--cr-big:${big}deg;--dx:${dx.toFixed(0)}px;--dy:${dy.toFixed(0)}px;--cs:${sc};--skew:${(Math.random()*18-9).toFixed(1)}deg;--delay:${d}s;--hue:${hue}deg;--land-x:${landX.toFixed(0)}px;--land-y:${landY.toFixed(0)}px;--depth:${depth};--beat-factor:${beatFactor};--phase:${phase}deg;--axis:${axis}"><span class="cinema-word-inner">${esc(word)}</span></span>`;
    }).join(' ');
    const linesHtml=parsed.lines.map((line,i)=>{
      const len=(line.text||'').trim().length;
      const density=len>92?'very-dense':len>58?'dense':'';
      const lineStyle=pickStyle(i);
      return `<button class="cinema-lyric-line ${density}" data-cinema-animation="${lineStyle}" data-cinema-index="${i}" ${line.time!=null?`data-lyric-time="${line.time}"`:''}>${words(line.text||'♪')}</button>`;
    }).join('');
    body.innerHTML=`<div class="cinema-lyrics-stage ${parsed.synced?'synced':''}" data-cinema-style="${configured}" data-cinema-transition="${transition}" style="--cinema-intensity:${intensity}"><div class="cinema-beat-orb cinema-beat-orb-a"></div><div class="cinema-beat-orb cinema-beat-orb-b"></div>${linesHtml}</div>`;
    showFocusSyncButton(false);
  }

  function syncFocusLyrics(force=false){
    if(!state.focusOpen)return;
    const song=state.library.find(s=>s.id===state.currentId);
    if(!song)return;
    const parsed=getSongLyrics(song);
    if(!parsed.synced)return;
    let active=-1;
    const now=audio.currentTime;
    parsed.lines.forEach((line,i)=>{if(line.time!=null&&line.time<=now)active=i;});
    const cinema=state.appearance.focusLayout==='cinema';
    const els=cinema?$$('#focusLyricsBody .cinema-lyric-line'):$$('#focusLyricsBody .focus-lyric-line');
    const prev=$('#focusLyricsBody')?.dataset.activeCinemaIndex;
    els.forEach((el,i)=>el.classList.toggle('active',i===active));
    if(cinema){
      if(active>=0 && (force || String(active)!==String(prev))){
        $('#focusLyricsBody').dataset.activeCinemaIndex=String(active);
        const stage=$('#focusLyricsBody .cinema-lyrics-stage');
        if(stage){ stage.dataset.animationTick=String(Date.now()); }
      }
      return;
    }
    const current=active>=0?els[active]:null;
    if(current) lyricAutoScroll('focus',$('#focusLyricsBody'),current,force);
  }
  async function toggleFocus(next=undefined){
    const open = next === undefined ? !state.focusOpen : Boolean(next);
    const overlay = $('#focusOverlay');
    if(!overlay) return false;

    if(open){
      // Focus mode owns the screen: close the regular lyrics/queue panels first.
      state.focusOpen = true;
      state.lyricsOpen = false;
      resetLyricsScroll('regular');
      resetLyricsScroll('focus');
      $('#lyricsPanel')?.classList.add('hidden');
      $('#lyricsBtn')?.classList.remove('active');
      $('#queuePanel')?.classList.add('hidden');
      renderFocusOverlay(state.library.find(s=>s.id===state.currentId));
      setupLyricsScrollListeners();
      return true;
    }

    state.focusOpen = false;
    resetLyricsScroll('focus');
    // Exit browser fullscreen when closing focus mode, but don't let a browser
    // fullscreen error prevent the overlay from closing.
    try{
      if(document.fullscreenElement === overlay) await document.exitFullscreen();
    }catch{}
    renderFocusOverlay(state.library.find(s=>s.id===state.currentId));
    return false;
  }

  async function toggleLyrics(){
    const next=!state.lyricsOpen;
    if(next && state.focusOpen) await toggleFocus(false);
    state.lyricsOpen=next;
    $('#lyricsPanel').classList.toggle('hidden',!state.lyricsOpen);
    if(state.lyricsOpen){$('#queuePanel').classList.add('hidden');resetLyricsScroll('regular');renderLyricsPanel(state.library.find(s=>s.id===state.currentId));}
  }

  function toggleFavorite(id){ if(state.favorites.has(id))state.favorites.delete(id);else state.favorites.add(id);persist();if(state.currentId===id)setNowPlayingUI(state.library.find(s=>s.id===id));render(); }
  $('#likeBtn').addEventListener('click',()=>state.currentId&&toggleFavorite(state.currentId));
  $('#playBtn').addEventListener('click',()=>{if(!state.currentId){const list=state.library.slice(0,1);if(list.length)playById(list[0].id);return;} if(audio.paused)audio.play();else audio.pause();});
  $('#prevBtn').addEventListener('click',()=>previousTrack());
  $('#nextBtn').addEventListener('click',()=>nextTrack());
  $('#shuffleBtn').addEventListener('click',()=>{state.shuffle=!state.shuffle;$('#shuffleBtn').classList.toggle('active',state.shuffle);persist();toast(state.shuffle?'Shuffle on':'Shuffle off');});
  $('#repeatBtn').addEventListener('click',()=>{state.repeat=state.repeat==='off'?'all':state.repeat==='all'?'one':'off';$('#repeatBtn').classList.toggle('active',state.repeat!=='off');$('#repeatBtn').textContent=state.repeat==='one'?'↻¹':'↻';persist();toast(`Repeat ${state.repeat}`);});
  function nextTrack(){if(state.repeat==='one'){audio.currentTime=0;audio.play();return;} if(!state.queue.length){const list=state.library.filter(s=>s.id!==state.currentId);if(!list.length)return;playById((state.shuffle?shuffleIds(list.map(s=>s.id)):list.map(s=>s.id))[0]);return;} let idx=state.queue.findIndex(id=>id===state.currentId); if(idx<0)idx=state.queueIndex; let next=idx+1;if(next>=state.queue.length){if(state.repeat==='all')next=0;else{return audio.pause();}}state.queueIndex=next;playById(state.queue[next],true);renderQueue('queue',true);}
  function previousTrack(){if(audio.currentTime>5){audio.currentTime=0;return;}const idx=state.queue.findIndex(id=>id===state.currentId);if(idx>0){state.queueIndex=idx-1;playById(state.queue[idx-1],true);}else if(state.history.length>1){playById(state.history[1],false);}}
  audio.addEventListener('play',()=>{const s=state.library.find(x=>x.id===state.currentId);if(s)setNowPlayingUI(s,true);});
  audio.addEventListener('pause',()=>{const s=state.library.find(x=>x.id===state.currentId);if(s)setNowPlayingUI(s,false);});
  audio.addEventListener('ended',nextTrack);
  $('#progress').addEventListener('input',()=>{if(audio.duration)audio.currentTime=audio.duration*(Number($('#progress').value)/1000);});
  $('#volume').addEventListener('input',e=>{state.volume=Number(e.target.value);audio.volume=state.volume;state.previousVolume=state.volume||state.previousVolume;$('#muteBtn').textContent=state.volume===0?'🔇':'🔊';persist();});
  $('#muteBtn').addEventListener('click',()=>{if(audio.volume>0){state.previousVolume=audio.volume;audio.volume=0;state.volume=0;}else{audio.volume=state.previousVolume||.8;state.volume=audio.volume;}$('#volume').value=state.volume;$('#muteBtn').textContent=state.volume===0?'🔇':'🔊';persist();});

  $('#lyricsBtn').addEventListener('click',toggleLyrics);
  $('#focusLyricsBtn').addEventListener('click',async()=>{toggleFocus(true);try{if(!document.fullscreenElement) await $('#focusOverlay').requestFullscreen();}catch{}});
  $('#focusLyricsFooterBtn').addEventListener('click',()=>toggleFocus(true));
  $('#focusCloseBtn').addEventListener('click',()=>toggleFocus(false));
  $('#focusPlayBtn').addEventListener('click',()=>{if(audio.paused)audio.play();else audio.pause();});
  $('#focusPrevBtn').addEventListener('click',previousTrack);
  $('#focusNextBtn').addEventListener('click',nextTrack);
  $('#focusLayoutBtn').addEventListener('click',()=>{const order=['split','lyrics','artwork'];const i=order.indexOf(state.appearance.focusLayout||'split');setAppearance({focusLayout:order[(i+1)%order.length]});renderFocusOverlay(state.library.find(s=>s.id===state.currentId));});
  $('#focusSyncBtn')?.addEventListener('click',()=>syncBackToCurrent('focus'));
  $('#focusFullscreenBtn').addEventListener('click',async()=>{try{if(!document.fullscreenElement) await $('#focusOverlay').requestFullscreen(); else await document.exitFullscreen();}catch{toast('Fullscreen is not available in this window');}});
  $('#closeLyricsBtn').addEventListener('click',()=>{state.lyricsOpen=false;resetLyricsScroll('regular');$('#lyricsPanel').classList.add('hidden');$('#lyricsBtn').classList.remove('active');});
  $('#queueBtn').addEventListener('click',async()=>{ const opening=$('#queuePanel').classList.contains('hidden'); if(opening && state.focusOpen) await toggleFocus(false); $('#queuePanel').classList.toggle('hidden'); if(opening){state.lyricsOpen=false;$('#lyricsPanel').classList.add('hidden');$('#lyricsBtn').classList.remove('active');renderQueue('queue');} });
  $('#closeQueueBtn').addEventListener('click',()=>$('#queuePanel').classList.add('hidden'));
  $$('.queue-tab').forEach(b=>b.addEventListener('click',()=>{$$('.queue-tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderQueue(b.dataset.queueTab);}));
  $('#queueList')?.addEventListener('scroll',e=>{state.queueScrollTop=e.currentTarget.scrollTop;});
  function renderQueue(tab='queue', preserveScroll=false){
    const box=$('#queueList'); if(!box)return;
    if(tab==='queue'){
      if(!state.queue.length && state.currentId && state.library.some(s=>s.id===state.currentId)){
        state.queue=[state.currentId];
        state.queueIndex=0;
        persist();
      }
      const seen=new Set();
      state.queue=state.queue.filter(id=>state.library.some(s=>s.id===id)&&!seen.has(id)&&(seen.add(id),true));
      if(state.currentId&&state.queue.includes(state.currentId)) state.queueIndex=state.queue.indexOf(state.currentId);
    }
    const list=tab==='history'
      ? state.history.map(id=>state.library.find(s=>s.id===id)).filter(Boolean)
      : state.queue.map(id=>state.library.find(s=>s.id===id)).filter(Boolean);
    const savedScroll=preserveScroll?Math.max(0,Number(state.queueScrollTop)||box.scrollTop):0;
    $('#queueCount').textContent=`${list.length} song${list.length===1?'':'s'}`;
    box.innerHTML=list.length
      ? list.map((s,i)=>`<div class="queue-row ${s.id===state.currentId?'playing':''}" data-qid="${esc(s.id)}">${art(s,'q-art')}<div class="q-text"><div class="q-title">${esc(s.title)}</div><div class="q-sub">${esc(s.artist)}</div></div>${tab==='queue'?`<button class="q-remove" data-qremove="${esc(s.id)}">×</button>`:'<span class="q-index">'+(i+1)+'</span>'}</div>`).join('')
      : '<div class="queue-empty"><strong>Nothing queued</strong><span>Add songs with “Add to queue” or play a playlist.</span></div>';
    if(tab==='queue'){
      $$('#queueList .queue-row').forEach(r=>r.addEventListener('click',e=>{
        if(e.target.closest('[data-qremove]'))return;
        state.queueScrollTop=box.scrollTop;
        const id=r.dataset.qid;
        state.queueIndex=state.queue.indexOf(id);
        persist();
        playById(id,true);
        updateQueueRows();
      }));
      $$('#queueList [data-qremove]').forEach(b=>b.addEventListener('click',e=>{
        e.stopPropagation();
        state.queueScrollTop=box.scrollTop;
        const id=b.dataset.qremove;
        const removedIndex=state.queue.indexOf(id);
        state.queue=state.queue.filter(x=>x!==id);
        if(removedIndex>=0&&state.queueIndex>removedIndex)state.queueIndex--;
        if(state.queueIndex>=state.queue.length)state.queueIndex=state.queue.length-1;
        persist();
        renderQueue('queue',true);
      }));
    }
    requestAnimationFrame(()=>{
      const max=Math.max(0,box.scrollHeight-box.clientHeight);
      box.scrollTop=Math.min(savedScroll,max);
      state.queueScrollTop=box.scrollTop;
      updateQueueRows();
    });
  }


  document.addEventListener('click',e=>{
    const nav=e.target.closest('.nav-btn[data-view]'); if(nav){navigate(nav.dataset.view);return;}
    const pl=e.target.closest('[data-playlist-id]'); if(pl){navigate('playlist',pl.dataset.playlistId);return;}
  });
  $('#createPlaylistBtn').addEventListener('click',()=>openPlaylistModal());
  $('#addFolderBtn').addEventListener('click',addFolder);
  $('#settingsBtn').addEventListener('click',openSettingsModal);
  $('#aboutBtn').addEventListener('click',openAboutModal);
  $('#searchInput').addEventListener('input',e=>{state.search=e.target.value;render();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&state.focusOpen&&!document.fullscreenElement){e.preventDefault();toggleFocus(false);return;}if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==='l'){e.preventDefault();toggleFocus();return;}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#searchInput').focus();return;}if(e.code==='Space'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();$('#playBtn').click();}if(e.key==='ArrowRight'&&e.ctrlKey)nextTrack();if(e.key==='ArrowLeft'&&e.ctrlKey)previousTrack();});

  $('#backBtn').addEventListener('click',()=>{if(navIndex>0){navIndex--;const n=navHistory[navIndex];navigate(n.view,n.playlistId,false);}});
  $('#forwardBtn').addEventListener('click',()=>{if(navIndex<navHistory.length-1){navIndex++;const n=navHistory[navIndex];navigate(n.view,n.playlistId,false);}});

  function openModal(html){
    const card=$('#modalCard');
    card.innerHTML=html;
    card.classList.toggle('power-shell', !!card.querySelector('.power-modal'));
    $('#modal').classList.remove('hidden');
  }
  function closeModal(){
    $('#modal').classList.add('hidden');
    $('#modalCard').classList.remove('power-shell');
  }
  $('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal();});

  function removeFromPlaylist(playlistId,songId){ const p=state.playlists.find(x=>x.id===playlistId); if(!p)return;p.songIds=p.songIds.filter(x=>x!==songId);persist();render();toast('Removed from playlist'); }
  function openAddToPlaylistModal(songId){
    if(!state.playlists.length){ toast('Create a playlist first'); openPlaylistModal(); return; }
    const s=state.library.find(x=>x.id===songId);
    openModal(`<h2>Add to playlist</h2><p>${esc(s?.title||'Song')}</p><div class="playlist-picker">${state.playlists.map(p=>`<button class="playlist-pick ${p.songIds.includes(songId)?'selected':''}" data-plpick="${esc(p.id)}"><span>${esc(p.name)}</span><b>${p.songIds.includes(songId)?'✓':'＋'}</b></button>`).join('')}</div><div class="modal-actions"><button class="btn" id="cancelPlaylistPick">Done</button></div>`);
    $$('#modal [data-plpick]').forEach(b=>b.addEventListener('click',()=>{const p=state.playlists.find(x=>x.id===b.dataset.plpick);if(!p)return;const at=p.songIds.indexOf(songId);if(at>=0){p.songIds.splice(at,1);}else p.songIds.push(songId);persist();openAddToPlaylistModal(songId);}));
    $('#cancelPlaylistPick').addEventListener('click',closeModal);
  }

  function openPlaylistModal(id){
    const p=id?state.playlists.find(x=>x.id===id):null;
    let pendingCover=p?.cover||null;
    openModal(`<div class="power-modal playlist-modal"><div class="power-modal-head"><div><h2>${p?'Playlist settings':'Create playlist'}</h2><p>Choose a name, description and optional cover image for this playlist.</p></div></div><div class="playlist-cover-editor"><div id="playlistCoverPreview" class="playlist-cover-preview">${pendingCover?`<img src="${pendingCover}" alt="">`:'<span>♫</span>'}</div><div><strong>Playlist cover</strong><p class="muted">Use JPG, PNG or WebP. Localify stores a resized copy with the playlist.</p><div class="modal-row"><button class="btn small" id="choosePlaylistCover">Choose image</button><button class="btn small" id="removePlaylistCover" ${pendingCover?'':'disabled'}>Remove</button></div></div><input id="playlistCoverInput" type="file" accept="image/png,image/jpeg,image/webp,image/*" hidden></div><div class="settings-grid"><label>Name<input id="playlistName" class="modal-input" value="${esc(p?.name||'My playlist')}"></label><label>Description<input id="playlistDescription" class="modal-input" value="${esc(p?.description||'')}" placeholder="Optional"></label></div><div class="modal-actions"><button class="btn" id="cancelPlaylist">Cancel</button><button class="btn primary" id="savePlaylistBtn">Save</button></div></div>`);
    const input=$('#playlistCoverInput');
    $('#choosePlaylistCover').onclick=()=>input.click();
    $('#removePlaylistCover').onclick=()=>{pendingCover=null;$('#playlistCoverPreview').innerHTML='<span>♫</span>';$('#removePlaylistCover').disabled=true;};
    input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;pendingCover=await imageFileToDataURL(file,900);$('#playlistCoverPreview').innerHTML=`<img src="${pendingCover}" alt="">`;$('#removePlaylistCover').disabled=false;}catch{toast('Could not load that image');}};
    $('#cancelPlaylist').onclick=closeModal;
    $('#savePlaylistBtn').onclick=()=>{const name=$('#playlistName').value.trim()||'My playlist';const description=$('#playlistDescription').value.trim();if(p){p.name=name;p.description=description;p.cover=pendingCover;}else state.playlists.push({id:uid('pl'),name,description,cover:pendingCover,songIds:[]});persist();closeModal();renderSidebar();render();toast(p?'Playlist updated':'Playlist created');};
  }

  function openSettingsModal(){
    const a=state.appearance||{};
    openModal(`<h2>Settings</h2><p>Make Localify look and feel like your own music app.</p>
      <div class="settings-tabs"><button class="settings-tab active" data-stab="appearance">Appearance</button><button class="settings-tab" data-stab="library">Library</button><button class="settings-tab" data-stab="data">Data</button></div>
      <div class="settings-page" data-settings-page="appearance">
        <div class="setting-group"><div class="setting-heading"><strong>Theme presets</strong><span>Choose a starting look, then customise it below.</span></div><div class="theme-grid">${Object.entries(APPEARANCE_PRESETS).map(([k,p])=>`<button class="theme-preset ${a.preset===k?'selected':''}" data-preset="${k}"><span class="theme-dot" style="--dot:${p.accent}"></span><span>${p.name}</span></button>`).join('')}</div></div>
        <div class="setting-group"><div class="setting-heading"><strong>Accent colour</strong><span>Used for active controls, buttons and highlights.</span></div><div class="appearance-row"><input id="accentColor" class="color-input" type="color" value="${esc(a.accent||'#9cff57')}"><input id="accentHex" class="modal-input compact-input" value="${esc(a.accent||'#9cff57')}" maxlength="7"><button class="btn small" id="resetAccent">Preset</button></div></div>
        <div class="setting-group"><div class="setting-heading"><strong>Background</strong><span>Change the overall atmosphere of the app.</span></div><div class="appearance-selects"><label>Style<select id="backgroundSelect" class="sort-select"><option value="aurora" ${a.background==='aurora'?'selected':''}>Aurora gradient</option><option value="midnight" ${a.background==='midnight'?'selected':''}>Midnight</option><option value="graphite" ${a.background==='graphite'?'selected':''}>Graphite</option><option value="glass" ${a.background==='glass'?'selected':''}>Glass glow</option></select></label><label>Density<select id="densitySelect" class="sort-select"><option value="comfortable" ${a.density==='comfortable'?'selected':''}>Comfortable</option><option value="compact" ${a.density==='compact'?'selected':''}>Compact</option><option value="spacious" ${a.density==='spacious'?'selected':''}>Spacious</option></select></label></div></div>
        <div class="setting-group"><div class="setting-heading"><strong>Shape & layout</strong><span>Fine-tune how much space the interface uses.</span></div><div class="appearance-selects"><label>Corner style<select id="radiusSelect" class="sort-select"><option value="rounded" ${a.radius==='rounded'?'selected':''}>Rounded</option><option value="soft" ${a.radius==='soft'?'selected':''}>Soft</option><option value="sharp" ${a.radius==='sharp'?'selected':''}>Sharp</option></select></label><label>Sidebar<select id="sidebarSelect" class="sort-select"><option value="wide" ${a.sidebar==='wide'?'selected':''}>Wide</option><option value="compact" ${a.sidebar==='compact'?'selected':''}>Compact</option><option value="minimal" ${a.sidebar==='minimal'?'selected':''}>Minimal</option></select></label><label>Artwork<select id="artworkSelect" class="sort-select"><option value="large" ${a.artwork==='large'?'selected':''}>Large</option><option value="medium" ${a.artwork==='medium'?'selected':''}>Medium</option><option value="small" ${a.artwork==='small'?'selected':''}>Small</option></select></label><label>Player<select id="playerSelect" class="sort-select"><option value="bar" ${a.player==='bar'?'selected':''}>Classic bar</option><option value="raised" ${a.player==='raised'?'selected':''}>Raised</option><option value="minimal" ${a.player==='minimal'?'selected':''}>Minimal</option></select></label><label>Accent glow<select id="accentGlowSelect" class="sort-select"><option value="subtle" ${a.accentGlow==='subtle'?'selected':''}>Subtle</option><option value="medium" ${a.accentGlow==='medium'?'selected':''}>Medium</option><option value="strong" ${a.accentGlow==='strong'?'selected':''}>Strong</option></select></label><label>Visualizer<select id="visualizerStyleSelect" class="sort-select"><option value="bars" ${state.visualizerStyle==='bars'?'selected':''}>Bars</option><option value="wave" ${state.visualizerStyle==='wave'?'selected':''}>Wave</option><option value="dots" ${state.visualizerStyle==='dots'?'selected':''}>Dots</option></select></label></div></div>
        <div class="setting-group"><div class="setting-heading"><strong>Lyrics & fullscreen player</strong><span>Choose what the immersive player looks like when you maximize lyrics.</span></div><div class="appearance-selects"><label>Focus layout<select id="focusLayoutSelect" class="sort-select"><option value="split" ${a.focusLayout==='split'?'selected':''}>50 / 50 Art + Lyrics</option><option value="lyrics" ${a.focusLayout==='lyrics'?'selected':''}>Lyrics only</option><option value="artwork" ${a.focusLayout==='artwork'?'selected':''}>Artwork only</option><option value="cinema" ${a.focusLayout==='cinema'?'selected':''}>Cinema</option></select></label><label>Cinema animation<select id="cinemaStyleSelect"><option value="random" ${a.cinemaStyle==='random'?'selected':''}>Random mix (variety)</option><option value="scatter" ${a.cinemaStyle==='scatter'?'selected':''}>Scatter</option><option value="pop" ${a.cinemaStyle==='pop'?'selected':''}>Pop</option><option value="slide" ${a.cinemaStyle==='slide'?'selected':''}>Slide</option><option value="slam" ${a.cinemaStyle==='slam'?'selected':''}>Slam</option><option value="float" ${a.cinemaStyle==='float'?'selected':''}>Float</option><option value="wave" ${a.cinemaStyle==='wave'?'selected':''}>Wave</option><option value="flip" ${a.cinemaStyle==='flip'?'selected':''}>Flip</option><option value="blur" ${a.cinemaStyle==='blur'?'selected':''}>Blur</option><option value="zoom" ${a.cinemaStyle==='zoom'?'selected':''}>Zoom</option><option value="rotate" ${a.cinemaStyle==='rotate'?'selected':''}>Rotate</option><option value="type" ${a.cinemaStyle==='type'?'selected':''}>Type</option><option value="drift" ${a.cinemaStyle==='drift'?'selected':''}>Drift</option><option value="bounce" ${a.cinemaStyle==='bounce'?'selected':''}>Bounce</option><option value="glitch" ${a.cinemaStyle==='glitch'?'selected':''}>Glitch</option><option value="elastic" ${a.cinemaStyle==='elastic'?'selected':''}>Elastic</option><option value="orbit" ${a.cinemaStyle==='orbit'?'selected':''}>Orbit</option><option value="radial" ${a.cinemaStyle==='radial'?'selected':''}>Radial burst</option><option value="jitter" ${a.cinemaStyle==='jitter'?'selected':''}>Jitter</option><option value="stretch" ${a.cinemaStyle==='stretch'?'selected':''}>Stretch</option><option value="neon" ${a.cinemaStyle==='neon'?'selected':''}>Neon</option><option value="pulse" ${a.cinemaStyle==='pulse'?'selected':''}>Pulse</option><option value="split" ${a.cinemaStyle==='split'?'selected':''}>Split</option><option value="rise" ${a.cinemaStyle==='rise'?'selected':''}>Rise</option><option value="fall" ${a.cinemaStyle==='fall'?'selected':''}>Fall</option><option value="spiral" ${a.cinemaStyle==='spiral'?'selected':''}>Spiral</option><option value="snap" ${a.cinemaStyle==='snap'?'selected':''}>Snap</option><option value="swing" ${a.cinemaStyle==='swing'?'selected':''}>Swing</option><option value="topDrop" ${a.cinemaStyle==='topDrop'?'selected':''}>Top drop</option><option value="bottomRise" ${a.cinemaStyle==='bottomRise'?'selected':''}>Bottom rise</option><option value="leftRush" ${a.cinemaStyle==='leftRush'?'selected':''}>Left rush</option><option value="rightRush" ${a.cinemaStyle==='rightRush'?'selected':''}>Right rush</option><option value="diagonal" ${a.cinemaStyle==='diagonal'?'selected':''}>Diagonal</option><option value="verticalFlip" ${a.cinemaStyle==='verticalFlip'?'selected':''}>Vertical flip</option><option value="pendulum" ${a.cinemaStyle==='pendulum'?'selected':''}>Pendulum</option><option value="cardTurn" ${a.cinemaStyle==='cardTurn'?'selected':''}>Card turn</option><option value="corkscrew" ${a.cinemaStyle==='corkscrew'?'selected':''}>Corkscrew</option><option value="tunnel" ${a.cinemaStyle==='tunnel'?'selected':''}>Tunnel</option><option value="gravity" ${a.cinemaStyle==='gravity'?'selected':''}>Gravity</option><option value="sideSwipe" ${a.cinemaStyle==='sideSwipe'?'selected':''}>Side swipe</option><option value="centerBurst" ${a.cinemaStyle==='centerBurst'?'selected':''}>Center burst</option><option value="edgeFloat" ${a.cinemaStyle==='edgeFloat'?'selected':''}>Edge float</option><option value="stackRise" ${a.cinemaStyle==='stackRise'?'selected':''}>Stack rise</option><option value="stackFall" ${a.cinemaStyle==='stackFall'?'selected':''}>Stack fall</option><option value="waveVertical" ${a.cinemaStyle==='waveVertical'?'selected':''}>Vertical wave</option><option value="skate" ${a.cinemaStyle==='skate'?'selected':''}>Skate</option><option value="swoop" ${a.cinemaStyle==='swoop'?'selected':''}>Swoop</option><option value="whiplash" ${a.cinemaStyle==='whiplash'?'selected':''}>Whiplash</option><option value="magnet" ${a.cinemaStyle==='magnet'?'selected':''}>Magnet</option><option value="flicker" ${a.cinemaStyle==='flicker'?'selected':''}>Flicker</option><option value="cascade" ${a.cinemaStyle==='cascade'?'selected':''}>Cascade</option></select></label><label>Cinema beat reaction<select id="cinemaBeatSelect"><option value="off" ${a.cinemaBeat==='off'?'selected':''}>Off</option><option value="subtle" ${a.cinemaBeat==='subtle'?'selected':''}>Subtle</option><option value="medium" ${(!a.cinemaBeat||a.cinemaBeat==='medium')?'selected':''}>Medium</option><option value="strong" ${a.cinemaBeat==='strong'?'selected':''}>Strong</option></select></label><label>Beat sensitivity<select id="cinemaBeatSensitivitySelect"><option value="low" ${a.cinemaBeatSensitivity==='low'?'selected':''}>Low</option><option value="medium" ${(!a.cinemaBeatSensitivity||a.cinemaBeatSensitivity==='medium')?'selected':''}>Medium</option><option value="high" ${a.cinemaBeatSensitivity==='high'?'selected':''}>High</option></select></label><label>Animation intensity<select id="cinemaIntensitySelect"><option value="0.7" ${Number(a.cinemaIntensity)===0.7?'selected':''}>Gentle</option><option value="1" ${!a.cinemaIntensity||Number(a.cinemaIntensity)===1?'selected':''}>Normal</option><option value="1.25" ${Number(a.cinemaIntensity)===1.25?'selected':''}>Punchy</option><option value="1.5" ${Number(a.cinemaIntensity)===1.5?'selected':''}>Wild</option></select></label><label>Line transition<select id="cinemaTransitionSelect"><option value="dynamic" ${(!a.cinemaTransition||a.cinemaTransition==='dynamic')?'selected':''}>Dynamic</option><option value="smooth" ${a.cinemaTransition==='smooth'?'selected':''}>Smooth</option><option value="hard" ${a.cinemaTransition==='hard'?'selected':''}>Hard cut</option></select></label><label>Lyrics size<select id="focusLyricsSizeSelect" class="sort-select"><option value="small" ${a.focusLyricsSize==='small'?'selected':''}>Small</option><option value="medium" ${a.focusLyricsSize==='medium'?'selected':''}>Medium</option><option value="large" ${a.focusLyricsSize==='large'?'selected':''}>Large</option><option value="huge" ${a.focusLyricsSize==='huge'?'selected':''}>Huge</option></select></label><label>Fullscreen backdrop<select id="focusBackdropSelect" class="sort-select"><option value="artwork" ${a.focusBackdrop==='artwork'?'selected':''}>Artwork blur</option><option value="gradient" ${a.focusBackdrop==='gradient'?'selected':''}>Accent gradient</option><option value="solid" ${a.focusBackdrop==='solid'?'selected':''}>Solid</option></select></label><label>Artwork scale<select id="focusArtScaleSelect" class="sort-select"><option value="0.85" ${String(a.focusArtScale)==='0.85'?'selected':''}>85%</option><option value="1" ${String(a.focusArtScale)==='1'?'selected':''}>100%</option><option value="1.15" ${String(a.focusArtScale)==='1.15'?'selected':''}>115%</option></select></label></div></div>
        <div class="setting-group"><div class="appearance-range"><div class="setting-heading"><strong>Interface size</strong><span>Adjust text and controls globally.</span></div><input id="fontScale" type="range" min="0.9" max="1" step="0.01" value="${a.fontScale||1}"><output id="fontScaleValue">${Math.round((a.fontScale||1)*100)}%</output></div><label class="settings-toggle"><input type="checkbox" id="glassToggle" ${a.glass!==false?'checked':''}><span><strong>Glass panels</strong><small>Use translucency and blur in the top bar, cards and overlays.</small></span></label><label class="settings-toggle"><input type="checkbox" id="animationToggle" ${a.animated!==false?'checked':''}><span><strong>Motion & animations</strong><small>Enable subtle hover, lyric and panel transitions.</small></span></label></div>
      </div>
      <div class="settings-page hidden-settings-page" data-settings-page="library">
        <div class="notice"><b>Lyrics:</b> Localify can automatically find synced lyrics when a song has no local or embedded lyrics.</div>
        <label class="settings-toggle"><input type="checkbox" id="autoLyricsToggle" ${state.autoFetchLyrics?'checked':''}><span><strong>Automatically find lyrics</strong><small>Search LRCLIB using the track metadata.</small></span></label>
        <div class="settings-grid"><div class="stat-card"><span>Tracks</span><strong>${state.library.length}</strong></div><div class="stat-card"><span>Playlists</span><strong>${state.playlists.length}</strong></div></div>
        <div class="section" style="margin-top:18px"><div class="modal-row"><div class="modal-label"><strong>Music folders</strong><span>Folders currently remembered by Localify.</span></div><button class="btn small" id="settingsAddFolder">Add</button></div><div id="folderSettings" class="folder-list" style="margin-top:10px">${state.folders.length?state.folders.map(f=>`<div class="folder-item"><div class="folder-path">${esc(f.name)}</div><div class="folder-actions"><button class="btn small" data-rescan-folder="${esc(f.id)}">Rescan</button><button class="btn small danger" data-remove-folder="${esc(f.id)}">Forget</button></div></div>`).join(''):'<div style="color:#747a85;font-size:12px;padding:10px 0">No folders added.</div>'}</div></div>
      </div>
      <div class="settings-page hidden-settings-page" data-settings-page="data">
        <div class="notice"><b>Privacy:</b> Your MP3 files, playlists, history and appearance preferences stay on this PC. Only metadata needed for automatic lyric lookup is sent to the configured lyric service.</div>
        <div class="data-actions"><button class="btn" id="exportBtn">Export playlists</button><button class="btn" id="importBtn">Import playlists</button><button class="btn danger" id="resetAppearance">Reset appearance</button></div>
      </div>
      <div class="modal-actions"><button class="btn" id="closeSettings">Done</button></div>`);
    $$('#modal [data-stab]').forEach(tab=>tab.addEventListener('click',()=>{$$('#modal [data-stab]').forEach(x=>x.classList.remove('active'));tab.classList.add('active');$$('#modal [data-settings-page]').forEach(p=>p.classList.toggle('hidden-settings-page',p.dataset.settingsPage!==tab.dataset.stab));}));
    $$('#modal [data-preset]').forEach(b=>b.addEventListener('click',()=>{setAppearance({preset:b.dataset.preset});openSettingsModal();}));
    const syncColor=(val)=>{const v=/^#[0-9a-fA-F]{6}$/.test(val)?val:'#9cff57';setAppearance({preset:'custom',accent:v,accent2:v});};
    $('#accentColor').addEventListener('input',e=>{$('#accentHex').value=e.target.value;syncColor(e.target.value);});$('#accentHex').addEventListener('change',e=>{if(/^#[0-9a-fA-F]{6}$/.test(e.target.value)){ $('#accentColor').value=e.target.value;syncColor(e.target.value); }});$('#resetAccent').addEventListener('click',()=>setAppearance({preset:'lime'}));
    $('#backgroundSelect').addEventListener('change',e=>setAppearance({background:e.target.value}));$('#densitySelect').addEventListener('change',e=>setAppearance({density:e.target.value}));$('#radiusSelect').addEventListener('change',e=>setAppearance({radius:e.target.value}));$('#sidebarSelect').addEventListener('change',e=>setAppearance({sidebar:e.target.value}));$('#artworkSelect').addEventListener('change',e=>setAppearance({artwork:e.target.value}));$('#playerSelect').addEventListener('change',e=>setAppearance({player:e.target.value}));$('#accentGlowSelect').addEventListener('change',e=>setAppearance({accentGlow:e.target.value}));$('#visualizerStyleSelect').addEventListener('change',e=>{state.visualizerStyle=e.target.value;persist();});$('#cinemaStyleSelect').addEventListener('change',e=>setAppearance({cinemaStyle:e.target.value}));$('#cinemaBeatSelect').addEventListener('change',e=>setAppearance({cinemaBeat:e.target.value}));$('#cinemaBeatSensitivitySelect').addEventListener('change',e=>setAppearance({cinemaBeatSensitivity:e.target.value}));$('#cinemaIntensitySelect').addEventListener('change',e=>setAppearance({cinemaIntensity:Number(e.target.value)}));$('#cinemaTransitionSelect').addEventListener('change',e=>setAppearance({cinemaTransition:e.target.value}));$('#focusLayoutSelect').addEventListener('change',e=>setAppearance({focusLayout:e.target.value}));$('#focusLyricsSizeSelect').addEventListener('change',e=>setAppearance({focusLyricsSize:e.target.value}));$('#focusBackdropSelect').addEventListener('change',e=>setAppearance({focusBackdrop:e.target.value}));$('#focusArtScaleSelect').addEventListener('change',e=>setAppearance({focusArtScale:Number(e.target.value)}));
    $('#fontScale').addEventListener('input',e=>{state.appearance.fontScale=Number(e.target.value);$('#fontScaleValue').textContent=Math.round(state.appearance.fontScale*100)+'%';applyAppearance();persist();});
    $('#glassToggle').addEventListener('change',e=>setAppearance({glass:e.target.checked}));$('#animationToggle').addEventListener('change',e=>setAppearance({animated:e.target.checked}));
    $('#closeSettings').addEventListener('click',closeModal);$('#autoLyricsToggle').addEventListener('change',e=>{state.autoFetchLyrics=e.target.checked;persist();toast(state.autoFetchLyrics?'Automatic lyrics enabled':'Automatic lyrics disabled');});
    $('#settingsAddFolder').addEventListener('click',()=>{closeModal();addFolder();});
    $$('#modal [data-remove-folder]').forEach(b=>b.addEventListener('click',async()=>{const id=b.dataset.removeFolder;state.folders=state.folders.filter(x=>x.id!==id);await dbDelete('folders',id);state.library=state.library.filter(s=>s.folderId!==id);for(const s of await dbGetAll('songs'))if(s.folderId===id)await dbDelete('songs',s.id);persist();render();openSettingsModal();}));
    $$('#modal [data-rescan-folder]').forEach(b=>b.addEventListener('click',async()=>{const f=state.folders.find(x=>x.id===b.dataset.rescanFolder);if(f){closeModal();await scanFolder(f);}}));
    $('#exportBtn').addEventListener('click',exportPlaylists);$('#importBtn').addEventListener('click',importPlaylists);
    $('#resetAppearance').addEventListener('click',()=>{state.appearance={preset:'lime',accent:'#9cff57',accent2:'#d7ffb9',background:'aurora',density:'compact',radius:'rounded',glass:true,sidebar:'wide',fontScale:.96,artwork:'medium',player:'bar',animated:true,focusLayout:'split',focusLyricsSize:'large',focusBackdrop:'artwork',focusArtScale:1,cinemaStyle:'random',cinemaBeat:'strong',cinemaBeatSensitivity:'medium',cinemaIntensity:1,cinemaTransition:'dynamic',accentGlow:'medium',sidebarCollapsed:false};applyAppearance();persist();toast('Appearance reset');openSettingsModal();});
  }
  function exportPlaylists(){const data=JSON.stringify({playlists:state.playlists,favorites:[...state.favorites],version:1},null,2);const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download='localify-playlists.json';a.click();URL.revokeObjectURL(a.href);toast('Playlist backup exported');}
  function importPlaylists(){const inp=document.createElement('input');inp.type='file';inp.accept='application/json';inp.onchange=async()=>{try{const x=JSON.parse(await inp.files[0].text());if(Array.isArray(x.playlists))state.playlists=x.playlists;if(Array.isArray(x.favorites))state.favorites=new Set(x.favorites);persist();closeModal();render();toast('Playlist backup imported');}catch{toast('Invalid playlist backup')}};inp.click();}
  function openAboutModal(){openModal(`<h2>Localify</h2><p>A local-first desktop music player for your own files.</p><div class="modal-row"><div class="modal-label"><strong>No streaming account</strong><span>Everything is played from files you select on this computer.</span></div></div><div class="modal-row"><div class="modal-label"><strong>Supported files</strong><span>MP3, M4A, AAC, WAV, OGG and FLAC where your browser supports them.</span></div></div><div class="modal-row"><div class="modal-label"><strong>Keyboard</strong><span>Space = play/pause · Ctrl+K = search · Ctrl+←/→ = previous/next</span></div></div><div class="modal-actions"><button class="btn primary" id="closeAbout">Close</button></div>`);$('#closeAbout').addEventListener('click',closeModal);}

  $('#sidebarToggle')?.addEventListener('click',()=>{
    const collapsed=state.appearance.sidebarCollapsed!==true;
    setAppearance({sidebarCollapsed:collapsed});
    const b=$('#sidebarToggle'); if(b){b.textContent=collapsed?'›':'‹';b.title=collapsed?'Expand sidebar':'Collapse sidebar';b.setAttribute('aria-label',b.title);}
  });

  audio.addEventListener('timeupdate',()=>{
    const duration=Number.isFinite(audio.duration)?audio.duration:0;
    if(duration){$('#progress').value=String(Math.round((audio.currentTime/duration)*1000));$('#currentTime').textContent=fmtTime(audio.currentTime);$('#totalTime').textContent=fmtTime(duration);}
    const pos=duration?(audio.currentTime/duration)*1000:0;
    const fp=$('#focusProgress'); if(fp)fp.value=String(Math.max(0,Math.min(1000,pos)));
    const ft=$('#focusTime'); if(ft)ft.textContent=fmtTime(audio.currentTime); const fd=$('#focusDuration'); if(fd)fd.textContent=fmtTime(duration);
    const fplay=$('#focusPlayBtn'); if(fplay)fplay.textContent=audio.paused?'▶':'❚❚';
    syncLyrics();
  });
  audio.addEventListener('loadedmetadata',()=>{const fd=$('#focusDuration');if(fd)fd.textContent=fmtTime(audio.duration);});
  $('#focusProgress').addEventListener('input',e=>{if(Number.isFinite(audio.duration))audio.currentTime=(Number(e.target.value)/1000)*audio.duration;});
  document.addEventListener('fullscreenchange',()=>{
    const overlay=$('#focusOverlay');
    if(overlay && state.focusOpen)overlay.classList.remove('hidden');
    const fs=document.fullscreenElement===overlay;
    const btn=$('#focusFullscreenBtn');
    if(btn){btn.textContent=fs?'⤢':'⛶';btn.title=fs?'Exit fullscreen':'Enter fullscreen';}
  });

  // A compact Web Audio visualizer.
  let audioCtx, analyser, sourceNode, raf;
  let beatEnergy=0, beatPrev=0, beatPulse=0, beatLastAt=0, beatAvg=0;
  function updateCinemaBeat(data){
    if(!analyser)return;
    const sensitivity=state.appearance?.cinemaBeatSensitivity||'medium';
    const beatSetting=state.appearance?.cinemaBeat||'strong';
    const lowEnd=Math.min(10,data.length-1);
    let low=0,mid=0,high=0;
    for(let i=1;i<=lowEnd;i++) low+=data[i]||0;
    for(let i=lowEnd+1;i<Math.min(data.length,24);i++) mid+=data[i]||0;
    for(let i=24;i<Math.min(data.length,48);i++) high+=data[i]||0;
    const lowN=Math.max(1,lowEnd), midN=Math.max(1,Math.min(data.length,24)-lowEnd-1), highN=Math.max(1,Math.min(data.length,48)-24);
    const raw=((low/lowN)*.62+(mid/midN)*.28+(high/highN)*.10)/255;
    beatAvg=beatAvg*.92+raw*.08;
    const delta=Math.max(0,raw-beatAvg);
    beatEnergy=beatEnergy*.80+raw*.20;
    const threshold=sensitivity==='high'?.018:sensitivity==='low'?.055:.034;
    const cooldown=sensitivity==='high'?95:sensitivity==='low'?180:125;
    const now=performance.now();
    if(beatSetting!=='off' && delta>threshold && raw>.105 && now-beatLastAt>cooldown){ beatLastAt=now; beatPulse=1; const stage=$('#focusLyricsBody .cinema-lyrics-stage'); if(stage){ stage.classList.remove('beat-hit'); void stage.offsetWidth; stage.classList.add('beat-hit'); setTimeout(()=>stage.classList.remove('beat-hit'),220); } }
    beatPulse*=.90;
    const strength=beatSetting==='off'?0:beatSetting==='subtle'?.45:beatSetting==='medium'?1:1.35;
    const pulse=Math.min(1,beatPulse*strength);
    document.documentElement.style.setProperty('--cinema-beat',pulse.toFixed(3));
    const stage=$('#focusLyricsBody .cinema-lyrics-stage');
    if(stage){ stage.style.setProperty('--cinema-beat',pulse.toFixed(3)); stage.style.setProperty('--cinema-energy',Math.min(1,beatEnergy*1.8).toFixed(3)); }
  }
  function initVisualizer(){
    try{
      audioCtx=new (window.AudioContext||window.webkitAudioContext)();
      analyser=audioCtx.createAnalyser();analyser.fftSize=128;
      sourceNode=audioCtx.createMediaElementSource(audio);
      const settings=window.__localifyEQSettings||{bands:[0,0,0,0,0,0,0,0,0,0],preamp:0,bass:0,treble:0,eqEnabled:true};
      const freqs=[32,64,125,250,500,1000,2000,4000,8000,16000];
      const filters=freqs.map((freq,i)=>{const f=audioCtx.createBiquadFilter();f.type='peaking';f.frequency.value=freq;f.Q.value=1.0;f.gain.value=settings.eqEnabled===false?0:Number(settings.bands?.[i]||0);return f;});
      const preamp=audioCtx.createGain();preamp.gain.value=Math.pow(10,Number(settings.preamp||0)/20);
      const bass=audioCtx.createBiquadFilter();bass.type='lowshelf';bass.frequency.value=120;bass.gain.value=Number(settings.bass||0);
      const treble=audioCtx.createBiquadFilter();treble.type='highshelf';treble.frequency.value=6000;treble.gain.value=Number(settings.treble||0);
      let node=sourceNode;node.connect(preamp);node=preamp;node.connect(bass);node=bass;for(const f of filters){node.connect(f);node=f;}node.connect(treble);node=treble;node.connect(analyser);analyser.connect(audioCtx.destination);
      window.__localifyAudioGraph={audioCtx,analyser,sourceNode,filters,preamp,bass,treble};
      drawVisualizer();
      window.__localifyPowerAudioReady?.();
    }catch(e){$('#visualizerWrap').style.display='none';}
  }
  function drawVisualizer(){
    const c=$('#visualizer');const ctx=c.getContext('2d');const data=new Uint8Array(analyser.frequencyBinCount);
    function frame(){
      raf=requestAnimationFrame(frame); c.width=Math.max(1,c.clientWidth*devicePixelRatio);c.height=Math.max(1,c.clientHeight*devicePixelRatio);
      ctx.clearRect(0,0,c.width,c.height);
      analyser.getByteFrequencyData(data);
      updateCinemaBeat(data);
      if(!state.visualizer)return; const rgb=getComputedStyle(document.documentElement).getPropertyValue('--accent-rgb').trim()||'156,255,87'; ctx.fillStyle=`rgba(${rgb},.88)`; ctx.strokeStyle=`rgba(${rgb},.88)`;
      const style=state.visualizerStyle||'bars'; const bw=c.width/data.length;
      if(style==='dots'){
        for(let i=0;i<data.length;i+=2){const h=(data[i]/255)*c.height;const r=Math.max(1.5,2.2*devicePixelRatio);ctx.beginPath();ctx.arc(i*bw,c.height-h-r,r,0,Math.PI*2);ctx.fill();}
      } else if(style==='wave'){
        ctx.lineWidth=Math.max(1,2*devicePixelRatio);ctx.beginPath(); for(let i=0;i<data.length;i++){const x=i/(data.length-1)*c.width;const y=c.height-(data[i]/255)*c.height*.92; if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();
      } else if(style==='mirror') {
        const half=c.height/2;
        for(let i=0;i<data.length;i++){const h=(data[i]/255)*half;const x=i*bw;ctx.fillRect(x,half-h,Math.max(1,bw*.72),h);ctx.fillRect(x,half,Math.max(1,bw*.72),h);}
      } else if(style==='circle') {
        const cx=c.width/2,cy=c.height/2,R=Math.min(c.width,c.height)*.28;
        ctx.beginPath();
        for(let i=0;i<data.length;i++){const a=(i/data.length)*Math.PI*2;const r=R+(data[i]/255)*R*.8;const x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}
        ctx.closePath();ctx.stroke();
      } else {
        for(let i=0;i<data.length;i++){const h=(data[i]/255)*c.height;ctx.fillRect(i*bw,c.height-h,Math.max(1,bw*.72),h);}
      }
    } frame();
  }
  $('#visualizerBtn').addEventListener('click',()=>{state.visualizer=!state.visualizer;$('#visualizerBtn').classList.toggle('active',state.visualizer);persist();});
  audio.addEventListener('play',()=>{if(!audioCtx)initVisualizer();if(audioCtx?.state==='suspended')audioCtx.resume();});

  // Public bridge used by the advanced Localify power pack.
  window.LocalifyAPI = {
    get ready(){ return !!state.dbReady; }, state, audio, esc, fmtTime, APPEARANCE_PRESETS,
    dbGet, dbPut, dbGetAll, dbDelete, persist,
    render, renderSidebar, renderQueue, renderFocusOverlay,
    navigate, setAppearance, playById, playList, nextTrack, previousTrack, enqueue, toggleFocus,
    openModal, closeModal, openPlaylistModal, openAddToPlaylistModal, fetchLyricsOnline,
    getFileForSong, parseFile, upsertSong, finishScan, scanAllFolders, scanFolder, addFolder, art, card, songTable,
    toast
  };

  // Initial route and app startup.
  navHistory=[{view:'home',playlistId:null}];navIndex=0;
  loadPersistent().then(()=>{window.dispatchEvent(new Event('localify-ready'));}).catch(()=>{render();toast('Local storage could not be opened');window.dispatchEvent(new Event('localify-ready'));});
})();
