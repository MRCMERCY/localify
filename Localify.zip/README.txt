LOCALIFY — Windows local music player

This build includes automatic lyrics, deep appearance customisation, and an immersive fullscreen player.

INSTALL
1. Extract this ZIP.
2. Double-click "Install Localify.bat".
3. Launch Localify from the desktop shortcut.

APPEARANCE
Settings > Appearance includes:
- Lime, Spotify, Ocean, Violet, Sunset, Rose, Cyber and Mono presets
- Custom accent colour
- Accent glow intensity
- Aurora, Midnight, Graphite and Glass backgrounds
- Compact / Comfortable / Spacious density
- Rounded / Soft / Sharp corners
- Wide / Compact / Minimal sidebar
- Large / Medium / Small artwork
- Classic / Raised / Minimal player
- Bars / Wave / Dots visualizer
- Global interface scaling
- Glass panels on/off
- Animations on/off

FULLSCREEN PLAYER / LYRICS
- One-click fullscreen lyrics from the Lyrics panel
- 50/50 album art + lyrics mode
- Lyrics-only mode
- Artwork-only mode
- Synced karaoke highlighting and clickable lyric seeking
- Configurable lyrics size
- Artwork-blur, accent-gradient or solid fullscreen backdrop
- Adjustable fullscreen artwork scale
- Browser fullscreen exit/re-entry support
- Scrollable lyrics with automatic sync pause while you browse; sync resumes after scrolling stops

LYRICS
- Embedded ID3 lyrics where available
- Adjacent .lrc and .txt files
- Automatic LRCLIB lookup using track metadata
- Synced karaoke-style line highlighting

PLAYBACK
- MP3/local audio playback
- Playlists, favourites, queue and history
- Search, sorting, shuffle and repeat
- Album artwork and metadata
- Keyboard shortcuts

PRIVACY
Your music files remain on the computer. Automatic lyric lookup sends only the metadata needed to identify the track.

POWER FEATURES
- 10-band EQ, presets, preamp, bass/treble, ReplayGain loudness normalisation, track transitions
- Smart Shuffle and For You recommendations
- Ratings, listening statistics, daily/monthly charts, top songs/artists/genres and skip tracking
- Duplicate detector, advanced library filters and quality information
- Automatic album-art lookup (track metadata is not editable in the app)
- Automatic artwork/metadata helpers, folder monitoring and drag/drop audio import
- Queue drag/reorder, mini player, sleep timer, media-key support and keyboard shortcuts
- Dynamic album-colour themes, Cinema focus mode, beat-reactive visual effects and more visualizer styles
- Full backup / restore and M3U playlist export

NOTE
Online metadata/artwork lookup uses public iTunes Search results when enabled. Automatic lyrics continue to use the lyric service configured by Localify.

Mini Player: the Mini Player button opens a separate Windows window that is pinned above other applications. Sleep Timer: choose a time after which Localify pauses playback; Fade out smoothly lowers volume during the final 20 seconds.

QUEUE & PLAYLISTS
- Queue keeps its full order when you jump to another song and preserves your scroll position.
- Queue state persists between launches when the underlying files are still available.
- Collapsible sidebar for a compact desktop layout.
- Playlists support custom cover images stored as a resized local copy.

CINEMA MODE
- Fullscreen cinema layout with lyric words animated individually onto the screen.
- Each synced lyric line replays a word-level entrance animation as the song progresses.
- Random Mix chooses a different animation family per lyric line for a more varied edit-style presentation.
- Beat-reactive mode uses the local Web Audio analyser to detect rhythmic onsets and pulse the artwork, lyric glow, rings and Cinema stage in time with the music.
- Beat reaction can be Off, Subtle, Medium or Strong, with Low / Medium / High sensitivity.
- Animation intensity can be Gentle, Normal, Punchy or Wild.
- Transition timing can be Dynamic, Smooth or Hard Cut.
- Cinema animation presets: Random Mix plus 50 word-motion families including horizontal rushes, vertical drops/rises, diagonals, pendulum, card turns, corkscrews, tunnels, gravity, center bursts, edge floats, stack motion, vertical waves, skate, swoop, whiplash, magnet, flicker and cascade.
- Each word gets independent motion parameters for direction, distance, rotation, scale and stagger timing.
- Beat reaction now pulses the individual lyric words as well as the Cinema background/stage.
- Vertical and diagonal word travel is built into the animation families rather than relying only on left/right entrances.
- Long lyric lines automatically switch to tighter typography so the full line stays inside the stage.
