$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-FreePort {
  $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
  $listener.Start()
  $port = ([System.Net.IPEndPoint]$listener.LocalEndpoint).Port
  $listener.Stop()
  return $port
}

function Get-MimeType([string]$path) {
  switch ([IO.Path]::GetExtension($path).ToLowerInvariant()) {
    '.html' { 'text/html; charset=utf-8'; break }
    '.css'  { 'text/css; charset=utf-8'; break }
    '.js'   { 'text/javascript; charset=utf-8'; break }
    '.json' { 'application/json; charset=utf-8'; break }
    '.svg'  { 'image/svg+xml'; break }
    '.png'  { 'image/png'; break }
    '.jpg'  { 'image/jpeg'; break }
    '.jpeg' { 'image/jpeg'; break }
    default { 'application/octet-stream' }
  }
}

$port = Get-FreePort
$prefix = "http://127.0.0.1:$port/"
$http = New-Object System.Net.HttpListener
$http.Prefixes.Add($prefix)
$http.Start()

$browser = @(
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $browser) { $browser = (Get-Command msedge.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -First 1) }
if (-not $browser) {
  $browser = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
  ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
}
if (-not $browser) { $browser = (Get-Command chrome.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -First 1) }
if (-not $browser) { $http.Stop(); throw 'Microsoft Edge or Google Chrome was not found.' }

# A dedicated browser profile makes the app window behave independently from ordinary browser windows.
$profile = Join-Path $root 'BrowserProfile'
New-Item -ItemType Directory -Force -Path $profile | Out-Null
$args = @('--app=' + $prefix + 'index.html', '--user-data-dir=' + $profile, '--disable-features=msSmartScreenProtection')
$browserProc = Start-Process -FilePath $browser -ArgumentList $args -PassThru

# Keep the separate Mini Player window pinned above other applications.
$topMost = Join-Path $root 'Set-Mini-TopMost.ps1'
if (Test-Path $topMost) {
  Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$topMost,'-ParentPid',$PID) | Out-Null
}

try {
  while (-not $browserProc.HasExited) {
    $ctx = $null
    try {
      $task = $http.GetContextAsync()
      if ($task.Wait(1000)) { $ctx = $task.Result }
    } catch { break }
    if ($null -eq $ctx) { continue }
    if ($browserProc.HasExited) { break }
    try {
      $relative = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
      if ([string]::IsNullOrWhiteSpace($relative)) { $relative = 'index.html' }
      $full = [IO.Path]::GetFullPath((Join-Path $root $relative))
      $rootFull = [IO.Path]::GetFullPath($root)
      $rootPrefix = $rootFull.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
      if (-not ($full.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase) -or $full.Equals($rootFull, [StringComparison]::OrdinalIgnoreCase))) {
        $ctx.Response.StatusCode = 403
        $msg = [Text.Encoding]::UTF8.GetBytes('Forbidden')
        $ctx.Response.OutputStream.Write($msg,0,$msg.Length)
      } elseif (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        $ctx.Response.StatusCode = 404
        $msg = [Text.Encoding]::UTF8.GetBytes('Not found')
        $ctx.Response.OutputStream.Write($msg,0,$msg.Length)
      } else {
        $bytes = [IO.File]::ReadAllBytes($full)
        $ctx.Response.StatusCode = 200
        $ctx.Response.ContentType = Get-MimeType $full
        $ctx.Response.ContentLength64 = $bytes.Length
        $ctx.Response.Headers['Cache-Control'] = 'no-cache'
        $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
      }
    } catch {
      try { $ctx.Response.StatusCode=500 } catch {}
    } finally {
      try { $ctx.Response.OutputStream.Close() } catch {}
    }
  }
}
finally {
  try { $http.Stop() } catch {}
  try { $http.Close() } catch {}
}
