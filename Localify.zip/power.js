/* Localify Power Pack — advanced local music features. */
(() => {
  'use strict';

  const onReady = (fn) => {
    if (window.LocalifyAPI?.ready) fn(window.LocalifyAPI);
    else window.addEventListener('localify-ready', () => fn(window.LocalifyAPI), { once: true });
  };

  onReady((api) => {
    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => [...r.querySelectorAll(s)];
    const esc = api.esc;
    const fmtTime = api.fmtTime;
    const toast = api.toast;
    const audio = api.audio;
    const state = api.state;

    const defaults = {
      ratings: {},
      stats: { plays: {}, seconds: {}, skips: 0, skipCounts: {}, daily: {}, sessions: [], lastPlayed: {} },
      eq: { bands: [0,0,0,0,0,0,0,0,0,0], preamp: 0, bass: 0, treble: 0, loudness: false, crossfade: 0, gapless: true, eqEnabled: true },
      features: { smartShuffle: false, dynamicTheme: false, folderMonitor: false, autoArtwork: false, duplicateScan: false },
      sleep: { until: 0, fade: true },
      mini: false,
      cinema: false,
      dropImport: true,
      autoBackup: false,
      lastBackup: 0,
      shortcuts: { playPause: 'Space', next: 'Ctrl+ArrowRight', previous: 'Ctrl+ArrowLeft', lyrics: 'Ctrl+Shift+L', search: 'Ctrl+K', mini: 'Ctrl+M' }
    };

    const mergeDeep = (base, src) => {
      const out = {...base};
      for (const [k, v] of Object.entries(src || {})) {
        if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object') out[k] = mergeDeep(base[k], v);
        else out[k] = v;
      }
      return out;
    };

    let power = mergeDeep(defaults, {});
    let powerSaveTimer = null;
    let monitorTimer = null;
    let sleepTimer = null;
    let statsLastTime = null;
    let statsLastSong = null;
    let artworkLookupsInFlight = new Map();
    let miniTimer = null;
    let dragSongId = null;
    let miniWindow = null;
    let miniChannel = null;
    let miniPollTimer = null;

    const powerSave = () => {
      clearTimeout(powerSaveTimer);
      powerSaveTimer = setTimeout(() => api.dbPut('config', structuredClone(power), 'powerState').catch(() => {}), 120);
    };

    async function loadPower() {
      try { power = mergeDeep(defaults, await api.dbGet('config', 'powerState') || {}); } catch {}
      // Mini player windows are session-only; never resurrect a stale external window.
      power.mini = false;
      state.ratings = power.ratings;
      window.__localifyPower = power;
      window.__localifyEQSettings = power.eq;
      applyAudioConfigToGraph();
      startAutomation();
      startSleepWatcher();
      if(power.autoBackup && (!power.lastBackup || Date.now()-power.lastBackup>7*86400000)) setTimeout(()=>toast('It has been a while — consider exporting a Localify backup.'),2400);
      installMediaSession();
      createPowerUI();
      refreshPowerUI();
    }

    function qualityInfo(song) {
      const kbps = song?.bitrate || (song?.size && song?.duration ? Math.round((song.size * 8 / song.duration) / 1000) : 0);
      if (!kbps) return {label: 'Unknown quality', kbps: 0};
      const label = kbps >= 280 ? 'High quality' : kbps >= 190 ? 'Good quality' : kbps >= 128 ? 'Standard' : 'Low quality';
      return {label, kbps};
    }

    function rateFor(id) { return Math.max(0, Math.min(5, Number(power.ratings[id] || 0))); }
    function ratingStars(id, compact = false) {
      const r = rateFor(id);
      return `<button class="power-rating ${compact ? 'compact' : ''}" data-rate-id="${esc(id)}" title="${r ? `${r}/5 rating — click to change` : 'Rate this song'}"><span>${'★'.repeat(r)}${'☆'.repeat(5-r)}</span>${compact ? '' : `<small>${r ? `${r}/5` : 'Rate'}</small>`}</button>`;
    }

    function trackPlays(id) { return Number(power.stats.plays[id] || 0); }
    function trackSeconds(id) { return Number(power.stats.seconds[id] || 0); }
    function trackLast(id) { return Number(power.stats.lastPlayed[id] || 0); }

    function incrementPlay(id) {
      if (!id) return;
      power.stats.plays[id] = trackPlays(id) + 1;
      power.stats.lastPlayed[id] = Date.now();
      power.stats.sessions.push({id, at: Date.now()});
      power.stats.sessions = power.stats.sessions.slice(-5000);
      powerSave();
    }

    audio.addEventListener('play', () => {
      const id = state.currentId;
      if (id) incrementPlay(id);
      statsLastSong = id;
      statsLastTime = audio.currentTime;
      updateMediaSession();
      updateMini();
      publishMiniState();
      applyEffectiveVolume();
    });
    audio.addEventListener('pause', () => { statsLastTime = null; updateMediaSession(); updateMini(); publishMiniState(); });
    audio.addEventListener('timeupdate', () => {
      const id = state.currentId;
      if (id && !audio.paused && statsLastSong === id && statsLastTime != null) {
        const delta = Math.min(1.2, Math.max(0, audio.currentTime - statsLastTime));
        if (delta > 0 && delta < 1.5) {
          power.stats.seconds[id] = trackSeconds(id) + delta;
          const day = localDateKey();
          power.stats.daily[day] = Number(power.stats.daily[day] || 0) + delta / 3600;
          if (Math.random() < 0.03) powerSave();
        }
        statsLastTime = audio.currentTime;
      } else {
        statsLastSong = id;
        statsLastTime = audio.currentTime;
      }
      updateMini();
      publishMiniState();
      maybeSoftCrossfade();
    });

    function markSkip() {
      if (state.currentId && audio.currentTime < Math.min(30, Number(audio.duration || 30))) {
        power.stats.skips = Number(power.stats.skips || 0) + 1;
        power.stats.skipCounts[state.currentId] = Number(power.stats.skipCounts[state.currentId] || 0) + 1;
        powerSave();
      }
    }
    ['nextBtn','prevBtn','focusNextBtn','focusPrevBtn'].forEach(id => $("#" + id)?.addEventListener('click', markSkip));

    // ---------------- Audio engine / EQ ----------------
    function ensureEqState() {
      power.eq.bands = Array.isArray(power.eq.bands) && power.eq.bands.length === 10 ? power.eq.bands : defaults.eq.bands.slice();
      window.__localifyEQSettings = power.eq;
    }

    function applyAudioConfigToGraph() {
      ensureEqState();
      const g = window.__localifyAudioGraph;
      if (!g) return;
      try {
        g.preamp.gain.value = Math.pow(10, Number(power.eq.preamp || 0) / 20);
        g.bass.gain.value = Number(power.eq.bass || 0);
        g.treble.gain.value = Number(power.eq.treble || 0);
        g.filters.forEach((f, i) => f.gain.value = power.eq.eqEnabled === false ? 0 : Number(power.eq.bands[i] || 0));
      } catch {}
    }

    function setupAudioGraphFromAppGraph() {
      const g = window.__localifyAudioGraph;
      if (g) applyAudioConfigToGraph();
    }

    const EQ_PRESETS = {
      flat: [0,0,0,0,0,0,0,0,0,0],
      pop: [-1,1,2,3,2,0,-1,-1,1,2],
      rock: [4,3,2,0,-1,-1,1,2,3,4],
      hiphop: [5,4,2,0,-1,0,2,3,3,2],
      classical: [3,2,1,0,-1,0,1,2,3,3],
      vocal: [-2,-1,0,2,4,4,3,2,1,0],
      bass: [7,6,5,3,1,0,0,0,0,0],
      electronic: [4,3,1,0,0,2,3,3,4,4]
    };

    function updateEqBand(i, val) {
      ensureEqState();
      power.eq.bands[i] = Number(val);
      window.__localifyEQSettings = power.eq;
      const g = window.__localifyAudioGraph;
      if (g?.filters?.[i]) g.filters[i].gain.value = power.eq.bands[i];
      powerSave();
    }

    function updateAudioConfig(patch) {
      power.eq = {...power.eq, ...patch};
      if (patch.bands) power.eq.bands = [...patch.bands];
      window.__localifyEQSettings = power.eq;
      applyAudioConfigToGraph();
      powerSave();
      refreshPowerUI();
    }

    function applyEffectiveVolume() {
      let v = Number(state.volume ?? audio.volume ?? 0.8);
      const s = state.library.find(x => x.id === state.currentId);
      if (power.eq.loudness && s?.replayGainDb != null) v *= Math.pow(10, Number(s.replayGainDb) / 20);
      audio.volume = Math.max(0, Math.min(1, v));
    }

    function updateLoudnessFromSong(song) { if (song) applyEffectiveVolume(); }

    // Patch the app's existing visualizer engine via global settings consumed by its init path.
    window.__localifyPowerAudioReady = setupAudioGraphFromAppGraph;

    // ---------------- Library filters ----------------
    function getFilteredLibrary() {
      const filters = power.libraryFilters || (power.libraryFilters = {artist:'',genre:'',rating:0,quality:'all',minDuration:0,maxDuration:0});
      let list = [...state.library];
      const q = state.search?.trim().toLowerCase();
      if (q) list = list.filter(s => [s.title,s.artist,s.album,s.genre,s.path].some(v => String(v || '').toLowerCase().includes(q)));
      if (filters.artist) list = list.filter(s => (s.artist || '') === filters.artist);
      if (filters.genre) list = list.filter(s => (s.genre || '') === filters.genre);
      if (filters.rating) list = list.filter(s => rateFor(s.id) >= Number(filters.rating));
      if (filters.quality !== 'all') list = list.filter(s => {
        const ql = qualityInfo(s).kbps;
        return filters.quality === 'lossless' ? /flac|wav|aiff/i.test(s.name || s.path || '') : filters.quality === 'high' ? ql >= 280 : ql > 0 && ql < 190;
      });
      if (filters.minDuration) list = list.filter(s => Number(s.duration || 0) >= Number(filters.minDuration) * 60);
      if (filters.maxDuration) list = list.filter(s => Number(s.duration || 0) <= Number(filters.maxDuration) * 60);
      return list;
    }

    function artistsMap() {
      const map = new Map();
      for (const s of state.library) {
        const k = s.artist || 'Unknown artist';
        const a = map.get(k) || {name:k, songs:[], plays:0, seconds:0, art:s.art || null};
        a.songs.push(s); a.plays += trackPlays(s.id); a.seconds += trackSeconds(s.id); if (!a.art && s.art) a.art = s.art; map.set(k, a);
      }
      return map;
    }

    function topArtists(limit=8) { return [...artistsMap().values()].sort((a,b)=>b.seconds-a.seconds || b.plays-a.plays).slice(0,limit); }
    function topSongs(limit=10) { return [...state.library].sort((a,b)=>trackSeconds(b.id)-trackSeconds(a.id) || trackPlays(b.id)-trackPlays(a.id)).slice(0,limit); }

    // ---------------- Recommendations / listening context ----------------
    function scoreSimilarity(seed, song) {
      if (!seed || seed.id === song.id) return -999;
      let score = Math.random() * 2;
      if ((seed.artist || '') === (song.artist || '')) score += 40;
      if ((seed.genre || '') && (seed.genre || '') === (song.genre || '')) score += 22;
      if ((seed.album || '') && (seed.album || '') === (song.album || '')) score += 10;
      if (Math.abs(Number(seed.duration || 0) - Number(song.duration || 0)) < 45) score += 3;
      score += rateFor(song.id) * 2;
      score += Math.max(0, 3 - ((Date.now() - trackLast(song.id)) / 86400000)) * .5;
      return score;
    }
    function recommendations(seed) {
      const s = seed || state.library.find(x=>x.id===state.currentId);
      if (!s) return [...state.library].slice(0,12);
      return [...state.library].sort((a,b)=>scoreSimilarity(s,b)-scoreSimilarity(s,a)).slice(0,12);
    }

    function fillSmartQueue(seedId = state.currentId) {
      const pool = smartShufflePool();
      const ids = pool.filter(s => s.id !== state.currentId).map(s=>s.id);
      const existing = new Set(state.queue);
      for (const id of ids) if (!existing.has(id)) state.queue.push(id);
      state.queueIndex = Math.max(0, state.queue.findIndex(id=>id===state.currentId));
      state.queueMode = power.features.smartShuffle ? 'smart' : 'normal';
      api.persist();
      api.renderQueue?.();
    }
    function smartShufflePool() {
      const unseen = state.library.filter(s => trackLast(s.id) === 0);
      const rated = [...state.library].filter(s => rateFor(s.id) > 0).sort((a,b)=>rateFor(b.id)-rateFor(a.id));
      const recently = [...state.library].filter(s=>Date.now()-trackLast(s.id)<7*86400000);
      return shuffle([...unseen,...rated,...recently,...state.library]).filter((s,i,a)=>a.findIndex(x=>x.id===s.id)===i);
    }
    function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

    function maybeSoftCrossfade() {
      const seconds = Number(power.eq.crossfade || 0);
      if (!seconds || !Number.isFinite(audio.duration) || !state.currentId || audio.paused) return;
      const remaining = audio.duration - audio.currentTime;
      if (remaining <= seconds && remaining > 0.2 && !audio.dataset.crossfading) {
        audio.dataset.crossfading = '1';
        const startVol = audio.volume;
        const begin = performance.now();
        const fade = () => {
          const t = Math.min(1, (performance.now()-begin)/(seconds*1000));
          audio.volume = startVol*(1-t);
          if (t < 1 && !audio.paused) requestAnimationFrame(fade);
          else { delete audio.dataset.crossfading; audio.volume = 0; api.nextTrack(); setTimeout(()=>{ applyEffectiveVolume(); },120); }
        };
        requestAnimationFrame(fade);
      }
    }

    // ---------------- Media session ----------------
    function updateMediaSession() {
      if (!('mediaSession' in navigator)) return;
      const s = state.library.find(x=>x.id===state.currentId);
      if (s) {
        try {
          navigator.mediaSession.metadata = new MediaMetadata({title:s.title||'Unknown',artist:s.artist||'Unknown artist',album:s.album||'',artwork:s.art?[{src:s.art,sizes:'512x512',type:'image/jpeg'}]:[]});
          navigator.mediaSession.playbackState = audio.paused ? 'paused' : 'playing';
        } catch {}
      }
    }
    function installMediaSession() {
      if (!('mediaSession' in navigator)) return;
      const handlers = {
        play:()=>audio.play(), pause:()=>audio.pause(), nexttrack:()=>api.nextTrack(), previoustrack:()=>api.previousTrack(), seekbackward:()=>{audio.currentTime=Math.max(0,audio.currentTime-10)}, seekforward:()=>{audio.currentTime=Math.min(audio.duration||Infinity,audio.currentTime+10)}
      };
      for (const [name, fn] of Object.entries(handlers)) { try{navigator.mediaSession.setActionHandler(name,fn);}catch{} }
    }

    // ---------------- Library tools ----------------
    function findDuplicates() {
      const groups = new Map();
      for (const s of state.library) {
        const k = `${String(s.artist||'').trim().toLowerCase()}|${String(s.title||'').trim().toLowerCase()}|${Math.round(Number(s.duration||0)/3)}`;
        const arr = groups.get(k) || []; arr.push(s); groups.set(k,arr);
      }
      return [...groups.values()].filter(g=>g.length>1);
    }

    async function lookupArtwork(song) {
      if (!song) return null;
      if (artworkLookupsInFlight.has(song.id)) return artworkLookupsInFlight.get(song.id);
      const promise = (async()=>{
        const term = encodeURIComponent(`${song.artist||''} ${song.title||''}`.trim());
        const r = await fetch(`https://itunes.apple.com/search?term=${term}&entity=song&limit=8`);
        if (!r.ok) throw new Error('Artwork service unavailable');
        const data = await r.json();
        const item=(data.results||[])[0];
        return item?.artworkUrl100 ? item.artworkUrl100.replace('100x100bb','1000x1000bb') : null;
      })();
      artworkLookupsInFlight.set(song.id,promise);
      promise.finally(()=>artworkLookupsInFlight.delete(song.id));
      return promise;
    }

    async function saveArtworkOnly(song, artUrl) {
      if(!song || !artUrl) return song;
      const updated={...song,art:artUrl};
      await api.dbPut('songs',updated);
      const i=state.library.findIndex(x=>x.id===song.id);
      if(i>=0) state.library[i]=updated;
      api.persist();
      if(state.currentId===song.id) api.renderFocusOverlay?.(updated);
      return updated;
    }

    // ---------------- Settings UI ----------------
    function openAdvancedSettings() {
      const eq=power.eq;
      api.openModal(`<div class="power-modal"><div class="power-modal-head"><div><h2>Localify Studio</h2><p>Audio, smart playback, automation, personalisation and power tools.</p></div><button class="icon-btn" id="powerClose">×</button></div><div class="power-tabs">${['audio','playback','library','data','shortcuts'].map((x,i)=>`<button class="power-tab ${i===0?'active':''}" data-power-tab="${x}">${x[0].toUpperCase()+x.slice(1)}</button>`).join('')}</div><div id="powerSettingsBody"></div></div>`);
      const body=$('#powerSettingsBody');
      function renderTab(tab){
        if(tab==='audio') body.innerHTML = `<div class="power-section"><div class="power-section-title"><div><strong>10-band equalizer</strong><span>Real-time Web Audio EQ. Changes apply immediately when the audio graph is active.</span></div><label class="switch"><input id="eqEnabled" type="checkbox" ${eq.eqEnabled!==false?'checked':''}><span></span></label></div><div class="eq-wrap"><div class="eq-sliders">${[32,64,125,250,500,1000,2000,4000,8000,16000].map((f,i)=>`<label><input data-eq-band="${i}" type="range" min="-12" max="12" step="0.5" value="${eq.bands[i]||0}"><span>${f>=1000?`${f/1000}k`:f} <b>${Number(eq.bands[i]||0).toFixed(1)}</b></span></label>`).join('')}</div></div><div class="power-grid-3"><label>Preset<select id="eqPreset" class="sort-select">${Object.keys(EQ_PRESETS).map(k=>`<option value="${k}">${k[0].toUpperCase()+k.slice(1)}</option>`).join('')}</select></label><label>Preamp<select id="preampSelect" class="sort-select">${[-6,-3,0,3,6].map(v=>`<option ${Number(eq.preamp)===v?'selected':''}>${v} dB</option>`).join('')}</select></label><label>Bass boost<select id="bassSelect" class="sort-select">${[0,2,4,6,8].map(v=>`<option ${Number(eq.bass)===v?'selected':''}>${v} dB</option>`).join('')}</select></label><label>Treble<select id="trebleSelect" class="sort-select">${[0,2,4,6,8].map(v=>`<option ${Number(eq.treble)===v?'selected':''}>${v} dB</option>`).join('')}</select></label><label>Crossfade<select id="crossfadeSelect" class="sort-select">${[0,2,4,6,8,10,12].map(v=>`<option value="${v}" ${Number(eq.crossfade)===v?'selected':''}>${v ? `${v}s` : 'Off'}</option>`).join('')}</select></label><label>Playback<select id="gaplessSelect" class="sort-select"><option value="gapless" ${eq.gapless!==false?'selected':''}>Gapless preference</option><option value="fade">Soft transitions</option></select></label></div><label class="settings-toggle"><input id="loudnessToggle" type="checkbox" ${eq.loudness?'checked':''}><span><strong>Loudness normalisation</strong><small>Uses ReplayGain track tags when present.</small></span></label><label class="power-label" style="margin-top:14px">Visualizer style<select id="powerVisualizerStyle" class="sort-select"><option value="bars" ${state.visualizerStyle==='bars'?'selected':''}>Spectrum bars</option><option value="wave" ${state.visualizerStyle==='wave'?'selected':''}>Wave</option><option value="dots" ${state.visualizerStyle==='dots'?'selected':''}>Dots</option><option value="mirror" ${state.visualizerStyle==='mirror'?'selected':''}>Mirror</option><option value="circle" ${state.visualizerStyle==='circle'?'selected':''}>Circular</option></select></label></div>`;
        if(tab==='playback') body.innerHTML = `<div class="power-section"><div class="power-section-title"><div><strong>Smart playback</strong><span>Let Localify choose what plays next from your own library.</span></div></div><label class="settings-toggle"><input id="smartShuffleToggle" type="checkbox" ${power.features.smartShuffle?'checked':''}><span><strong>Smart Shuffle</strong><small>Prefers unrated/unheard songs and avoids immediate repeats.</small></span></label><label class="settings-toggle"><input id="dynamicThemeToggle" type="checkbox" ${power.features.dynamicTheme?'checked':''}><span><strong>Dynamic album themes</strong><small>Extract a colour from the current artwork and use it as the accent.</small></span></label></div>`;
        if(tab==='library') body.innerHTML = `<div class="power-section"><div class="power-section-title"><div><strong>Automation</strong><span>Keep the local library fresh without manual scanning.</span></div></div><label class="settings-toggle"><input id="folderMonitorToggle" type="checkbox" ${power.features.folderMonitor?'checked':''}><span><strong>Watch music folders</strong><small>Rescans remembered folders every 2 minutes while Localify is open.</small></span></label><label class="settings-toggle"><input id="autoArtworkToggle" type="checkbox" ${power.features.autoArtwork?'checked':''}><span><strong>Automatic artwork</strong><small>When artwork is missing, try a public album-art search.</small></span></label><div class="power-section-title" style="margin-top:18px"><div><strong>Library filters</strong><span>These are available on Your Library.</span></div></div><button class="btn" id="openLibraryStudio">Open Library filters</button><button class="btn" id="scanDuplicatesStudio">Find duplicates</button></div>`;
        if(tab==='data') body.innerHTML = `<div class="power-section"><div class="power-section-title"><div><strong>Backup & restore</strong><span>Audio files stay where they are; Localify backs up metadata, playlists, history, ratings and settings.</span></div></div><div class="power-actions"><button class="btn primary" id="fullBackupBtn">Export full Localify backup</button><button class="btn" id="fullRestoreBtn">Restore backup</button><button class="btn" id="exportM3U">Export M3U playlists</button></div><label class="settings-toggle"><input id="autoBackupToggle" type="checkbox" ${power.autoBackup?'checked':''}><span><strong>Automatic backup reminder</strong><small>Creates a local reminder every 7 days to export a backup.</small></span></label><div class="notice"><b>Portable:</b> Backup files do not contain your MP3 audio. Re-add the music folder on the new PC, then restore this backup.</div></div>`;
        if(tab==='shortcuts') body.innerHTML = `<div class="power-section"><div class="power-section-title"><div><strong>Keyboard shortcuts</strong><span>These work globally while Localify is focused.</span></div></div><div class="shortcut-list">${[['Play / pause','playPause'],['Next track','next'],['Previous track','previous'],['Search','search'],['Focus lyrics','lyrics'],['Mini player','mini']].map(([n,k])=>`<div class="shortcut-row"><span>${n}</span><kbd>${esc(power.shortcuts[k])}</kbd></div>`).join('')}</div><div class="notice">Shortcuts are shown here so you always know what the current controls are. Media-key support is automatic when Windows/browser media session is available.</div></div>`;
        wireTabEvents(tab);
      }
      function wireTabEvents(tab){
        $$('.power-tab').forEach(b=>b.onclick=()=>{$$('.power-tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderTab(b.dataset.powerTab);});
        if(tab==='audio'){
          $$('#powerSettingsBody [data-eq-band]').forEach(inp=>inp.oninput=()=>{updateEqBand(Number(inp.dataset.eqBand),Number(inp.value));inp.nextElementSibling.querySelector('b').textContent=Number(inp.value).toFixed(1);});
          $('#eqEnabled').onchange=e=>updateAudioConfig({eqEnabled:e.target.checked});
          $('#eqPreset').onchange=e=>updateAudioConfig({bands:EQ_PRESETS[e.target.value].slice()});
          $('#preampSelect').onchange=e=>updateAudioConfig({preamp:Number(e.target.value)});
          $('#bassSelect').onchange=e=>updateAudioConfig({bass:Number(e.target.value)});
          $('#trebleSelect').onchange=e=>updateAudioConfig({treble:Number(e.target.value)});
          $('#crossfadeSelect').onchange=e=>updateAudioConfig({crossfade:Number(e.target.value)});
          $('#gaplessSelect').onchange=e=>updateAudioConfig({gapless:e.target.value==='gapless'});
          $('#loudnessToggle').onchange=e=>updateAudioConfig({loudness:e.target.checked});
          $('#powerVisualizerStyle').onchange=e=>{state.visualizerStyle=e.target.value;api.persist();};
        }
        if(tab==='playback'){
          $('#smartShuffleToggle').onchange=e=>{power.features.smartShuffle=e.target.checked;if(e.target.checked){state.queue=[];fillSmartQueue(state.currentId);}powerSave();refreshPowerUI();};
          $('#dynamicThemeToggle').onchange=e=>{power.features.dynamicTheme=e.target.checked;powerSave();if(e.target.checked)applyDynamicTheme(state.library.find(s=>s.id===state.currentId));};
        }
        if(tab==='library'){
          $('#folderMonitorToggle').onchange=e=>{power.features.folderMonitor=e.target.checked;powerSave();startAutomation();};
          $('#autoArtworkToggle').onchange=e=>{power.features.autoArtwork=e.target.checked;powerSave();};
          $('#openLibraryStudio').onclick=()=>{api.closeModal();showEnhancedLibrary();};
          $('#scanDuplicatesStudio').onclick=()=>{api.closeModal();showTools('duplicates');};
        }
        if(tab==='data'){
          $('#fullBackupBtn').onclick=exportFullBackup;
          $('#fullRestoreBtn').onclick=importFullBackup;
          $('#exportM3U').onclick=exportM3U;
          $('#autoBackupToggle').onchange=e=>{power.autoBackup=e.target.checked;powerSave();};
        }
        if(tab==='shortcuts'){}
      }
      $('#powerClose').onclick=api.closeModal;
      renderTab('audio');
    }

    // ---------------- UI views ----------------
    function songTablePower(list, withEdit=true) {
      if (!list.length) return `<div class="empty"><div><div class="empty-icon">♫</div><h3>No songs found</h3><p>Try changing the filters or add another music folder.</p></div></div>`;
      return `<div class="table-wrap"><table class="song-table power-table"><thead><tr><th>Title</th><th>Album</th><th>Genre</th><th>Quality</th><th>Rating</th><th>Time</th></tr></thead><tbody>${list.map(s=>{const q=qualityInfo(s);return `<tr class="song-row ${s.id===state.currentId?'playing':''}" data-song-id="${esc(s.id)}" draggable="true"><td><div class="title-cell">${api.art(s)}<div class="title-meta"><div class="title-main">${esc(s.title||s.name)}</div><div class="title-sub">${esc(s.artist||'Unknown artist')}</div></div></div></td><td>${esc(s.album||'Unknown album')}</td><td>${esc(s.genre||'')}</td><td><span class="quality-badge">${esc(q.kbps?`${q.kbps} kbps`:q.label)}</span></td><td>${ratingStars(s.id,true)}</td><td>${fmtTime(s.duration)}</td></tr>`;}).join('')}</tbody></table></div>`;
    }

    function homePower() {
      const top = topSongs(6), artists = topArtists(6), recs = recommendations(state.library.find(s=>s.id===state.currentId)).slice(0,6);
      return `<div class="power-home-grid"><section class="power-spotlight"><div class="eyebrow">Your local listening</div><h1>Made for you.</h1><p>Personal recommendations, stats and tools built entirely from your own library.</p><div class="hero-stats"><span><strong>${formatHours(totalSeconds())}</strong> listened</span><span><strong>${Object.values(power.stats.plays).reduce((a,b)=>a+Number(b||0),0)}</strong> plays</span><span><strong>${state.library.length}</strong> tracks</span><span><strong>${state.playlists.length}</strong> playlists</span></div><div class="power-actions"><button class="btn" id="homeStatsBtn">View statistics</button></div></section><section class="power-panel"><div class="power-panel-title">Quick controls</div><div class="quick-grid"><button data-power-action="eq">🎚 EQ</button><button data-power-action="smart">🧠 Smart shuffle</button><button data-power-action="timer">⏱ Sleep timer</button><button data-power-action="mini">▣ Mini player</button><button data-power-action="tools">🛠 Tools</button><button data-power-action="backup">↥ Backup</button></div></section></div><section class="section"><div class="section-title-row"><h2>Because you listen</h2><button class="section-link" id="homeForYouBtn">Open For You</button></div><div class="cards">${recs.map(api.card).join('')}</div></section><section class="section"><div class="section-title-row"><h2>Top songs</h2></div>${songTablePower(top,false)}</section><section class="section"><div class="section-title-row"><h2>Top artists</h2></div><div class="artist-grid">${artists.map(a=>`<button class="artist-card" data-artist-filter="${esc(a.name)}">${a.art?`<img src="${a.art}" alt="">`:'<span>♪</span>'}<strong>${esc(a.name)}</strong><small>${formatHours(a.seconds)} listened</small></button>`).join('')}</div></section>`;
    }

    function statsView() {
      const total = totalSeconds(); const plays = Object.values(power.stats.plays).reduce((a,b)=>a+Number(b||0),0); const top = topSongs(10); const daily = lastDays(14);
      const maxDay = Math.max(1, ...daily.map(d=>d.value));
      const monthly = lastMonths(12); const maxMonth = Math.max(1, ...monthly.map(d=>d.value));
      const topSkips = [...state.library].sort((a,b)=>Number(power.stats.skipCounts?.[b.id]||0)-Number(power.stats.skipCounts?.[a.id]||0)).filter(s=>Number(power.stats.skipCounts?.[s.id]||0)>0).slice(0,8);
      const genreMap = new Map(); for(const song of state.library){const g=song.genre||'Unknown';genreMap.set(g,(genreMap.get(g)||0)+trackSeconds(song.id));} const topGenres=[...genreMap.entries()].sort((a,b)=>b[1]-a[1]).slice(0,8);
      return `<div class="view-head"><div><div class="eyebrow">Analytics</div><div class="view-title">Your listening</div><div class="view-subtitle">Private stats generated from your Localify listening history.</div></div><div class="actions"><button class="btn" id="clearStatsBtn">Clear stats</button><button class="btn" id="exportStatsBtn">Export stats</button></div></div><div class="stats-hero-grid"><div class="stat-card big"><span>Listening time</span><strong>${formatHours(total)}</strong><small>${fmtTime(total)}</small></div><div class="stat-card big"><span>Plays</span><strong>${plays}</strong><small>${power.stats.skips || 0} early skips</small></div><div class="stat-card big"><span>Artists</span><strong>${artistsMap().size}</strong><small>${state.library.length} tracks</small></div><div class="stat-card big"><span>Rated tracks</span><strong>${Object.values(power.ratings).filter(v=>v>0).length}</strong><small>out of ${state.library.length}</small></div></div><section class="section"><div class="section-title-row"><h2>Listening — last 14 days</h2></div><div class="day-chart">${daily.map(d=>`<div class="day-bar"><div class="day-value" style="height:${Math.max(4,(d.value/maxDay)*150)}px"><span>${d.value>=60?formatHours(d.value):''}</span></div><small>${d.label}</small></div>`).join('')}</div></section><section class="section"><div class="section-title-row"><h2>Listening — last 12 months</h2></div><div class="day-chart">${monthly.map(d=>`<div class="day-bar"><div class="day-value month" style="height:${Math.max(4,(d.value/maxMonth)*150)}px"><span>${d.value>=3600?formatHours(d.value):''}</span></div><small>${d.label}</small></div>`).join('')}</div></section><div class="stats-split"><section class="section"><div class="section-title-row"><h2>Top songs</h2></div>${songTablePower(top,false)}</section><section class="section"><div class="section-title-row"><h2>Top genres</h2></div><div class="rank-list">${topGenres.map((g,i)=>`<div class="rank-row"><b>${i+1}</b><span>${esc(g[0])}</span><small>${formatHours(g[1])}</small></div>`).join('')}</div><div class="section-title-row" style="margin-top:18px"><h2>Most skipped</h2></div><div class="rank-list">${topSkips.length?topSkips.map((s,i)=>`<div class="rank-row"><b>${i+1}</b>${s.art?`<img src="${s.art}" alt="">`:'<span class="rank-art">♪</span>'}<span>${esc(s.title)}</span><small>${Number(power.stats.skipCounts[s.id]||0)} skips</small></div>`).join(''):'<div class="notice">No early skips recorded yet.</div>'}</div></section></div><section class="section"><div class="section-title-row"><h2>Top artists</h2></div><div class="rank-list">${topArtists(10).map((a,i)=>`<div class="rank-row"><b>${i+1}</b>${a.art?`<img src="${a.art}" alt="">`:'<span class="rank-art">♪</span>'}<span>${esc(a.name)}</span><small>${formatHours(a.seconds)}</small></div>`).join('')}</div></section>`;
    }

    function forYouView() {
      const seed = state.library.find(s=>s.id===state.currentId) || [...state.library].sort((a,b)=>trackPlays(b.id)-trackPlays(a.id))[0];
      const recs = recommendations(seed).slice(0,12);
      const forgotten = [...state.library].filter(s=>trackLast(s.id)>0 && Date.now()-trackLast(s.id)>21*86400000).sort((a,b)=>trackLast(a.id)-trackLast(b.id)).slice(0,6);
      const favourites = [...state.library].filter(s=>rateFor(s.id)>=4 || state.favorites.has(s.id)).sort((a,b)=>trackSeconds(b.id)-trackSeconds(a.id)).slice(0,6);
      return `<div class="view-head"><div><div class="eyebrow">Your listening</div><div class="view-title">For You</div><div class="view-subtitle">Recommendations made only from your local library and listening history.</div></div><div class="actions"></div></div><section class="section"><div class="section-title-row"><h2>Recommended for you</h2></div><div class="cards">${recs.map(api.card).join('')}</div></section>${forgotten.length?`<section class="section"><div class="section-title-row"><h2>Forgotten favourites</h2></div><div class="cards">${forgotten.map(api.card).join('')}</div></section>`:''}${favourites.length?`<section class="section"><div class="section-title-row"><h2>Your highest-rated</h2></div>${songTablePower(favourites,false)}</section>`:''}`;
    }

    function toolsView(mode='overview') {
      if (mode==='duplicates') {
        const groups=findDuplicates();
        return `<div class="view-head"><div><div class="eyebrow">Library tools</div><div class="view-title">Duplicate detector</div><div class="view-subtitle">Matches title + artist + near-identical duration to find likely duplicates.</div></div><div class="actions"><button class="btn" id="rescanDupBtn">Rescan</button></div></div>${groups.length?groups.map((g,i)=>`<section class="duplicate-group"><div class="duplicate-head"><strong>Possible duplicate ${i+1}</strong><span>${g.length} copies</span></div>${songTablePower(g)}</section>`).join(''):`<div class="empty"><div><div class="empty-icon">✓</div><h3>No likely duplicates found</h3><p>Your library currently looks clean.</p></div></div>`}`;
      }
      return `<div class="view-head"><div><div class="eyebrow">Power tools</div><div class="view-title">Library toolkit</div><div class="view-subtitle">Maintenance, artwork, backups and quality tools.</div></div></div><div class="tool-grid"><button class="tool-card" data-tool="duplicates"><strong>Duplicate detector</strong><span>Find likely duplicate files.</span></button><button class="tool-card" data-tool="artwork"><strong>Artwork finder</strong><span>Find album artwork automatically.</span></button><button class="tool-card" data-tool="backup"><strong>Full backup</strong><span>Export Localify metadata and settings.</span></button><button class="tool-card" data-tool="timer"><strong>Sleep timer</strong><span>Stop or fade playback automatically.</span></button><button class="tool-card" data-tool="mini"><strong>Mini player</strong><span>Keep a compact player on top.</span></button><button class="tool-card" data-tool="studio"><strong>Audio studio</strong><span>Equalizer, crossfade and normalisation.</span></button></div><section class="section"><div class="section-title-row"><h2>Library quality</h2></div><div class="stats-hero-grid"><div class="stat-card big"><span>Lossless</span><strong>${state.library.filter(s=>/flac|wav|aiff/i.test(s.name||s.path||'')).length}</strong><small>tracks</small></div><div class="stat-card big"><span>High quality</span><strong>${state.library.filter(s=>qualityInfo(s).kbps>=280).length}</strong><small>≥ 280 kbps</small></div><div class="stat-card big"><span>No artwork</span><strong>${state.library.filter(s=>!s.art).length}</strong><small>tracks</small></div><div class="stat-card big"><span>Unrated</span><strong>${state.library.filter(s=>rateFor(s.id)===0).length}</strong><small>tracks</small></div></div></section>`;
    }

    function localDateKey(date=new Date()){const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,'0'),d=String(date.getDate()).padStart(2,'0');return `${y}-${m}-${d}`;}
    function formatHours(sec){const h=Number(sec||0)/3600;return h>=100?`${h.toFixed(0)}h`:h>=10?`${h.toFixed(1)}h`:h>=1?`${h.toFixed(1)}h`:`${Math.round(Number(sec||0)/60)}m`;}
    function totalSeconds(){return Object.values(power.stats.seconds).reduce((a,b)=>a+Number(b||0),0);}
    function lastDays(n){const out=[];for(let i=n-1;i>=0;i--){const d=new Date(Date.now()-i*86400000);const key=d.toISOString().slice(0,10);out.push({key,label:d.toLocaleDateString(undefined,{weekday:'short'}),value:Number(power.stats.daily[key]||0)});}return out;}
    function lastMonths(n){const out=[];const now=new Date();for(let i=n-1;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0');let value=0;for(const [key,v] of Object.entries(power.stats.daily)){if(key.startsWith(`${y}-${m}-`))value+=Number(v||0);}out.push({key:`${y}-${m}`,label:d.toLocaleDateString(undefined,{month:'short'}),value});}return out;}

    function showView(kind, extra=null) {
      if (kind==='stats'){state.view='power-stats';$('#mainView').innerHTML=statsView();}
      else if(kind==='foryou'){state.view='power-foryou';$('#mainView').innerHTML=forYouView();}
      else if(kind==='tools'){state.view='power-tools';$('#mainView').innerHTML=toolsView(extra||'overview');}
      else if(kind==='library-enhanced'){state.view='library';showEnhancedLibrary(true);return;}
      wirePowerView(kind,extra);
      api.renderSidebar();
    }

    function showEnhancedLibrary(initial=false) {
      const filters=power.libraryFilters || (power.libraryFilters={artist:'',genre:'',rating:0,quality:'all',minDuration:0,maxDuration:0});
      const artists=[...new Set(state.library.map(s=>s.artist).filter(Boolean))].sort();
      const genres=[...new Set(state.library.map(s=>s.genre).filter(Boolean))].sort();
      const list=getFilteredLibrary();
      $('#mainView').innerHTML=`<div class="view-head"><div><div class="eyebrow">Library</div><div class="view-title">Your Library</div><div class="view-subtitle">${list.length} of ${state.library.length} tracks · advanced filters</div></div><div class="actions"><button class="btn" id="advancedRescan">Rescan</button><button class="btn primary" id="advancedPlay">Play visible</button></div></div><div class="filter-bar"><input id="librarySearchPower" class="modal-input" placeholder="Filter this library…" value="${esc(state.search||'')}"><select id="filterArtist" class="sort-select"><option value="">All artists</option>${artists.map(v=>`<option ${filters.artist===v?'selected':''}>${esc(v)}</option>`).join('')}</select><select id="filterGenre" class="sort-select"><option value="">All genres</option>${genres.map(v=>`<option ${filters.genre===v?'selected':''}>${esc(v)}</option>`).join('')}</select><select id="filterRating" class="sort-select"><option value="0">Any rating</option>${[1,2,3,4,5].map(v=>`<option value="${v}" ${Number(filters.rating)===v?'selected':''}>${v}+ stars</option>`).join('')}</select><select id="filterQuality" class="sort-select"><option value="all">Any quality</option><option value="high" ${filters.quality==='high'?'selected':''}>High quality</option><option value="lossless" ${filters.quality==='lossless'?'selected':''}>Lossless</option><option value="low" ${filters.quality==='low'?'selected':''}>Low quality</option></select><input id="minDurationFilter" class="modal-input small-input" type="number" min="0" placeholder="Min min" value="${filters.minDuration||''}"><input id="maxDurationFilter" class="modal-input small-input" type="number" min="0" placeholder="Max min" value="${filters.maxDuration||''}"></div>${songTablePower(list)}`;
      wireLibraryPower();
    }

    function wireLibraryPower(){
      const rerender=()=>{power.libraryFilters={artist:$('#filterArtist')?.value||'',genre:$('#filterGenre')?.value||'',rating:Number($('#filterRating')?.value||0),quality:$('#filterQuality')?.value||'all',minDuration:Number($('#minDurationFilter')?.value||0),maxDuration:Number($('#maxDurationFilter')?.value||0)};state.search=$('#librarySearchPower')?.value||'';showEnhancedLibrary(true);};
      ['filterArtist','filterGenre','filterRating','filterQuality','minDurationFilter','maxDurationFilter'].forEach(id=>$('#'+id)?.addEventListener('change',rerender));
      $('#librarySearchPower')?.addEventListener('input',()=>{clearTimeout(wireLibraryPower._t);wireLibraryPower._t=setTimeout(rerender,180);});
      $('#advancedRescan')?.addEventListener('click',api.scanAllFolders);
      $('#advancedPlay')?.addEventListener('click',()=>api.playList(getFilteredLibrary()));
      bindPowerRows($('#mainView'));
    }

    function wirePowerView(kind, extra){
      bindPowerRows($('#mainView'));
      $('#homeStatsBtn')?.addEventListener('click',()=>showView('stats'));
      $('#homeForYouBtn')?.addEventListener('click',()=>showView('foryou'));
      $('#clearStatsBtn')?.addEventListener('click',()=>{power.stats=mergeDeep(defaults.stats,{});powerSave();showView('stats');toast('Listening statistics cleared');});
      $('#exportStatsBtn')?.addEventListener('click',()=>downloadJSON('localify-stats.json',power.stats));
      $('#rescanDupBtn')?.addEventListener('click',()=>showView('tools','duplicates'));
      $$('#mainView [data-tool]').forEach(b=>b.addEventListener('click',()=>{const t=b.dataset.tool;if(t==='duplicates')showView('tools','duplicates');else if(t==='artwork'){findArtworkForMissing();}else if(t==='backup')exportFullBackup();else if(t==='timer')openSleepTimer();else if(t==='mini')toggleMini();else if(t==='studio')openAdvancedSettings();}));
      $$('#mainView [data-artist-filter]').forEach(b=>b.addEventListener('click',()=>{showEnhancedLibrary();$('#filterArtist').value=b.dataset.artistFilter;$('#filterArtist').dispatchEvent(new Event('change'));}));
    }

    function setSongRating(id){
      if(!id) return;
      const next=rateFor(id)>=5?0:rateFor(id)+1;
      power.ratings[id]=next;
      state.ratings=power.ratings;
      powerSave();
      $$('[data-rate-id]').filter(b=>b.dataset.rateId===id).forEach(b=>{
        const compact=b.classList.contains('compact');
        b.innerHTML=`<span>${'★'.repeat(next)}${'☆'.repeat(5-next)}</span>${compact?'':`<small>${next?`${next}/5`:'Rate'}</small>`}`;
        b.title=next?`${next}/5 rating — click to change`:'Rate this song';
      });
      toast(next?`Rated ${next}/5`:'Rating cleared');
    }

    function bindPowerRows(root) {
      if(!root) return;
      $$('.song-row',root).forEach(row=>{
        if(row.dataset.powerBound) return; row.dataset.powerBound='1';
        row.addEventListener('click',e=>{if(e.target.closest('button'))return;api.playById(row.dataset.songId);});
        row.addEventListener('dragstart',()=>{dragSongId=row.dataset.songId;});
        row.addEventListener('dragover',e=>e.preventDefault());
        row.addEventListener('drop',e=>{e.preventDefault();if(dragSongId && dragSongId!==row.dataset.songId && state.queue.length){const from=state.queue.indexOf(dragSongId),to=state.queue.indexOf(row.dataset.songId);if(from>=0&&to>=0){state.queue.splice(from,1);state.queue.splice(to,0,dragSongId);api.renderQueue?.();}}});
      });
    }

    // ---------------- Artwork finder ----------------
    async function findArtworkForMissing(){
      const missing=state.library.filter(s=>!s.art).slice(0,30); if(!missing.length){toast('All scanned tracks already have artwork');return;}
      toast(`Finding artwork for ${missing.length} tracks…`); let count=0;
      for(const s of missing){try{const artUrl=await lookupArtwork(s);if(artUrl){s.art=artUrl;await api.dbPut('songs',s);count++;}}catch{} await new Promise(r=>setTimeout(r,180));}
      state.library=await api.dbGetAll('songs');api.persist();api.render();toast(`Added artwork to ${count} track${count===1?'':'s'}`);
    }

    // ---------------- Sleep timer / mini player ----------------
    function openSleepTimer(){
      const current=power.sleep.until?Math.max(0,power.sleep.until-Date.now()):0;
      api.openModal(`<div class="power-modal sleep-modal"><div class="power-modal-head"><div><h2>Sleep timer</h2><p>Automatically pauses music after the selected time. Optional fade-out lowers the volume over the final 20 seconds.</p></div><button class="icon-btn" id="sleepClose">×</button></div><div class="sleep-status">${current?`Currently set for <strong>${fmtTimer(current)}</strong>`:'Currently off'}</div><div class="sleep-options">${[0,5,10,15,30,45,60,90].map(v=>`<button class="sleep-option ${(!current&&v===0)||(current&&Math.abs(current/60000-v)<1)?'selected':''}" data-sleep="${v}">${v===0?'Off':v+' min'}</button>`).join('')}</div><label class="settings-toggle"><input id="sleepFade" type="checkbox" ${power.sleep.fade!==false?'checked':''}><span><strong>Fade out before stopping</strong><small>Over the last 20 seconds, smoothly lower volume to zero, then pause.</small></span></label><div class="modal-actions"><button class="btn" id="sleepCancel">Close</button></div></div>`);
      $$('.sleep-option').forEach(b=>b.onclick=()=>{
        const min=Number(b.dataset.sleep);
        power.sleep.until=min?Date.now()+min*60000:0;
        power.sleep.fade=$('#sleepFade')?.checked!==false;
        powerSave();
        api.closeModal();
        toast(min?`Sleep timer set for ${min} minutes`:'Sleep timer off');
        refreshPowerUI();
        publishMiniState();
      });
      $('#sleepCancel').onclick=api.closeModal;
      $('#sleepClose').onclick=api.closeModal;
    }
    function startSleepWatcher(){
      clearInterval(sleepTimer);
      sleepTimer=setInterval(()=>{
        if(!power.sleep.until) return;
        const left=power.sleep.until-Date.now();
        if(left<=0){
          power.sleep.until=0;
          audio.pause();
          api.persist();
          toast('Sleep timer stopped playback');
          refreshPowerUI();
          publishMiniState();
          return;
        }
        if(power.sleep.fade && left<20000 && !audio.paused){
          audio.volume=Math.max(0, (state.volume||.8)*(left/20000));
        }else if(audio.volume<state.volume && left>=20000){
          applyEffectiveVolume();
        }
        refreshPowerUI();
        publishMiniState();
      },1000);
    }

    function initMiniBridge(){
      if(!('BroadcastChannel' in window)) return;
      try{
        miniChannel=new BroadcastChannel('localify-mini');
        miniChannel.addEventListener('message',e=>{
          const m=e.data||{};
          if(m.type==='hello'){ publishMiniState(); return; }
          if(m.type==='command'){
            if(m.action==='playPause'){ audio.paused?audio.play():audio.pause(); }
            else if(m.action==='next'){ api.nextTrack(); }
            else if(m.action==='previous'){ api.previousTrack(); }
            else if(m.action==='close'){ closeMiniWindow(); }
            else if(m.action==='seek' && Number.isFinite(audio.duration)) audio.currentTime=Math.max(0,Math.min(audio.duration,Number(m.value)||0));
            else if(m.action==='volume'){ const v=Math.max(0,Math.min(1,Number(m.value))); state.volume=v; audio.volume=v; $('#volume').value=v; $('#muteBtn').textContent=v===0?'🔇':'🔊'; api.persist(); publishMiniState(); }
          }
        });
      }catch{}
    }
    function miniStatePayload(){
      const s=state.library.find(x=>x.id===state.currentId);
      return {type:'state',track:s?{title:s.title||'Nothing playing',artist:s.artist||'—',album:s.album||'',art:s.art||''}:null,currentTime:Number(audio.currentTime||0),duration:Number(audio.duration||0),paused:audio.paused,volume:Number(state.volume ?? audio.volume ?? .8),sleepUntil:Number(power.sleep.until||0),sentAt:Date.now(),appearance:{accent:getComputedStyle(document.documentElement).getPropertyValue('--accent').trim(),accentRgb:getComputedStyle(document.documentElement).getPropertyValue('--accent-rgb').trim()}};
    }
    function publishMiniState(){
      if(!miniChannel) return;
      try{ miniChannel.postMessage(miniStatePayload()); }catch{}
    }
    function closeMiniWindow(){
      try{ if(miniWindow && !miniWindow.closed) miniWindow.close(); }catch{}
      miniWindow=null;
      power.mini=false;
      clearInterval(miniPollTimer); miniPollTimer=null;
      powerSave();
    }
    function openMiniWindow(){
      if(miniWindow && !miniWindow.closed){ try{miniWindow.focus();}catch{}; publishMiniState(); return; }
      miniWindow=window.open(`${location.origin}/mini.html`,`LocalifyMini`,`popup=yes,width=430,height=150,resizable=yes,scrollbars=no`);
      if(!miniWindow){ toast('Mini player could not open. Allow pop-ups for Localify.'); power.mini=false; return; }
      power.mini=true;
      powerSave();
      publishMiniState();
      clearInterval(miniPollTimer);
      miniPollTimer=setInterval(()=>{
        if(!miniWindow || miniWindow.closed){ closeMiniWindow(); return; }
        publishMiniState();
      },800);
      try{miniWindow.focus();}catch{}
    }
    function toggleMini(next=undefined){
      const want=next===undefined?!power.mini:Boolean(next);
      if(want) openMiniWindow(); else closeMiniWindow();
    }
    function updateMini(){ publishMiniState(); }
    function fmtTimer(ms){const sec=Math.ceil(ms/1000);if(sec>=3600)return `${Math.floor(sec/3600)}h`;if(sec>=60)return `${Math.floor(sec/60)}m`;return `${sec}s`;}
    // ---------------- Dynamic theme ----------------
    async function applyDynamicTheme(song){
      if(!power.features.dynamicTheme || !song?.art) return;
      try{
        const img=new Image(); img.src=song.art; await img.decode(); const canvas=document.createElement('canvas');canvas.width=20;canvas.height=20;const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0,20,20);const d=ctx.getImageData(0,0,20,20).data;let r=0,g=0,b=0,n=0;for(let i=0;i<d.length;i+=4){const rr=d[i],gg=d[i+1],bb=d[i+2];if(rr+gg+bb<60)continue;r+=rr;g+=gg;b+=bb;n++;}if(!n)return;r=Math.round(r/n);g=Math.round(g/n);b=Math.round(b/n);const hex='#'+[r,g,b].map(x=>x.toString(16).padStart(2,'0')).join('');state.appearance.preset='custom';state.appearance.accent=hex;state.appearance.accent2=hex;document.documentElement.style.setProperty('--accent',hex);document.documentElement.style.setProperty('--accent-2',hex);document.documentElement.style.setProperty('--accent-rgb',`${r},${g},${b}`);document.body.dataset.theme='custom';api.persist();
      }catch{}
    }
    audio.addEventListener('play',async()=>{const s=state.library.find(x=>x.id===state.currentId);applyDynamicTheme(s);updateLoudnessFromSong(s); if(power.features.autoArtwork && s && !s.art){try{const artUrl=await lookupArtwork(s);if(artUrl){await saveArtworkOnly(s,artUrl);toast('Artwork added automatically');}}catch{}}});

    // ---------------- Backup ----------------
    function downloadJSON(name,data){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);}
    async function exportFullBackup(){const cfg={version:3,createdAt:new Date().toISOString(),songs:state.library.map(s=>{const x={...s};delete x.handle;return x;}),folders:state.folders.map(f=>({id:f.id,name:f.name})),playlists:state.playlists,favorites:[...state.favorites],history:state.history,power};downloadJSON('localify-full-backup.json',cfg);power.lastBackup=Date.now();powerSave();toast('Full Localify backup exported');}
    function importFullBackup(){const inp=document.createElement('input');inp.type='file';inp.accept='application/json';inp.onchange=async()=>{try{const x=JSON.parse(await inp.files[0].text());if(Array.isArray(x.playlists))state.playlists=x.playlists;if(Array.isArray(x.favorites))state.favorites=new Set(x.favorites);if(Array.isArray(x.history))state.history=x.history;if(x.power)power=mergeDeep(defaults,x.power);if(Array.isArray(x.songs)){for(const s of x.songs){const old=state.library.find(v=>v.id===s.id);await api.dbPut('songs',old?{...old,...s}:s);}state.library=await api.dbGetAll('songs');}powerSave();api.persist();api.render();refreshPowerUI();toast('Backup restored');}catch{toast('Invalid Localify backup')}};inp.click();}
    function exportM3U(){for(const p of state.playlists){const lines=['#EXTM3U',...p.songIds.map(id=>{const s=state.library.find(x=>x.id===id);return s?`#EXTINF:${Math.round(s.duration||-1)},${s.artist||''} - ${s.title||''}\n${s.path||s.name||''}`:''}).filter(Boolean)];downloadText(`${p.name.replace(/[^\w -]/g,'')||'playlist'}.m3u`,lines.join('\n'));}toast('M3U playlists exported');}
    function downloadText(name,text){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);}

    // ---------------- Global UI / navigation ----------------
    function addPowerNav(){
      const nav=$('.main-nav'); if(!nav||$('#powerNav'))return;
      const wrap=document.createElement('div');wrap.id='powerNav';wrap.className='power-nav-section';wrap.innerHTML=`<div class="power-nav-title">Personal</div><button class="nav-btn" data-power-view="foryou"><span class="nav-icon">✦</span><span class="nav-label">For You</span></button><button class="nav-btn" data-power-view="stats"><span class="nav-icon">▥</span><span class="nav-label">Listening stats</span></button><button class="nav-btn" data-power-view="tools"><span class="nav-icon">⌘</span><span class="nav-label">Library tools</span></button>`;nav.parentNode.insertBefore(wrap,nav.nextSibling);
      wrap.addEventListener('click',e=>{const b=e.target.closest('[data-power-view]');if(!b)return;e.preventDefault();e.stopPropagation();showView(b.dataset.powerView);refreshPowerNav(b.dataset.powerView);});
    }
    function refreshPowerNav(active){
      $$('#powerNav [data-power-view]').forEach(b=>b.classList.toggle('active',b.dataset.powerView===active));
      $$('.nav-btn[data-view]').forEach(b=>b.classList.toggle('active',false));
    }

    function addPlayerExtras(){
      if(!$('#powerTimerBtn')){const b=document.createElement('button');b.id='powerTimerBtn';b.className='player-btn';b.title='Sleep timer';b.textContent='⏱';$('#lyricsBtn').before(b);b.onclick=openSleepTimer;}
      if(!$('#powerMiniBtn')){const b=document.createElement('button');b.id='powerMiniBtn';b.className='player-btn';b.title='Mini player';b.textContent='▣';$('#queueBtn').after(b);b.onclick=()=>toggleMini();}
      if(!$('#powerStudioBtn')){const b=document.createElement('button');b.id='powerStudioBtn';b.className='player-btn';b.title='Audio studio';b.textContent='🎚';$('#lyricsBtn').before(b);b.onclick=openAdvancedSettings;}
      const focusActions=$('#focusOverlay .focus-actions');
      if(focusActions&&!$('#focusCinemaBtn')){const b=document.createElement('button');b.id='focusCinemaBtn';b.className='focus-action';b.title='Cinema mode';b.textContent='◉';b.onclick=()=>{state.appearance.focusLayout='cinema';state.appearance.focusBackdrop='gradient';state.appearance.focusArtScale=1;api.persist();api.renderFocusOverlay(state.library.find(s=>s.id===state.currentId));$('#focusLayoutLabel').textContent='Cinema';};focusActions.insertBefore(b,$('#focusFullscreenBtn'));}
    }

    function createPowerUI(){ initMiniBridge(); addPowerNav(); addPlayerExtras(); installDropImport(); installPowerCapture(); observeRenders(); }
    function installPowerCapture(){
      document.addEventListener('click',e=>{
        const rate=e.target.closest('[data-rate-id]');
        if(rate){ e.preventDefault(); e.stopPropagation(); setSongRating(rate.dataset.rateId); return; }
        const normal=e.target.closest('.nav-btn[data-view]');
        if(normal)refreshPowerNav('');
        const b=e.target.closest('[data-power-view]');
        if(!b)return;
      });
      document.addEventListener('keydown',e=>{
        if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='m'){e.preventDefault();toggleMini();}
        if(e.key==='Escape' && power.mini){toggleMini(false);}
      });
    }

    // Enhance normal song rows whenever the base app re-renders.
    function enhanceRows(){
      const main=$('#mainView'); if(!main)return;
      $$('.song-row',main).forEach(row=>{
        if(row.dataset.enhanced) return;
        row.dataset.enhanced='1'; row.setAttribute('draggable','true');
        const actionCell=row.lastElementChild; if(actionCell && !actionCell.querySelector('[data-rate-id]')){
          const rate=document.createElement('span');rate.className='inline-rating';rate.innerHTML=ratingStars(row.dataset.songId,true);actionCell.insertBefore(rate,actionCell.firstChild);
        }
      });
    }
    function observeRenders(){
      const obs=new MutationObserver(()=>{enhanceRows(); updateMini(); wireQueueDnD();});
      obs.observe($('#mainView'),{childList:true,subtree:true});
      const qobs=new MutationObserver(()=>wireQueueDnD());
      if($('#queueList')) qobs.observe($('#queueList'),{childList:true,subtree:true});
      enhanceRows(); wireQueueDnD();
    }
    function wireQueueDnD(){
      const list=$('#queueList'); if(!list)return;
      $$('.queue-row',list).forEach(row=>{if(row.dataset.powerDrag)return;row.dataset.powerDrag='1';row.draggable=true;row.addEventListener('dragstart',()=>{dragSongId=row.dataset.qid;});row.addEventListener('dragover',e=>e.preventDefault());row.addEventListener('drop',e=>{e.preventDefault();const target=row.dataset.qid;if(!dragSongId||dragSongId===target)return;const from=state.queue.indexOf(dragSongId),to=state.queue.indexOf(target);if(from>=0&&to>=0){state.queue.splice(from,1);state.queue.splice(to,0,dragSongId);api.renderQueue?.();api.persist();toast('Queue reordered');}});});
    }

    function installDropImport(){
      if(!power.dropImport)return;
      document.addEventListener('dragover',e=>{if([...e.dataTransfer.types].includes('Files')){e.preventDefault();document.body.classList.add('power-dragging');}},false);
      document.addEventListener('dragleave',e=>{if(e.target===document.documentElement)document.body.classList.remove('power-dragging');});
      document.addEventListener('drop',async e=>{if(![...e.dataTransfer.types].includes('Files'))return;e.preventDefault();document.body.classList.remove('power-dragging');const files=[...e.dataTransfer.files].filter(f=>/\.(mp3|m4a|aac|wav|ogg|flac)$/i.test(f.name));if(!files.length){toast('Drop audio files to import them');return;}const f={id:`drop-${crypto.randomUUID()}`,name:'Dropped files',legacyFiles:files};state.folders.push(f);for(const file of files){const song=await api.parseFile(file,f.id,file.name,null);await api.upsertSong(song);}api.finishScan?.();api.render();toast(`Imported ${files.length} audio file${files.length===1?'':'s'} — choose a Music Folder to make them persistent`);},false);
    }

    function startAutomation(){
      clearInterval(monitorTimer); if(!power.features.folderMonitor)return;
      monitorTimer=setInterval(()=>{api.scanAllFolders().catch(()=>{});},120000);
    }

    function refreshPowerUI(){
      if($('#powerMiniPlayer')) $('#powerMiniPlayer').classList.toggle('hidden',!power.mini);
      updateMini();
    }

    // Public helpers for this module and debugging.
    function openAdvancedFromButton(){openAdvancedSettings();}

    // Initial load and event wiring.
    Promise.resolve(loadPower()).then(()=>{
      // Ensure the app has a power state before any view interaction.
      addPowerNav(); addPlayerExtras();
      refreshPowerUI();
      window.LocalifyPower = {power,openAdvancedSettings,showView,showEnhancedLibrary,openSleepTimer,toggleMini,findDuplicates,exportFullBackup};
    });

    // Save power state when the window closes.
    window.addEventListener('beforeunload',()=>{try{api.dbPut('config',structuredClone(power),'powerState');}catch{}});
  });
})();
