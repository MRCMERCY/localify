@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Localify.ps1"
pause
